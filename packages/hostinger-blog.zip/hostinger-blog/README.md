# Hostinger blog theme

This is a WordPress theme for the Hostinger blog.

## Installation

1. Clone this repository into your `wp-content/themes` directory.
2. Run `npm install` to install dependencies.
3. Run `npm run prod` to build the theme.
4. Run `npm run build-blocks` to build theme blocks.