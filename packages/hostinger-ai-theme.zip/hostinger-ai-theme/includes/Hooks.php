<?php

namespace Hostinger\AiTheme;

defined( 'ABSPATH' ) || exit;

class Hooks {
    public function __construct() {
        if ( isset( $_GET['ai_preview'] ) || isset($_SERVER['HTTP_SEC_FETCH_DEST']) && $_SERVER['HTTP_SEC_FETCH_DEST'] == 'iframe' ) {
            add_filter( 'show_admin_bar', '__return_false' );
        }
    }
}
