<?php

namespace Hostinger\AiTheme;

use WP_Admin_Bar;

defined( 'ABSPATH' ) || exit;

class Hooks {
    public function __construct() {
        if ( isset( $_GET['ai_preview'] ) || isset($_SERVER['HTTP_SEC_FETCH_DEST']) && $_SERVER['HTTP_SEC_FETCH_DEST'] == 'iframe' ) {
            add_filter( 'show_admin_bar', '__return_false' );
            add_action( 'wp_head', array( $this, 'hide_preview_domain_topbar' ), 999 );
        }

        $this->rehook_edit_site_menu();
    }

    /**
     * @return void
     */
    public function rehook_edit_site_menu() {
        remove_action( 'admin_bar_menu', 'wp_admin_bar_edit_site_menu', 40 );
        add_action( 'admin_bar_menu', [ $this, 'add_edit_site_menu' ], 39 );
    }

    /**
     * @param WP_Admin_Bar $wp_admin_bar The WP_Admin_Bar instance.
     *
     * @return void
     */
    public function add_edit_site_menu( WP_Admin_Bar $wp_admin_bar ) {
        global $_wp_current_template_id;

        // Don't show if a block theme is not activated.
        if ( ! wp_is_block_theme() ) {
            return;
        }

        // Don't show for users who can't edit theme options or when in the admin.
        if ( ! current_user_can( 'edit_theme_options' ) ) {
            return;
        }

        $wp_admin_bar->add_node(
            array(
                'id'    => 'site-editor',
                'title' => __( 'Edit site' ),
                'href'  => add_query_arg(
                    array(
                        'postType' => 'wp_template',
                        'postId'   => $_wp_current_template_id,
                        'canvas'   => 'edit',
                    ),
                    admin_url( 'site-editor.php' )
                ),
            )
        );
    }

    /**
     * @return void
     */
    public function hide_preview_domain_topbar() {
        ?>
        <style>
            #hostinger-preview-banner {
                display: none!important;
                box-sizing: border-box!important;
            }
        </style>
        <?php
    }
}
