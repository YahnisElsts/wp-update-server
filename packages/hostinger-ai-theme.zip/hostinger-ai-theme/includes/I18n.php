<?php

namespace Hostinger\AiTheme;

defined( 'ABSPATH' ) || exit;

class I18n {
    public function __construct() {
        add_action( 'after_setup_theme', array( $this, 'load_plugin_textdomain' ) );
    }

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.2.0
	 */
	public function load_plugin_textdomain(): void {
        load_theme_textdomain(
			'hostinger-ai-websites',
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}
}
