<?php

namespace Hostinger\AiTheme\Builder;

use stdClass;
use Hostinger\WpHelper\Config;
use Hostinger\AiTheme\Requests\Client;
use Hostinger\WpHelper\Utils;
use Hostinger\WpHelper\Utils as Helper;

defined( 'ABSPATH' ) || exit;

class ImageManager {
    public const GENERATE_CONTENT_IMAGES_ACTION = '/v3/wordpress/plugin/get-images';
    public const GENERATE_CONTENT_ACTION = '/v3/wordpress/plugin/generate-content';
    public const GET_UNSPLASH_IMAGE_ACTION = '/v3/wordpress/plugin/download-image';
    /**
     * @var string
     */
    public string $keyword;
    /**
     * @var string
     */
    public string $keyword_slug;
    /**
     * @var Helper
     */
    private Utils $helper;
    /**
     * @var Client
     */
    private Client $client;

    /**
     * @param string $keyword
     */
    public function __construct( string $keyword = '' )
    {
        $this->keyword        = $keyword;
        if(!empty($this->keyword)) {
            $this->keyword_slug = sanitize_title($this->keyword);
        }
        $this->helper         = new Helper();
        $config_handler       = new Config();
        $this->client         = new Client( $config_handler->getConfigValue( 'base_rest_uri', HOSTINGER_AI_WEBSITES_REST_URI ), [
            Config::TOKEN_HEADER  => $this->helper::getApiToken(),
            Config::DOMAIN_HEADER => $this->helper->getHostInfo(),
            'Content-Type' => 'application/json'
        ] );
    }

    public function set_keyword(string $keyword): void
    {
        $this->keyword = $keyword;
        $this->keyword_slug = sanitize_title($this->keyword);
    }

    /**
     * @return object
     */
    public function get_unsplash_image_data( bool $random = false ): object {
        $transient_key = 'image_data_' . $this->keyword_slug;

        if ( get_transient( $transient_key ) ) {
            $image_list = get_transient( $transient_key );
        } else {
            $image_list = $this->fetch_image_list();

            if ( !empty( $image_list ) ) {
                set_transient( $transient_key, $image_list, DAY_IN_SECONDS );
            }
        }

        return $this->pick_image_from_list( $image_list, $random );
    }

    /**
     * @param array $image_list
     * @param bool  $random
     *
     * @return mixed|stdClass|void
     */
    public function pick_image_from_list( array $image_list, bool $random = false ) {
        $used_images = get_option('hostinger_ai_used_images', []);

        if( empty( $image_list ) ) {
            return new stdClass();
        }

        if ( ! empty( $random ) ) {
            shuffle( $image_list );
        }

        foreach( $image_list as $image ) {
            if ( empty( $used_images[$this->keyword_slug][$image->image] ) ) {
                $used_images[$this->keyword_slug][$image->image] = $image;

                update_option( 'hostinger_ai_used_images', $used_images, false );

                return $image;
            }
        }

        update_option( 'hostinger_ai_used_images', [], false );

        return end($image_list);
    }

    /**
     * @return array
     */
    public function fetch_image_list(): array {
        try {
            $response = $this->client->get( self::GENERATE_CONTENT_IMAGES_ACTION, [
                'keywords' => array( $this->keyword ),
                'amount'   => 40
            ] );

            $response_code = wp_remote_retrieve_response_code( $response );
            $response_body = wp_remote_retrieve_body( $response );
            $response_data = json_decode( $response_body )->data;

            if ( empty( $response_data ) ) {
                error_log(print_r($response, true));
                return array();
            }

            if ( is_wp_error( $response ) || $response_code !== 200 ) {
                error_log('Response error');
                error_log(print_r($response_data, true));
            } else {
                return json_decode( $response_body )->data;
            }
        } catch ( Exception $exception ) {
            error_log('There was an error getting unsplash image data' . $exception->getMessage() );
        }

        return array();
    }

    /**
     * @param $url
     * @param $image_size_data
     *
     * @return string
     */
    public function modify_image_url( $url, $element_structure = null ): string {
        $parsed_url = parse_url( $url );

        parse_str( $parsed_url['query'], $query_params );

        if ( ! empty( $element_structure['image_size'] ) ) {

            if ( ! empty( $element_structure['image_size']['width'] ) ) {
                $query_params['w'] = $element_structure['image_size']['width'];
            }

            if ( ! empty( $element_structure['image_size']['height'] ) ) {
                $query_params['h'] = $element_structure['image_size']['height'];
            }

            if ( ! empty( $element_structure['image_size']['crop'] ) ) {
                $query_params['fit'] = 'crop';
            }

        }

        $new_query = http_build_query( $query_params );

        return $parsed_url['scheme'] . '://' . $parsed_url['host'] . $parsed_url['path'] . '?' . $new_query;
    }
}
