<?php

namespace Hostinger\AiTheme\Admin;

defined( 'ABSPATH' ) || exit;

class Assets {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
	}

	/**
	 * Enqueues styles for the Hostinger admin pages.
	 */
	public function admin_styles(): void {
		wp_enqueue_style( 'hostinger_ai_websites_main_styles', HOSTINGER_AI_WEBSITES_ASSETS_URL . '/css/main.min.css', array(), wp_get_theme()->get( 'Version' ) );
	}

	/**
	 * Enqueues scripts for the Hostinger admin pages.
	 */
	public function admin_scripts(): void {
			wp_enqueue_script(
				'hostinger_ai_websites_main_scripts',
				HOSTINGER_AI_WEBSITES_ASSETS_URL . '/js/main.min.js',
				array(
					'jquery',
					'wp-i18n',
				),
                wp_get_theme()->get( 'Version' ),
				false
			);

			$localize_data = array(
                'site_url'     => get_site_url(),
                'plugin_url'   => get_stylesheet_directory_uri() . '/',
                'admin_url' => admin_url('admin-ajax.php'),
                'translations' => array(
                    'ai_website_creation' => __( 'AI Website Creation', 'hostinger-ai-theme' ),
					'ai_website_creation_tell_us_about_your_site' => __('Tell us about your site', 'hostinger-ai-theme'),
					'ai_website_creation_brand_name' => __('Brand name', 'hostinger-ai-theme'),
					'ai_website_creation_website_type' => __('Website type', 'hostinger-ai-theme'),
					'ai_website_creation_other' => __('Other', 'hostinger-ai-theme'),
					'ai_website_creation_describe_your_site' => __('Describe your site', 'hostinger-ai-theme'),
					'ai_website_creation_description' => __('Description', 'hostinger-ai-theme'),
					'ai_website_creation_create' => __('Create', 'hostinger-ai-theme'),
					'ai_website_creation_generating_colors' => __('Generating colors', 'hostinger-ai-theme'),
					'ai_website_creation_generating_structure' => __('Generating structure', 'hostinger-ai-theme'),
					'ai_website_creation_generating_content' => __('Generating content', 'hostinger-ai-theme'),
					'ai_website_creation_building_content' => __('Building content', 'hostinger-ai-theme'),
					'ai_website_creation_back_to_form' => __('Back to form', 'hostinger-ai-theme'),
					'ai_website_creation_edit_site' => __('Edit site', 'hostinger-ai-theme'),
					'ai_website_creation_give_us_a_minute' => __('Give us a minute', 'hostinger-ai-theme'),
					'ai_website_creation_enter_at_least_eleven_characters' => __('Enter at least 11 characters', 'hostinger-ai-theme'),
					'ai_website_creation_let_us_know_about_your_website' => __('Let us know more about your website to get the best result', 'hostinger-ai-theme'),
					'ai_website_creation_feel_free_to_add_more_details' => __('Great description! Feel free to add more details', 'hostinger-ai-theme'),
					'ai_website_creation_ai_website_mistakes' => __('Hostinger AI website creator for WordPress is still in early stages. Some mistakes can be made and some inconsistencies can be visible.', 'hostinger-ai-theme')
                ),
                'rest_base_url' => esc_url_raw( rest_url() ),
                'nonce'         => wp_create_nonce( 'wp_rest' ),
                'ajax_nonce'         => wp_create_nonce( 'updates' ),
            );

			wp_localize_script(
				'hostinger_ai_websites_main_scripts',
				'hostinger_ai_websites',
				$localize_data
			);
	}
}
