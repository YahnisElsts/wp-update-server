<?php

namespace Hostinger\AiTheme\Admin;

defined( 'ABSPATH' ) || exit;

class Assets {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
	}

	/**
	 * Enqueues styles for the Hostinger admin pages.
	 */
	public function admin_styles(): void {
		wp_enqueue_style( 'hostinger_ai_websites_main_styles', HOSTINGER_AI_WEBSITES_ASSETS_URL . '/css/main.min.css', array(), wp_get_theme()->get( 'Version' ) );

        $hide_menu_item = '.hsr-list__item a.hostinger-ai-website-creation, .toplevel_page_hostinger a[href="admin.php?page=hostinger-ai-website-creation"] { display: none !important; }';
        wp_add_inline_style( 'hostinger_ai_websites_main_styles', $hide_menu_item );
    }

	/**
	 * Enqueues scripts for the Hostinger admin pages.
	 */
	public function admin_scripts(): void {
			wp_enqueue_script(
				'hostinger_ai_websites_main_scripts',
				HOSTINGER_AI_WEBSITES_ASSETS_URL . '/js/main.min.js',
				array(
					'jquery',
					'wp-i18n',
				),
                wp_get_theme()->get( 'Version' ),
				false
			);

            $site_url = add_query_arg( 'LSCWP_CTRL', 'before_optm', get_site_url() . '/' );

			$localize_data = array(
                'site_url'     => $site_url,
                'plugin_url'   => get_stylesheet_directory_uri() . '/',
                'admin_url' => admin_url('admin-ajax.php'),
                'translations' => array(
					'ai_website_creation_site_couldnt_be_created' => __('<span style="display: flex; flex-direction: column; gap: 8px;"><h3 style="margin:0; font-size:16px">Site couldn’t be created</h3> <p style="margin-top:0; font-size:14px; color:#727586">That’s because of an issue on our end. Try creating your site again. </p></span>' ,'hostinger-ai-theme'),
                    'ai_website_creation' => __( 'AI Website Creation', 'hostinger-ai-theme' ),
					'ai_website_creation_tell_us_about_your_site' => __('Tell us about your site', 'hostinger-ai-theme'),
					'ai_website_creation_brand_name' => __('Brand name', 'hostinger-ai-theme'),
					'ai_website_creation_website_type' => __('Website type', 'hostinger-ai-theme'),
					'ai_website_creation_other' => __('Other', 'hostinger-ai-theme'),
					'ai_website_creation_portfolio' => __('Portfolio', 'hostinger-ai-theme'),
					'ai_website_creation_business_and_services' => __('Business and services', 'hostinger-ai-theme'),
					'ai_website_creation_describe_your_site' => __('Describe your site', 'hostinger-ai-theme'),
					'ai_website_creation_description' => __('Description', 'hostinger-ai-theme'),
					'ai_website_creation_create' => __('Create', 'hostinger-ai-theme'),
					'ai_website_creation_generating_colors' => __('Generating colors', 'hostinger-ai-theme'),
					'ai_website_creation_generating_structure' => __('Generating structure', 'hostinger-ai-theme'),
					'ai_website_creation_generating_content' => __('Generating content', 'hostinger-ai-theme'),
					'ai_website_creation_building_content' => __('Building content', 'hostinger-ai-theme'),
					'ai_website_creation_create_again' => __('Create again', 'hostinger-ai-theme'),
					'ai_website_creation_confirm_and_edit' => __('Confirm & edit', 'hostinger-ai-theme'),
					'ai_website_creation_give_us_a_minute' => __('Give us a minute', 'hostinger-ai-theme'),
					'ai_website_creation_enter_at_least_eleven_characters' => __('Enter at least 11 characters', 'hostinger-ai-theme'),
					'ai_website_creation_let_us_know_about_your_website' => __('Let us know more about your website to get the best result', 'hostinger-ai-theme'),
					'ai_website_creation_feel_free_to_add_more_details' => __('Great description! Feel free to add more details', 'hostinger-ai-theme'),
					'ai_website_creation_ai_website_mistakes' => __('Hostinger AI website builder for WordPress is still in early stages. Some mistakes can be made and some inconsistencies can be visible.', 'hostinger-ai-theme'),
					'ai_website_creation_existing_content_deleted' => __('Existing content will be deleted', 'hostinger-ai-theme'),
					'ai_website_creation_existing_content_deleted_paragraph' => __('You have already generated content. Continuing will delete all previous content. Are you sure you want to proceed?', 'hostinger-ai-theme'),
					'ai_website_creation_cancel' => __('Cancel', 'hostinger-ai-theme'),
					'ai_website_creation_continue' => __('Continue', 'hostinger-ai-theme'),
                ),
                'content_generated' => (int)!empty( get_option( 'hostinger_ai_version' ) ),
                'rest_base_url' => esc_url_raw( rest_url() ),
                'nonce'         => wp_create_nonce( 'wp_rest' ),
                'ajax_nonce'         => wp_create_nonce( 'updates' ),
            );

			wp_localize_script(
				'hostinger_ai_websites_main_scripts',
				'hostinger_ai_websites',
				$localize_data
			);
	}
}
