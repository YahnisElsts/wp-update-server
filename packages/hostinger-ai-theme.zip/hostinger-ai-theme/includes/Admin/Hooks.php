<?php

namespace Hostinger\AiTheme\Admin;

defined( 'ABSPATH' ) || exit;

class Hooks {
    public const PREVIEW_IMAGE_URL_META_SLUG = 'hostinger_preview_image_url';
    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_preview_image_metabox' ) );
        add_action( 'save_post', array( $this, 'save_preview_image_url' ), 10, 2 );
    }

    /**
     * @param $post_type
     *
     * @return void
     */
    public function add_preview_image_metabox( $post_type ): void {
        if ( $post_type != 'post' ) {
            return;
        }

        $post_types = post_type_supports( 'post', 'thumbnail' ) ? array( 'post' ) : array();

        add_meta_box(
            'hostinger_metabox',
            __( 'Featured Image with URL', 'hostinger-ai-theme' ),
            array( $this, 'render_metabox' ),
            $post_types,
            'normal',
            'low'
        );
    }

    /**
     * @param $post
     *
     * @return void
     */
    public function render_metabox( $post ): void {
        $image_url = get_post_meta( $post->ID, self::PREVIEW_IMAGE_URL_META_SLUG, true );

        include get_stylesheet_directory() . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'Admin' . DIRECTORY_SEPARATOR . 'Templates' . DIRECTORY_SEPARATOR . 'featured-image-metabox.php';
    }

    /**
     * @param $post_id
     * @param $post
     *
     * @return void
     */
    public function save_preview_image_url( $post_id, $post ) {
        if ( ! current_user_can( 'edit_post', $post_id ) || ! post_type_supports( $post->post_type, 'thumbnail' ) || defined( 'DOING_AUTOSAVE' ) ) {
            return;
        }

        if ( isset( $_POST[ self::PREVIEW_IMAGE_URL_META_SLUG ] ) ) {
            $image_url = isset( $_POST[ self::PREVIEW_IMAGE_URL_META_SLUG ] ) ? esc_url_raw( wp_unslash( $_POST[ self::PREVIEW_IMAGE_URL_META_SLUG ] ) ) : '';

            update_post_meta( $post_id, self::PREVIEW_IMAGE_URL_META_SLUG, $image_url );
        }

        $featured_image_id = get_post_meta( $post_id, '_thumbnail_id', true );

        if(!empty($featured_image_id)) {
            delete_post_meta( $post_id, self::PREVIEW_IMAGE_URL_META_SLUG );
        }
    }
}
