<?php

namespace Hostinger\AiTheme\Admin;

defined( 'ABSPATH' ) || exit;

class Menu {

	public function __construct() {
		add_filter( 'hostinger_menu_subpages', array( $this, 'add_menu_sub_pages' ) );
	}

	/**
	 * @param array $submenus
	 *
	 * @return array
	 */
	public function add_menu_sub_pages( array $submenus ): array {
		$submenus[] = array(
			'page_title' => __( 'AI website creation', 'hostinger-ai-websites' ),
			'menu_title' => __( 'AI website creation', 'hostinger-ai-websites' ),
			'capability' => 'manage_options',
			'menu_slug'  => 'hostinger-ai-website-creation',
			'callback'   => array( $this, 'renderWebsiteCreation' ),
			'menu_identifier' => 'generic',
			'menu_order' => 20
		);

		return $submenus;
	}

	/**
	 * @return void
	 */
	public function renderWebsiteCreation(): void {
		include_once __DIR__ . '/Views/WebsiteCreationOnboarding.php';
	}
}
