<?php

namespace Hostinger\AiTheme;

defined( 'ABSPATH' ) || exit;

class Redirects {
    /**
     * @var string
     */
    private string $platform;
    public const PLATFORM_CONTENT_CREATOR = 'ai-website-generation';

    /**
     *
     */
    public function __construct() {
        if ( ! isset( $_GET['platform'] ) ) {
            return;
        }

        $this->platform = sanitize_text_field( $_GET['platform'] );
        $this->login_redirect();
    }

    /**
     * @return void
     */
    private function login_redirect(): void {
        if ( $this->platform === self::PLATFORM_CONTENT_CREATOR ) {
            add_action(
                'init',
                static function () {
                    $redirect_url = admin_url( 'admin.php?page=hostinger-ai-website-creation' );
                    wp_safe_redirect( $redirect_url );
                    exit;
                }
            );
        }
    }
}