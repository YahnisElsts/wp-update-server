=== Hostinger AI theme ===
Tags: ai-theme
Requires at least: 5.6
Tested up to: 6.4
Requires PHP: 8.0
Stable tag: 1.0.3
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Text Domain: hostinger-ai-theme

== Description ==

Hostinger AI theme built with SEO and mobile responsiveness in mind, this theme ensures optimal performance and a better online presence.

== Changelog ==

1.0.3
===================

* Menu item changes
* Added lang param to content generation
* CSS changes
* Added default keywords for image elements

1.0.2
===================

* Removed iframe while previewing website
* Added deletion endpoints for clearing generated site data
* Added translations

1.0.1
===================

* Theme readme
* Add AI logic in theme
* Add localization

1.0.0
===================

* Initial theme functionality