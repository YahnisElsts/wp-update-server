let mix = require('laravel-mix');

mix.setPublicPath('./assets')
	.js('src/js/main.js', 'assets/js')
	.sass('src/css/style.scss', 'assets/css/main.css')
	.options({
		processCssUrls:false
	})
	.copy('src/images/**/*.{jpg,jpeg,png,gif,svg}', 'assets/images')
	.copy('src/fonts/**/*.{ttf,woff2,woff}', 'assets/fonts');
