import * as Survey from 'survey-jquery'

( function ( $ ) {
	$( document ).on( 'ready', function () {
		let surveyWrapper = $( '.hts-survey-wrapper' );
		if ( surveyWrapper.length ) {
			const nonce = document.getElementById( 'get_questions_nonce' ).value;
			$.ajax( {
				url: ajaxurl,
				method: 'POST',
				data: {
					action: 'hostinger_get_survey',
					nonce: nonce,
				},
				dataType: 'json',
				success: function ( data ) {

					let questionsCount = $( '#hts-questionsLeft' );
					surveyWrapper.show();
					const survey = new Survey.Model( data );
					survey.focusFirstQuestionAutomatic = false;
					survey.render( "hostinger-feedback-survey" );
					survey.onComplete.add( onSurveyComplete );
					survey.onCurrentPageChanged.add( onPageChanged ); // Add this line
					survey.render( "surveyElement" );

					let answeredQuestions = 0;
					let totalQuestions = survey.getAllQuestions().length;
					if ( totalQuestions >= 2 ) {
						questionsCount.show()
						$( "#hts-allQuestions" ).html( totalQuestions );
					}

					function updateQuestionsLeft () {
						var remaining = answeredQuestions + 1;
						document.getElementById( "hts-currentQuestion" ).textContent = remaining;
					}

					function onPageChanged ( sender, options ) {
						if ( options.isNextPage || options.isPrevPage ) {
							answeredQuestions = survey.currentPageNo;
							updateQuestionsLeft();
						}
					}

					function onSurveyComplete ( sender ) {
						const results = JSON.stringify( sender.data );
						$( '#hts-questionsLeft' ).remove();
						hostinger_submit_survey( results );
					}
					updateQuestionsLeft();

				},
				error: function ( xhr, status, error ) {
					console.log( 'AJAX request failed: ' + error );
				}
			} );
		}

		function hostinger_submit_survey ( survey_answers ) {
			const nonce = document.getElementById( 'submit_questions_nonce' ).value;
			$.ajax( {
				url: ajaxurl,
				method: 'POST',
				data: {
					action: 'hostinger_submit_survey',
					nonce: nonce,
					survey_results: survey_answers
				},
				dataType: 'json',
				success: function ( data ) {

				},
				error: function ( xhr, status, error ) {
					console.log( 'AJAX request failed: ' + error );
				}
			} );
		}

	} );

} )( jQuery );
