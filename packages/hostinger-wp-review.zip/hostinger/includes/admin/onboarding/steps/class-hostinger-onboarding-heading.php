<?php

class Hostinger_Onboarding_Heading extends Hostinger_Onboarding_Step {
	public function get_title(): string {
		return esc_html__( 'Edit site title', 'hostinger' );
	}

	public function get_body(): array {
		return [
			[
				'title'       => esc_html__( 'Go to the Customize page', 'hostinger' ),
				'description' => esc_html__( 'In the left sidebar, click Appearance to expand the menu. In the Appearance section, click Customize. The Customize page will open.', 'hostinger' )
			],
			[
				'title'       => esc_html__( 'Access the Site identity and edit title', 'hostinger' ),
				'description' => esc_html__( 'In the left sidebar, click Site Identity and edit your site title.', 'hostinger' ),
			],
		];
	}

	public function step_identifier(): string {
		return 'edit_site_title';
	}

	public function get_redirect_link(): string {
		return admin_url( 'customize.php' );
	}
}
