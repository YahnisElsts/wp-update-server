<?php

namespace Hostinger\EasyOnboarding;

use Hostinger\EasyOnboarding\Loader;
use Hostinger\EasyOnboarding\Helper;
use Hostinger\EasyOnboarding\Settings;
use Hostinger\EasyOnboarding\I18n;
use Hostinger\EasyOnboarding\Config;
use Hostinger\EasyOnboarding\Updates;
use Hostinger\EasyOnboarding\Admin\Surveys;
use Hostinger\EasyOnboarding\Admin\Assets as AdminAssets;
use Hostinger\EasyOnboarding\Admin\Hooks as AdminHooks;
use Hostinger\EasyOnboarding\Admin\Menu as AdminMenu;
use Hostinger\EasyOnboarding\Admin\Ajax as AdminAjax;
use Hostinger\EasyOnboarding\Admin\Redirects as AdminRedirects;
use Hostinger\EasyOnboarding\Preview\Assets as PreviewAssets;
use Hostinger\EasyOnboarding\Admin\Onboarding\Settings as OnboardingSettings;
use Hostinger\EasyOnboarding\Admin\Onboarding\AutocompleteSteps;
use Hostinger\Surveys\SurveyManager;

defined( 'ABSPATH' ) || exit;

class Bootstrap {
	protected Loader $loader;

	public function __construct() {
		$this->loader = new Loader();
	}

	public function run(): void {
		$this->load_dependencies();
		$this->set_locale();
		$this->loader->run();
	}

	private function load_dependencies(): void {
		$this->load_onboarding_dependencies();
		$this->load_public_dependencies();


		if ( is_admin() ) {
			$this->load_admin_dependencies();
		}
	}

	private function set_locale() {
		$plugin_i18n = new I18n();
		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}

	private function load_admin_dependencies(): void {
		new Updates();
		new AdminAssets();
		new AdminHooks();
		new AdminMenu();
		new AdminAjax();
		new AdminRedirects();
		if ( class_exists( SurveyManager::class ) ) {
			$surveys = new Surveys();
			$surveys->init();
		}
	}

	private function load_public_dependencies(): void {
		new PreviewAssets();
		new Hooks();
	}

	private function load_onboarding_dependencies(): void {
		if ( ! OnboardingSettings::all_steps_completed() ) {
			new AutocompleteSteps();
		}
	}
}
