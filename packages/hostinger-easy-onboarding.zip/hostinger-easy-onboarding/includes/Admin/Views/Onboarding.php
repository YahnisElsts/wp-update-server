<?php

use Hostinger\WpMenuManager\Menus;

echo Menus::renderMenuNavigation();
echo 'Hello, World!';
