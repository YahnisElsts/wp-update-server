<?php

namespace Hostinger\EasyOnboarding\AmplitudeEvents;

defined( 'ABSPATH' ) || exit;

class Actions {
	public const WOO_ITEM_COMPLETED    = 'wordpress.woocommerce.item_completed';
}
