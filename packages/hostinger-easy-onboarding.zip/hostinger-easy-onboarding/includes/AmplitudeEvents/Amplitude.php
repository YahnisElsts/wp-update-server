<?php

namespace Hostinger\EasyOnboarding\AmplitudeEvents;

defined( 'ABSPATH' ) || exit;

use Hostinger\Amplitude\AmplitudeManager;
use Hostinger\EasyOnboarding\AmplitudeEvents\Actions as AmplitudeActions;
use Hostinger\WpHelper\Utils;
use Hostinger\WpHelper\Utils as Helper;
use Hostinger\WpHelper\Requests\Client;
use Hostinger\WpHelper\Config;
use Hostinger\WpHelper\Constants;

class Amplitude {
    public const WEBSITE_BUILDER_TYPE = 'ai';
    /**
     * @var Helper
     */
    private Helper $helper;

    /**
     * @var Client
     */
    private Client $client;

    /**
     * @var Config
     */
    private Config $configHandler;

    public function __construct()
    {
        $this->helper          = new Helper();
        $this->configHandler   = new Config();
        $this->client          = new Client(
            $this->configHandler->getConfigValue( 'base_rest_uri', Constants::HOSTINGER_REST_URI ),
            array(
                Config::TOKEN_HEADER  => Helper::getApiToken(),
                Config::DOMAIN_HEADER => $this->helper->getHostInfo()
            )
        );
    }

    /**
     * @param $params
     *
     * @return array
     */
    public function send_event( array $params ): array
    {
        $amplitudeManger = new AmplitudeManager( $this->helper, $this->configHandler, $this->client );

        return $amplitudeManger->sendRequest( $amplitudeManger::AMPLITUDE_ENDPOINT, $params );
    }

    public function send_edit_amplitude_event(): void
    {
        $edit_count = $this->increment_amplitude_edit_event_count();

        $params = array(
            'action' => AmplitudeActions::WP_EDIT,
            'wp_builder_type' => Utils::getSetting('builder_type'),
            'website_id' => Utils::getSetting('website_id'),
            'edit_count' => $edit_count,
        );

        $this->send_event($params);
    }

    public function can_send_edit_amplitude_event(): bool
    {
        $today = date('Y-m-d');
        $event_data              = get_option('hostinger_amplitude_event_data', []);
        $isAiWebsiteNotGenerated = ! get_option('hostinger_ai_version', '');
        $websiteBuilderType      = get_option('hostinger_builder_type', '');

        // If specific conditions are met, stop further processing
        if ($websiteBuilderType == self::WEBSITE_BUILDER_TYPE && $isAiWebsiteNotGenerated) {
            return false;
        }

        // If no event data exists or it's not an array, initialize it for today
        if (!is_array($event_data)) {
            $event_data = [];
        }

        // Always reset the event data to only store today's data
        $event_data = [
            $today => [
                'count' => $event_data[$today]['count'] ?? 0,
                'last_reset' => current_time('timestamp')
            ]
        ];

        // Check if the count for today is less than 3
        if ($event_data[$today]['count'] < 3) {
            $event_data[$today]['count'] += 1;

            update_option('hostinger_amplitude_event_data', $event_data);

            if (has_action('litespeed_purge_all')) {
                do_action('litespeed_purge_all');
            }

            return true;
        }

        // Limit reached for today
        return false;
    }

    public function increment_amplitude_edit_event_count(): int
    {
        $option_name = 'hostinger_amplitude_edit_count';
        $edit_count = (int)get_option($option_name, 0);
        $edit_count++;

        update_option($option_name, $edit_count);

        return $edit_count;
    }
}
