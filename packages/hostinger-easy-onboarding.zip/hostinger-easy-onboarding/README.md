# Hostinger wordpress plugin

## CLI Commands

== Usage ==

## Build Commands

### Install packages
$ npm install

### Compiling Assets
$ npm run prod
