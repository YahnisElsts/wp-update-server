Changelog
=========
1.0.2 (2023-11-28)
- MVP version of the plugin

1.0.3 (2023-11-30)
- Fixed binding / product group item info sync from Amazon API
- Added different text label for 'Prime Videos' type items
- Added translations
- Added amplitude events

1.0.4 (2023-12-07)
- Added feature to overwrite title and description
- Added feature to limit title, description and description items

1.0.5 (2024-01-09)
- Lists functionality
- Table list page in admin

1.0.6 (2024-01-10)
- Multiple products selector in lists view
- Fatal error fix on plugin first install

1.0.7 (2024-01-24)
- Table creation and edit in admin added
- Added table selector in gutenberg block
- UI fixes

1.0.8 (2024-01-30)
- Scheduled job for product update in DB
- Internal testing UI fixes

1.0.9 (2024-02-08)
- Removed 'Reconnect' dropdown option from Amazon API status card
- Responsive fixes
- Affiliate dashboard URL corrections
- Amazon connected to display corrections (display name -> partner id)
- Site editor incompatibility message added
- UI changes to table creation/edit view
- Translations