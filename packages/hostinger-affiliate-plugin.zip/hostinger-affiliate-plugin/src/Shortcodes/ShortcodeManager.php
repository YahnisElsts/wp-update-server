<?php
/**
 * ShortcodeManager class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Shortcodes;

use Hostinger\AffiliatePlugin\Repositories\Product as ProductRepository;
use Hostinger\AffiliatePlugin\Amplitude\Actions as AmplitudeActions;
use Hostinger\AffiliatePlugin\Localization\Messages;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * ShortcodeManager class
 */
class ShortcodeManager {

	/**
	 * @var array
	 */
	private array $atts = array();

	/**
	 * @param array $atts attributes.
	 */
	public function __construct( array $atts ) {
		$this->atts = $atts;
	}

	/**
	 * @return array
	 */
	public function get_atts(): array {
		return $this->atts;
	}

	/**
	 * @param array $atts attributes.
	 */
	public function set_atts( array $atts ): void {
		$this->atts = $atts;
	}

	/**
	 * @return string
	 */
	public function render_shortcode(): string {
		global $wpdb;

		$product_repository = new ProductRepository( $wpdb );

		$asin         = ! empty( $this->atts['asin'] ) ? $product_repository->clean_asin( $this->atts['asin'] ) : '';
		$display_type = ! empty( $this->atts['display_type'] ) ? $this->atts['display_type'] : '';

		if ( empty( $display_type ) ) {
			return __( 'Please choose display type!', 'hostinger-affiliate-plugin' );
		}

		if ( ! in_array( $display_type, AmplitudeActions::AFFILIATE_ALLOWED_LAYOUTS, true ) ) {
			return Messages::get_unknown_layout_message();
		}

		if ( empty( $asin ) ) {
			return __( 'Please enter product(-s) ASIN(-s)!', 'hostinger-affiliate-plugin' );
		}

		try {
			$products = $product_repository->pull_products( $asin, $display_type );
		} catch ( \Exception $e ) {
			return $e->getMessage();
		}

		$this->atts['products'] = $products;

		$shortcode = null;

		switch ( $display_type ) {
			case AmplitudeActions::AFFILIATE_SINGLE_LAYOUT:
				$shortcode = new ProductCardShortcode( $this );
				break;
			case AmplitudeActions::AFFILIATE_LIST_LAYOUT:
				$shortcode = new ProductListShortcode( $this );
				break;
			case AmplitudeActions::AFFILIATE_TABLE_LAYOUT:
				$shortcode = new ProductTableShortcode( $this );
				break;
		}

		return ! empty( $shortcode ) ? $shortcode->render() : '';
	}

	/**
	 * @param string $text_string string to limit.
	 * @param int    $limit character limit.
	 * @param int    $default_limit default character limit.
	 *
	 * @return string
	 */
	public function limit_string( string $text_string, int $limit = 0, int $default_limit ) {
		if ( empty( $limit ) ) {
			$limit = $default_limit;
		}

		return ( mb_strlen( $text_string ) > $limit ) ? mb_substr( $text_string, 0, $limit ) . '...' : $text_string;
	}
}
