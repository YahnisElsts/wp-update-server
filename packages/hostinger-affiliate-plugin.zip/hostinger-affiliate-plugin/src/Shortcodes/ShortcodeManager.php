<?php
/**
 * ShortcodeManager class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Shortcodes;

use Hostinger\AffiliatePlugin\Models\Product;
use Hostinger\AffiliatePlugin\Repositories\ListRepository;
use Hostinger\AffiliatePlugin\Repositories\ProductRepository;
use Hostinger\AffiliatePlugin\Amplitude\Actions as AmplitudeActions;
use Hostinger\AffiliatePlugin\Localization\Messages;
use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * ShortcodeManager class
 */
class ShortcodeManager {
	/**
	 * @var array
	 */
	private array $atts = array();

	/**
	 * @var AmazonClient
	 */
	private AmazonClient $amazon_client;

	/**
	 * @var AmplitudeEvents
	 */
	private AmplitudeEvents $amplitude_events;

	/**
	 * @var ProductRepository
	 */
	private ProductRepository $product_repository;

	/**
	 * @var ListRepository
	 */
	private ListRepository $list_repository;

	/**
	 * @param array             $atts attributes.
	 * @param AmazonClient      $amazon_client amazon client instance.
	 * @param AmplitudeEvents   $amplitude_events amplitude events instance.
	 * @param ProductRepository $product_repository product repo instance.
	 * @param ListRepository    $list_repository list repo instance.
	 */
	public function __construct( array $atts, AmazonClient $amazon_client, AmplitudeEvents $amplitude_events, ProductRepository $product_repository, ListRepository $list_repository ) {
		$this->atts               = $atts;
		$this->amazon_client      = $amazon_client;
		$this->amplitude_events   = $amplitude_events;
		$this->product_repository = $product_repository;
		$this->list_repository    = $list_repository;
	}

	/**
	 * @return array
	 */
	public function get_atts(): array {
		return $this->atts;
	}

	/**
	 * @param array $atts attributes.
	 */
	public function set_atts( array $atts ): void {
		$this->atts = $atts;
	}

	/**
	 * @return string
	 */
	public function render_shortcode(): string {
		$display_type = ! empty( $this->atts['display_type'] ) ? sanitize_text_field( $this->atts['display_type'] ) : '';

		if ( empty( $display_type ) ) {
			return __( 'Please choose display type!', 'hostinger-affiliate-plugin' );
		}

		if ( ! in_array( $display_type, AmplitudeActions::AFFILIATE_ALLOWED_LAYOUTS, true ) ) {
			return Messages::get_unknown_layout_message();
		}

		$shortcode = null;

		switch ( $display_type ) {
			case AmplitudeActions::AFFILIATE_SINGLE_LAYOUT:
				$shortcode = new ProductCardShortcode( $this, $this->product_repository, $this->list_repository );
				break;
			case AmplitudeActions::AFFILIATE_LIST_LAYOUT:
				$shortcode = new ProductListShortcode( $this, $this->product_repository, $this->list_repository );
				break;
			case AmplitudeActions::AFFILIATE_TABLE_LAYOUT:
				$shortcode = new ProductTableShortcode( $this, $this->product_repository, $this->list_repository );
				break;
		}

		return ! empty( $shortcode ) ? $shortcode->render() : '';
	}

	/**
	 * @param string $text_string string to limit.
	 * @param int    $limit character limit.
	 * @param int    $default_limit default character limit.
	 *
	 * @return string
	 */
	public function limit_string( string $text_string, int $limit = 0, int $default_limit ): string {
		if ( empty( $limit ) ) {
			$limit = $default_limit;
		}

		return ( mb_strlen( $text_string ) > $limit ) ? mb_substr( $text_string, 0, $limit ) . '...' : $text_string;
	}

	/**
	 * @param array $item_data item data.
	 * @param int   $description_items item count.
	 *
	 * @return string
	 */
	public function render_product_description( array $item_data, int $description_items ): string {
		ob_start();

		?>
		<ul>
			<?php

			if ( ! empty( $item_data['features'] ) ) {
				foreach ( array_slice( $item_data['features'], 0, $description_items ) as $feature ) {
					?>
					<li><?php echo $this->limit_string( $feature, $this->atts['description_length'], 120 ); ?></li>
					<?php
				}
			} else {
				if ( ! empty( $item_data['by_line_info']['contributors'] ) ) {
					foreach ( array_slice( $item_data['by_line_info']['contributors'], 0, $description_items ) as $contributor ) {

						?>
						<li><?php echo $this->limit_string( ! empty( $contributor['name'] ) ? $contributor['name'] : '', $this->atts['description_length'], 120 ); ?></li>
						<?php
					}
				}
			}

			?>
		</ul>
		<?php

		$content = ob_get_contents();

		ob_end_clean();

		return $content;
	}
}