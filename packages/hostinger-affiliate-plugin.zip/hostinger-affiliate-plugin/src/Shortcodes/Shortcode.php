<?php
/**
 * Shortcode class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Shortcodes;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Shortcode class
 */
abstract class Shortcode {

	/**
	 * @var ShortcodeManager
	 */
	protected ShortcodeManager $shortcode_manager;

	/**
	 * @param ShortcodeManager $shortcode_manager shortcode manager object.
	 */
	public function __construct( ShortcodeManager $shortcode_manager ) {
		$this->shortcode_manager = $shortcode_manager;
	}

	/**
	 * @return void
	 */
	abstract public function render(): string;
}
