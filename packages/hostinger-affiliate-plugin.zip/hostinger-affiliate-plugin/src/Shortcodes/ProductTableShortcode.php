<?php
/**
 * Product table class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Shortcodes;

use Hostinger\AffiliatePlugin\Amplitude\Actions;
use Hostinger\AffiliatePlugin\Models\Product;
use Hostinger\AffiliatePlugin\Models\Table\AsinRow;
use Hostinger\AffiliatePlugin\Models\Table\FeatureRow;
use Hostinger\AffiliatePlugin\Repositories\ProductRepository;
use Hostinger\AffiliatePlugin\Repositories\TableRepository;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Product table class
 */
class ProductTableShortcode extends Shortcode {
	/**
	 * @var TableRepository
	 */
	private TableRepository $table_repository;

	/**
	 * @var array
	 */
	private array $products;

	/**
	 * @param ShortcodeManager $shortcode_manager Shortcode manager instance.
	 * @param ProductRepository  $product_repository Product repo instance.
	 * @param TableRepository  $table_repository Table repo instance.
	 */
	public function __construct( ShortcodeManager $shortcode_manager, ProductRepository $product_repository, TableRepository $table_repository ) {
		parent::__construct( $shortcode_manager, $product_repository );

		$this->table_repository = $table_repository;
	}

	/**
	 * @return string
	 */
	public function render(): string {
		$atts = $this->shortcode_manager->get_atts();

		if( empty( $atts['table_id'] ) ) {
			return __( 'Table not found.', 'hostinger-affiliate-plugin' );
		}

		$table = $this->table_repository->get( (int)$atts['table_id'] );

		if ( empty( $table ) ) {
			if ( current_user_can( 'administrator' ) ) {
				return __( 'Table not found or it is not published.', 'hostinger-affiliate-plugin' );
			} else {
				return '';
			}
		}

		$asin_rows = $table->convert_array_items_to_array( $table->get_asin_rows() );

		$asin_rows = array_filter( $asin_rows, function( $item ) {
			return $item['is_enabled'] == 1;
		} );

		$asin = wp_list_pluck( $asin_rows, 'asin' );

		try {
			$this->products = $this->product_repository->pull_products( $asin, Actions::AFFILIATE_TABLE_LAYOUT );
		} catch ( \Exception $e ) {
			return $e->getMessage();
		}

		ob_start();

		require __DIR__ . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'product-table.php';

		$content = ob_get_contents();

		ob_end_clean();

		return $content;
	}

	/**
	 * @param FeatureRow $feature_row
	 * @param AsinRow    $asin_row
	 *
	 * @return string
	 */
	public function render_table_row( FeatureRow $feature_row, AsinRow $asin_row ): string {
		$value = '';

		$asin = $asin_row->get_asin();

		$product = array_filter($this->products, function($product) use ($asin) {
			return ! empty( $product ) && $product->get_asin() == $asin;
		});

		if ( empty ( $product ) ) {
			return '';
		}

		$product = reset($product);

		switch( $feature_row->get_selected_value() ) {
			case 'title':

				$value = '<a href="' . $product->get_url() . '" target="_blank" rel="nofollow noopener noreferrer">' . $this->render_product_title( $product ) . '</a>';

				break;
			case 'thumbnail':
				$value = '<a href="' . $product->get_url() . '" target="_blank" rel="nofollow noopener noreferrer"><img src="' . $product->get_image_url() . '" alt="' . esc_attr( $product->get_title() ) . '"></a>';
				break;
			case 'price':
				$price = $product->get_price();

				if ( ! empty( $price ) ) {
					$value = $this->shortcode_manager->render_price( $product );
				}
				break;
			case 'prime_status':
				if ( ! empty( $product->get_is_prime() ) ) {
					$value = '<img src="' . HOSTINGER_AFFILIATE_PLUGIN_URL . 'assets/img/prime.png' . '" alt="' . __( 'Is prime', 'hostinger-affiliate-plugin' ) . '">';
				} else {
					$value = __( 'N/A', 'hostinger-affilaite-plugin' );
				}
				break;
			case 'amazon_button':

				ob_start();

				?>
				<a href="<?php echo $product->get_url(); ?>" target="_blank" target="_blank" rel="nofollow noopener noreferrer">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<g clip-path="url(#clip0_2104_11808)">
							<path d="M17.2188 16.147C9.12286 20 4.09841 16.7763 0.882107 14.8183C0.683083 14.6949 0.344812 14.8472 0.638308 15.1843C1.70982 16.4835 5.22139 19.615 9.80502 19.615C14.3918 19.615 17.1205 17.1123 17.4619 16.6757C17.8009 16.2428 17.5614 16.004 17.2187 16.147H17.2188ZM19.4926 14.8913C19.2751 14.6082 18.1706 14.5554 17.4754 14.6408C16.7792 14.7238 15.7341 15.1493 15.825 15.4048C15.8716 15.5005 15.9668 15.4575 16.445 15.4145C16.9246 15.3667 18.2682 15.1971 18.5481 15.5631C18.8294 15.9316 18.1196 17.687 17.99 17.9701C17.8647 18.2533 18.0378 18.3263 18.2731 18.1377C18.5051 17.9492 18.9252 17.4611 19.2071 16.7703C19.487 16.0758 19.6578 15.1069 19.4926 14.8913Z" fill="#FF9900"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M11.7752 8.28499C11.7752 9.29595 11.8007 10.1391 11.2898 11.0369C10.8773 11.7669 10.224 12.2158 9.49408 12.2158C8.49766 12.2158 7.91736 11.4566 7.91736 10.3362C7.91736 8.12435 9.89913 7.72292 11.7752 7.72292V8.28499ZM14.3921 14.61C14.2205 14.7633 13.9723 14.7743 13.7789 14.6721C12.9176 13.9567 12.7642 13.6246 12.2898 12.9421C10.8664 14.3947 9.85905 14.829 8.01229 14.829C5.82972 14.829 4.12891 13.4822 4.12891 10.7851C4.12891 8.67919 5.27135 7.24479 6.89539 6.54409C8.30425 5.92355 10.2715 5.81408 11.7752 5.6426V5.30679C11.7752 4.68994 11.8226 3.96001 11.4613 3.42718C11.1437 2.94904 10.5379 2.75194 10.005 2.75194C9.01595 2.75194 8.13269 3.25923 7.91736 4.31036C7.87351 4.544 7.70202 4.77395 7.46846 4.78488L4.95008 4.51485C4.73844 4.4673 4.50487 4.29582 4.56327 3.97094C5.14357 0.919802 7.89905 0 10.3663 0C11.6291 0 13.2788 0.335809 14.2752 1.29208C15.538 2.47091 15.4176 4.04394 15.4176 5.75569V9.79963C15.4176 11.015 15.9212 11.5478 16.3957 12.2048C16.5635 12.4384 16.6001 12.7195 16.3884 12.8946C15.8591 13.3362 14.9175 14.1575 14.3993 14.6174L14.392 14.61" fill="black"/>
							<path d="M17.2188 16.147C9.12286 20 4.09841 16.7763 0.882107 14.8183C0.683083 14.6949 0.344812 14.8472 0.638308 15.1843C1.70982 16.4835 5.22139 19.615 9.80502 19.615C14.3918 19.615 17.1205 17.1123 17.4619 16.6757C17.8009 16.2428 17.5614 16.004 17.2187 16.147H17.2188ZM19.4926 14.8913C19.2751 14.6082 18.1706 14.5554 17.4754 14.6408C16.7792 14.7238 15.7341 15.1493 15.825 15.4048C15.8716 15.5005 15.9668 15.4575 16.445 15.4145C16.9246 15.3667 18.2682 15.1971 18.5481 15.5631C18.8294 15.9316 18.1196 17.687 17.99 17.9701C17.8647 18.2533 18.0378 18.3263 18.2731 18.1377C18.5051 17.9492 18.9252 17.4611 19.2071 16.7703C19.487 16.0758 19.6578 15.1069 19.4926 14.8913Z" fill="#FF9900"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M11.7752 8.28499C11.7752 9.29595 11.8007 10.1391 11.2898 11.0369C10.8773 11.7669 10.224 12.2158 9.49408 12.2158C8.49766 12.2158 7.91736 11.4566 7.91736 10.3362C7.91736 8.12435 9.89913 7.72292 11.7752 7.72292V8.28499ZM14.3921 14.61C14.2205 14.7633 13.9723 14.7743 13.7789 14.6721C12.9176 13.9567 12.7642 13.6246 12.2898 12.9421C10.8664 14.3947 9.85905 14.829 8.01229 14.829C5.82972 14.829 4.12891 13.4822 4.12891 10.7851C4.12891 8.67919 5.27135 7.24479 6.89539 6.54409C8.30425 5.92355 10.2715 5.81408 11.7752 5.6426V5.30679C11.7752 4.68994 11.8226 3.96001 11.4613 3.42718C11.1437 2.94904 10.5379 2.75194 10.005 2.75194C9.01595 2.75194 8.13269 3.25923 7.91736 4.31036C7.87351 4.544 7.70202 4.77395 7.46846 4.78488L4.95008 4.51485C4.73844 4.4673 4.50487 4.29582 4.56327 3.97094C5.14357 0.919802 7.89905 0 10.3663 0C11.6291 0 13.2788 0.335809 14.2752 1.29208C15.538 2.47091 15.4176 4.04394 15.4176 5.75569V9.79963C15.4176 11.015 15.9212 11.5478 16.3957 12.2048C16.5635 12.4384 16.6001 12.7195 16.3884 12.8946C15.8591 13.3362 14.9175 14.1575 14.3993 14.6174L14.392 14.61" fill="black"/>
						</g>
						<defs>
							<clipPath id="clip0_2104_11808">
								<rect width="20" height="20" fill="white"/>
							</clipPath>
						</defs>
					</svg>

					<?php echo $product->buy_button_title(); ?>
				</a>
				<?php

				$value = ob_get_contents();

				ob_end_clean();

				break;
		}

		return $value;
	}

	/**
	 * @param AsinRow $asin_row
	 *
	 * @return string
	 */
	public function prepare_row_colors( AsinRow $asin_row ): string {

		$color = $asin_row->get_color();

		if ( ! empty ( $color ) ) {
			return 'style="background: '.$color.'; color: '.$this->inverse_color( $color ).' !important"';
		}

		return '';
	}

	/**
	 * @param $value
	 *
	 * @return string
	 */
	public function format_selected_value( $value ): string {
		return str_replace( '_', '-', $value );
	}

	/**
	 * @param Product $product product object.
	 *
	 * @return string
	 */
	public function render_product_title( Product $product ): string {
		$atts = $this->shortcode_manager->get_atts();

		$length = ! empty( $atts['title_length'] ) ? (int) $atts['title_length'] : 0;

		return $this->shortcode_manager->limit_string( $product->get_title(), $length, 65 );
	}

	/**
	 * @param $hex_color
	 *
	 * @return string
	 */
	private function inverse_color( $hex_color ): string {
		$hex_color = str_replace('#', '', $hex_color);

		$r = hexdec(substr($hex_color, 0, 2));
		$g = hexdec(substr($hex_color, 2, 2));
		$b = hexdec(substr($hex_color, 4, 2));

		$inverse_r = 255 - $r;
		$inverse_g = 255 - $g;
		$inverse_b = 255 - $b;

		return sprintf("#%02x%02x%02x", $inverse_r, $inverse_g, $inverse_b);
	}
}
