<?php
/**
 * Shortcode class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Shortcodes;

use Hostinger\AffiliatePlugin\Shortcodes\ShortcodeManager;
use Hostinger\AffiliatePlugin\Models\Product;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Shortcode class
 */
class ProductCardShortcode extends Shortcode {
	/**
	 * @param ShortcodeManager $shortcode_manager Shortcode manager object.
	 */
	public function __construct( ShortcodeManager $shortcode_manager ) {
		parent::__construct( $shortcode_manager );
	}

	/**
	 * @param Product $product product object.
	 *
	 * @return string
	 */
	public function render_product_title( Product $product ): string {
		$atts = $this->shortcode_manager->get_atts();

		if ( ! empty( $atts['title_overwrite_enabled'] ) ) {
			return $atts['title_overwrite'];
		}

		$length = ! empty( $atts['title_length'] ) ? (int) $atts['title_length'] : 0;

		return $this->shortcode_manager->limit_string( $product->get_title(), $length, 65 );
	}

	/**
	 * @param Product $product product.
	 *
	 * @return string
	 */
	public function render_product_description( Product $product ): string {
		$atts = $this->shortcode_manager->get_atts();

		if ( ! empty( $atts['description_overwrite_enabled'] ) ) {
			return '<p>' . $atts['description_overwrite'] . '</p>';
		}

		$description = '<ul>';

		$item_data = $product->get_item_data();

		$description_items = ! empty( $atts['description_items'] ) ? (int) $atts['description_items'] : '';

		ob_start();

		?>
		<ul>
			<?php

			if ( ! empty( $item_data['features'] ) ) {
				foreach ( array_slice( $item_data['features'], 0, $description_items ) as $feature ) {
					?>
					<li><?php echo $this->shortcode_manager->limit_string( $feature, $atts['description_length'], 120 ); ?></li>
					<?php
				}
			} else {
				if ( ! empty( $item_data['by_line_info']['contributors'] ) ) {
					foreach ( array_slice( $item_data['by_line_info']['contributors'], 0, $description_items ) as $contributor ) {

						?>
						<li><?php echo $this->shortcode_manager->limit_string( ! empty( $contributor['name'] ) ? $contributor['name'] : '', $atts['description_length'], 120 ); ?></li>
						<?php
					}
				}
			}
			?>
		</ul>
		<?php

		$description = ob_get_contents();

		ob_end_clean();

		return $description;
	}

	/**
	 * @return string
	 */
	public function render(): string {
		$atts = $this->shortcode_manager->get_atts();

		if ( empty( $atts['products'] ) ) {
			return __( 'Products not fetched from DB and/or API. Please check debug logs.', 'hostinger-affiliate-plugin' );
		}

		ob_start();

		require __DIR__ . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'product-card.php';

		$content = ob_get_contents();

		ob_end_clean();

		return $content;
	}
}
