<?php
/**
 * Product class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Models;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Product class
 */
class Product {
	/**
	 * @var int
	 */
	private int $id = 0;

	/**
	 * @var string
	 */
	private string $asin;

	/**
	 * @var string
	 */
	private string $title;

	/**
	 * @var string
	 */
	private string $url;

	/**
	 * @var string
	 */
	private string $image_url;

	/**
	 * @var string
	 */
	private string $thumbnail;

	/**
	 * @var array
	 */
	private array $item_data = array();

	/**
	 * @var string
	 */
	private string $currency = '';

	/**
	 * @var float
	 */
	private float $price = 0;

	/**
	 * @var bool
	 */
	private bool $is_prime = false;

	/**
	 * @var bool
	 */
	private bool $is_free_shipping = false;

	/**
	 * @var float|int
	 */
	private float $rating = 0;

	/**
	 * @var int
	 */
	private int $reviews = 0;

	/**
	 * @var string
	 */
	private string $created_at;

	/**
	 * @var string
	 */
	private string $updated_at = '';

	/**
	 * @param array $db_array fields from database.
	 */
	public function __construct( array $db_array = array() ) {
		if ( isset( $db_array['id'] ) ) {
			$this->set_id( $db_array['id'] );
		}

		if ( isset( $db_array['asin'] ) ) {
			$this->set_asin( $db_array['asin'] );
		}

		if ( isset( $db_array['title'] ) ) {
			$this->set_title( $db_array['title'] );
		}

		if ( isset( $db_array['url'] ) ) {
			$this->set_url( $db_array['url'] );
		}

		if ( isset( $db_array['image_url'] ) ) {
			$this->set_image_url( $db_array['image_url'] );
		}

		if ( isset( $db_array['item_data'] ) ) {
			$this->set_item_data( json_decode( $db_array['item_data'], true ) );
		}

		if ( isset( $db_array['currency'] ) ) {
			$this->set_currency( $db_array['currency'] );
		}

		if ( isset( $db_array['price'] ) ) {
			$this->set_price( $db_array['price'] );
		}

		if ( isset( $db_array['is_prime'] ) ) {
			$this->set_is_prime( $db_array['is_prime'] );
		}

		if ( isset( $db_array['is_free_shipping'] ) ) {
			$this->set_is_free_shipping( $db_array['is_free_shipping'] );
		}

		if ( isset( $db_array['rating'] ) ) {
			$this->set_rating( $db_array['rating'] );
		}

		if ( isset( $db_array['reviews'] ) ) {
			$this->set_reviews( $db_array['reviews'] );
		}

		if ( isset( $db_array['created_at'] ) ) {
			$this->set_created_at( $db_array['created_at'] );
		}

		if ( isset( $db_array['updated_at'] ) ) {
			$this->set_updated_at( $db_array['updated_at'] );
		}
	}

	/**
	 * @param array $data item data array from API.
	 *
	 * @return Product
	 */
	public static function create_from_api( array $data ): Product {
		$product = new self();

		if ( ! empty( $data['ASIN'] ) ) {
			$product->set_asin( $data['ASIN'] );
		}

		if ( ! empty( $data['ItemInfo']['Title']['DisplayValue'] ) ) {
			$product->set_title( $data['ItemInfo']['Title']['DisplayValue'] );
		}

		if ( ! empty( $data['DetailPageURL'] ) ) {
			$product->set_url( $data['DetailPageURL'] );
		}

		if ( ! empty( $data['Images']['Primary']['Large']['URL'] ) ) {
			$product->set_image_url( $data['Images']['Primary']['Large']['URL'] );
		}

		if ( ! empty( $data['Images']['Primary']['Small']['URL'] ) ) {
			$product->set_thumbnail_url( $data['Images']['Primary']['Small']['URL'] );
		}

		$product->set_item_data( $product->format_item_data( $data ) );

		if ( ! empty( $data['Offers']['Listings'][0]['Price']['Currency'] ) ) {
			$product->set_currency( $data['Offers']['Listings'][0]['Price']['Currency'] );
		}

		if ( ! empty( $data['Offers']['Listings'][0]['Price']['Amount'] ) ) {
			$product->set_price( $data['Offers']['Listings'][0]['Price']['Amount'] );
		}

		if ( ! empty( $data['Offers']['Listings'][0]['DeliveryInfo']['IsPrimeEligible'] ) ) {
			$product->set_is_prime( $data['Offers']['Listings'][0]['DeliveryInfo']['IsPrimeEligible'] );
		}

		if ( ! empty( $data['Offers']['Listings'][0]['DeliveryInfo']['IsFreeShippingEligible'] ) ) {
			$product->set_is_free_shipping( $data['Offers']['Listings'][0]['DeliveryInfo']['IsFreeShippingEligible'] );
		}

		$product->created_at = gmdate( 'Y-m-d H:i:s' );

		return $product;
	}

	/**
	 * @return int
	 */
	public function get_id(): int {
		return $this->id;
	}

	/**
	 * @param int $id product id.
	 */
	public function set_id( int $id ): void {
		$this->id = $id;
	}

	/**
	 * @return string
	 */
	public function get_asin(): string {
		return $this->asin;
	}

	/**
	 * @param string $asin product asin.
	 */
	public function set_asin( string $asin ): void {
		$this->asin = $asin;
	}

	/**
	 * @return string
	 */
	public function get_title(): string {
		return $this->title;
	}

	/**
	 * @param string $title product title.
	 */
	public function set_title( string $title ): void {
		$this->title = $title;
	}

	/**
	 * @return string
	 */
	public function get_url(): string {
		return $this->url;
	}

	/**
	 * @param string $url product url.
	 */
	public function set_url( string $url ): void {
		$this->url = $url;
	}

	/**
	 * @return array
	 */
	public function get_item_data(): array {
		return $this->item_data;
	}

	/**
	 * @param array $item_data product item data.
	 */
	public function set_item_data( array $item_data ): void {
		$this->item_data = $item_data;
	}

	/**
	 * @return string
	 */
	public function get_image_url(): string {
		return $this->image_url;
	}

	/**
	 * @param string $image_url product primary image url.
	 */
	public function set_image_url( string $image_url ): void {
		$this->image_url = $image_url;
	}

	/**
	 * @return string
	 */
	public function get_thumbnail_url(): string {
		return $this->thumbnail;
	}

	/**
	 * @param string $thumbnail product primary image url.
	 */
	public function set_thumbnail_url( string $thumbnail ): void {
		$this->thumbnail = $thumbnail;
	}

	/**
	 * @return string
	 */
	public function get_currency(): string {
		return $this->currency;
	}

	/**
	 * @param string $currency product price currency.
	 */
	public function set_currency( string $currency ): void {
		$this->currency = $currency;
	}

	/**
	 * @return float
	 */
	public function get_price(): float {
		return $this->price;
	}

	/**
	 * @param float $price product price.
	 */
	public function set_price( float $price ): void {
		$this->price = $price;
	}

	/**
	 * @return bool
	 */
	public function get_is_prime(): bool {
		return $this->is_prime;
	}

	/**
	 * @param bool $is_prime is product prime eligible.
	 */
	public function set_is_prime( bool $is_prime ): void {
		$this->is_prime = $is_prime;
	}

	/**
	 * @return bool
	 */
	public function get_is_free_shipping(): bool {
		return $this->is_free_shipping;
	}

	/**
	 * @param bool $is_free_shipping does product have free shipping.
	 */
	public function set_is_free_shipping( bool $is_free_shipping ): void {
		$this->is_free_shipping = $is_free_shipping;
	}

	/**
	 * @return float
	 */
	public function get_rating(): float {
		return $this->rating;
	}

	/**
	 * @param float $rating product rating.
	 */
	public function set_rating( float $rating ): void {
		$this->rating = $rating;
	}

	/**
	 * @return int
	 */
	public function get_reviews(): int {
		return $this->reviews;
	}

	/**
	 * @param int $reviews product review count.
	 */
	public function set_reviews( int $reviews ): void {
		$this->reviews = $reviews;
	}

	/**
	 * @return string
	 */
	public function get_created_at(): string {
		return $this->created_at;
	}

	/**
	 * @param string $created_at created at date.
	 */
	public function set_created_at( string $created_at ): void {
		$this->created_at = $created_at;
	}

	/**
	 * @return string
	 */
	public function get_updated_at(): string {
		return $this->updated_at;
	}

	/**
	 * @param string $updated_at updated at date.
	 */
	public function set_updated_at( string $updated_at ): void {
		$this->updated_at = $updated_at;
	}

	/**
	 * @param array $data product api data.
	 *
	 * @return array
	 */
	public function format_item_data( array $data ): array {
		$formatted_data = array();

		$by_line_info = array();

		if ( ! empty( $data['ItemInfo']['ByLineInfo']['Brand']['DisplayValue'] ) ) {
			$by_line_info['brand'] = $data['ItemInfo']['ByLineInfo']['Brand']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ByLineInfo']['Manufacturer']['DisplayValue'] ) ) {
			$by_line_info['manufacturer'] = $data['ItemInfo']['ByLineInfo']['Manufacturer']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ByLineInfo']['Contributors'] ) ) {
			$contributors = array();

			foreach ( $data['ItemInfo']['ByLineInfo']['Contributors'] as $contributor ) {
				$contributors[] = array(
					'name'     => ( ! empty( $contributor['Name'] ) ) ? $contributor['Name'] : '',
					'role'     => ( ! empty( $contributor['Role'] ) ) ? $contributor['Role'] : '',
					'roleType' => ( ! empty( $contributor['RoleType'] ) ) ? $contributor['RoleType'] : '',
				);
			}

			$by_line_info['contributors'] = $contributors;
		}

		if ( ! empty( $by_line_info ) ) {
			$formatted_data['by_line_info'] = $by_line_info;
		}

		if ( ! empty( $data['ItemInfo']['ContentRating']['AudienceRating']['DisplayValue'] ) ) {
			$formatted_data['audience_rating'] = $data['ItemInfo']['ContentRating']['AudienceRating']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['Classifications']['Binding']['DisplayValue'] ) ) {
			$formatted_data['binding'] = $data['ItemInfo']['Classifications']['Binding']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['Classifications']['ProductGroup']['DisplayValue'] ) ) {
			$formatted_data['product_group'] = $data['ItemInfo']['Classifications']['ProductGroup']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['Features']['DisplayValues'] ) ) {
			$features = array();

			foreach ( $data['ItemInfo']['Features']['DisplayValues'] as $feature ) {
				$features[] = $feature;
			}

			$formatted_data['features'] = $features;
		}

		if ( ! empty( $data['ItemInfo']['ContentInfo']['Edition']['DisplayValue'] ) ) {
			$formatted_data['edition'] = $data['ItemInfo']['ContentInfo']['Edition']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ContentInfo']['Languages']['DisplayValues'] ) ) {
			$languages = array();

			foreach ( $data['ItemInfo']['ContentInfo']['Languages']['DisplayValues'] as $language ) {
				$languages[] = array(
					'value' => ( ! empty( $language['DisplayValue'] ) ) ? $language['DisplayValue'] : '',
					'type'  => ( ! empty( $language['Type'] ) ) ? $language['Type'] : '',
				);
			}

			$formatted_data['languages'] = $languages;
		}

		if ( ! empty( $data['ItemInfo']['ContentInfo']['PagesCount']['DisplayValue'] ) ) {
			$formatted_data['pages_count'] = $data['ItemInfo']['ContentInfo']['PagesCount']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ContentInfo']['PublicationDate']['DisplayValue'] ) ) {
			$formatted_data['publication_date'] = $data['ItemInfo']['ContentInfo']['PublicationDate']['DisplayValue'];
		}

		$manufacture_info = array();

		if ( ! empty( $data['ItemInfo']['ManufactureInfo']['ItemPartNumber']['DisplayValue'] ) ) {
			$manufacture_info['item_part_number'] = $data['ItemInfo']['ManufactureInfo']['ItemPartNumber']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ManufactureInfo']['Model']['DisplayValue'] ) ) {
			$manufacture_info['model'] = $data['ItemInfo']['ManufactureInfo']['Model']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ManufactureInfo']['Warranty']['DisplayValue'] ) ) {
			$manufacture_info['warranty'] = $data['ItemInfo']['ManufactureInfo']['Warranty']['DisplayValue'];
		}

		if ( ! empty( $manufacture_info ) ) {
			$formatted_data['manufacture_info'] = $manufacture_info;
		}

		$product_info = array();

		if ( ! empty( $data['ItemInfo']['ProductInfo']['Color']['DisplayValue'] ) ) {
			$product_info['color'] = $data['ItemInfo']['ProductInfo']['Color']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ProductInfo']['IsAdultProduct']['DisplayValue'] ) ) {
			$product_info['is_adult_product'] = $data['ItemInfo']['ProductInfo']['IsAdultProduct']['DisplayValue'];
		}

		$item_dimensions = array();

		$possible_item_dimension_keys = array(
			'Height',
			'Length',
			'Weight',
			'Width',
		);

		foreach ( $possible_item_dimension_keys as $key ) {
			if ( ! empty( $data['ItemInfo']['ProductInfo']['ItemDimensions'][ $key ]['DisplayValue'] ) ) {
				$item_dimensions[ strtolower( $key ) ] = $data['ItemInfo']['ProductInfo']['ItemDimensions'][ $key ]['DisplayValue'];
			}
		}

		if ( ! empty( $item_dimensions ) ) {
			$product_info['item_dimensions'] = $item_dimensions;
		}

		if ( ! empty( $data['ItemInfo']['ProductInfo']['ReleaseDate']['DisplayValue'] ) ) {
			$product_info['release_date'] = $data['ItemInfo']['ProductInfo']['ReleaseDate']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ProductInfo']['Size']['DisplayValue'] ) ) {
			$product_info['size'] = $data['ItemInfo']['ProductInfo']['Size']['DisplayValue'];
		}

		if ( ! empty( $data['ItemInfo']['ProductInfo']['UnitCount']['DisplayValue'] ) ) {
			$product_info['unit_count'] = $data['ItemInfo']['ProductInfo']['UnitCount']['DisplayValue'];
		}

		if ( ! empty( $product_info ) ) {
			$formatted_data['product_info'] = $product_info;
		}

		$technical_info = array();

		if ( ! empty( $data['ItemInfo']['TechnicalInfo']['Formats']['DisplayValues'] ) ) {
			$formats = array();

			foreach ( $data['ItemInfo']['TechnicalInfo']['Formats']['DisplayValues'] as $format ) {
				$formats[] = $format;
			}

			$technical_info['formats'] = $formats;
		}

		if ( ! empty( $data['ItemInfo']['ProductInfo']['EnergyEfficiencyClass']['DisplayValue'] ) ) {
			$technical_info['energy_efficiency_class'] = $data['ItemInfo']['ProductInfo']['EnergyEfficiencyClass']['DisplayValue'];
		}

		if ( ! empty( $technical_info ) ) {
			$formatted_data['technical_info'] = $technical_info;
		}

		return $formatted_data;
	}

	/**
	 * @return string
	 */
	public function buy_button_title(): string {
		$item_data = $this->get_item_data();

		$amazon_button_label = __( 'Buy on Amazon', 'hostinger-affiliate-plugin' );

		if ( ! empty( $item_data ) && 'Prime Video' === $item_data['binding'] ) {
			$amazon_button_label = __( 'Watch on Amazon Prime', 'hostinger-affiliate-plugin' );
		}

		return $amazon_button_label;
	}

	/**
	 * @return array
	 */
	public function to_array(): array {

		return array(
			'id'               => $this->get_id(),
			'asin'             => $this->get_asin(),
			'title'            => $this->get_title(),
			'url'              => $this->get_url(),
			'image_url'        => $this->get_image_url(),
			'item_data'        => json_encode( $this->get_item_data() ),
			'currency'         => $this->get_currency(),
			'price'            => $this->get_price(),
			'is_prime'         => $this->get_is_prime(),
			'is_free_shipping' => $this->get_is_free_shipping(),
			'rating'           => $this->get_rating(),
			'reviews'          => $this->get_reviews(),
			'created_at'       => $this->get_created_at(),
			'updated_at'       => $this->get_updated_at(),
		);
	}
}
