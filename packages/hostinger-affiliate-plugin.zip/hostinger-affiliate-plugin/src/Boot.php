<?php
/**
 * Boot class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

use Hostinger\AffiliatePlugin\Admin\Menus;
use Hostinger\AffiliatePlugin\Admin\Notices;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Repositories\ListRepository;
use Hostinger\AffiliatePlugin\Repositories\ProductRepository;
use Hostinger\AffiliatePlugin\Repositories\TableRepository;
use Hostinger\AffiliatePlugin\Rest\ItemsRoutes;
use Hostinger\AffiliatePlugin\Rest\SettingsRoutes;
use Hostinger\AffiliatePlugin\Rest\Routes;
use Hostinger\AffiliatePlugin\Rest\TableRoutes;
use Hostinger\AffiliatePlugin\Setup\Assets;
use Hostinger\AffiliatePlugin\Setup\Blocks;
use Hostinger\AffiliatePlugin\Setup\Cpts;
use Hostinger\AffiliatePlugin\Setup\Localization;
use Hostinger\AffiliatePlugin\Setup\Updates;
use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;
use Hostinger\AffiliatePlugin\Api\RequestsClient;
use Hostinger\AffiliatePlugin\Api\AmazonClient;

/**
 * Boot class
 */
class Boot {

	/**
	 * Instance holder variable
	 *
	 * @var self|null Boot instance
	 */
	private static ?Boot $instance = null;

	/**
	 * Allow allow only one instance of class
	 *
	 * @return self|null
	 */
	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Run plugin
	 *
	 * @return void
	 */
	public function plugins_loaded(): void {
		global $wpdb;

		// Notices class.
		$notices = new Notices();

		$plugin_settings = new PluginSettings();

		$functions = new Functions();

		if ( $functions->is_plugin_active( 'hostinger' ) ) {

			$menus = new Menus( $plugin_settings );
			$menus->init();

		} else {
			add_action( 'admin_notices', array( $notices, 'main_plugin_notice' ) );
		}

		// Cpts.
		$cpts = new Cpts();
		$cpts->init();

		// Amazon client with requests client.
		$requests_client = new RequestsClient();
		$amazon_client   = new AmazonClient( $plugin_settings, $requests_client );

		// Updates.
		$updates = new Updates();
		$updates->updates();

		// Load assets.
		$assets = new Assets( $functions );
		$assets->init();

		// Load localization related functions.
		$localization = new Localization();
		$localization->init();

		// Amplitude events.
		$amplitude_events = new AmplitudeEvents();
		$amplitude_events->init();

		$table_repository = new TableRepository();

		// Rest Api.
		$rest_routes = new Routes(
			new SettingsRoutes( $amazon_client, $plugin_settings ),
			new ItemsRoutes( $amazon_client, $amplitude_events ),
			new TableRoutes( $table_repository )
		);
		$rest_routes->init();

		// Product Repo.
		$product_repository = new ProductRepository( $wpdb, $amazon_client, $amplitude_events );
		$list_repository    = new ListRepository( $wpdb, $amazon_client, $amplitude_events, $product_repository );

		// Blocks.
		$blocks = new Blocks( $plugin_settings, $amazon_client, $amplitude_events, $product_repository, $list_repository, $table_repository );
		$blocks->init();
	}
}