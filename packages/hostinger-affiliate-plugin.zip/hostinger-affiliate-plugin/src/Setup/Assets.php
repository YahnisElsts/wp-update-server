<?php
/**
 * Assets class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Setup;

use Hostinger\AffiliatePlugin\Admin\Options\PluginOptions;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Assets class
 */
class Assets {
	/**
	 * Run actions or/and hooks
	 */
	public function init(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
	}

	/**
	 * Enqueue admin assets
	 *
	 * @return void
	 */
	public function admin_enqueue_scripts(): void {
		wp_register_style(
			'hostinger-affiliate-plugin-backend',
			HOSTINGER_AFFILIATE_PLUGIN_URL . 'assets/dist/backend.css',
			false,
			filemtime( HOSTINGER_AFFILIATE_PLUGIN_DIR . 'assets/dist/backend.js' )
		);

		wp_enqueue_style(
			'hostinger-affiliate-plugin-backend'
		);

		wp_enqueue_script(
			'hostinger-affiliate-plugin-backend',
			HOSTINGER_AFFILIATE_PLUGIN_URL . 'assets/dist/backend.js',
			array(),
			filemtime( HOSTINGER_AFFILIATE_PLUGIN_DIR . 'assets/dist/backend.js' ),
			true
		);

		$settings = new PluginSettings();

		$plugin_settings = $settings->get_plugin_settings( true )->to_array();

		$user = wp_get_current_user();

		wp_localize_script(
			'hostinger-affiliate-plugin-backend',
			'hst_affiliate_data',
			array(
				'site_url'      => get_site_url(),
				'ajax_url'      => admin_url( 'admin-ajax.php' ),
				'plugin_url'    => HOSTINGER_AFFILIATE_PLUGIN_URL,
				'rest_base_url' => esc_url_raw( rest_url() ),
				'nonce'         => wp_create_nonce( 'wp_rest' ),
				'block'         => array(
					'user_display_name' => $user->data->display_name,
					'site_url'          => get_site_url(),
					'status_constants'  => array(
						'connected'    => PluginOptions::STATUS_CONNECTED,
						'disconnected' => PluginOptions::STATUS_DISCONNECTED,
					),
					'connection_status' => ( ! empty( $plugin_settings['connection_status'] ) ? $plugin_settings['connection_status'] : PluginOptions::STATUS_DISCONNECTED ),
				),
				'translations'  => array(
					'connect_your_amazon_account'     => __( 'Connect Your Amazon Account', 'hostinger-affiliate-plugin' ),
					'fill_api_details_dashboard'      => __( 'Fill API details from Amazon Product Advertising dashboard to start', 'hostinger-affiliate-plugin' ),
					/* translators: %s: URL to advertising dashboard */
					'settings_paragraph'              => sprintf( __( 'You can get all of this information by logging in to <a href="%s" target="_blank" rel="noopener">Amazon Product Advertising dashboard</a> using your personal account. Copy-paste the API information in the dashboard here.', 'hostinger-affiliate-plugin' ), 'https://advertising.amazon.com/sign-in' ),
					'settings_field_api_key'          => __( 'API Key', 'hostinger-affiliate-plugin' ),
					'settings_field_api_secret'       => __( 'API Secret', 'hostinger-affiliate-plugin' ),
					'settings_field_country'          => __( 'Country', 'hostinger-affiliate-plugin' ),
					'settings_label_choose_country'   => __( 'Choose Amazon region ...', 'hostinger-affiliate-plugin' ),
					'settings_field_tracking_id'      => __( 'Tracking ID', 'hostinger-affiliate-plugin' ),
					'settings_field_submit'           => __( 'Connect Amazon account', 'hostinger-affiliate-plugin' ),
					'api_status'                      => __( 'API status', 'hostinger-affiliate-plugin' ),
					'api_status_connected'            => __( 'Connected', 'hostinger-affiliate-plugin' ),
					'api_status_disconnected'         => __( 'Disconnected', 'hostinger-affiliate-plugin' ),
					'api_status_connected_to'         => __( 'Connected to', 'hostinger-affiliate-plugin' ),
					'create_a_new_post'               => __( 'Create a new post', 'hostinger-affiliate-plugin' ),
					'api_status_reconnect'            => __( 'Reconnect', 'hostinger-affiliate-plugin' ),
					'api_status_disconnect'           => __( 'Disconnect', 'hostinger-affiliate-plugin' ),
					'welcome_card_title'              => __( 'Welcome to Hostinger Amazon Affiliate Plugin!', 'hostinger-affiliate-plugin' ),
					'welcome_card_subtitle'           => __( 'Unlock the full potential of your website – monetize it with our plugin to earn more.', 'hostinger-affiliate-plugin' ),
					'welcome_card_button'             => __( 'Start Earning Now', 'hostinger-affiliate-plugin' ),
					'start_earning_title'             => __( 'Start Earning in Four Easy Steps', 'hostinger-affiliate-plugin' ),
					'start_earning_subtitle'          => __( 'Follow this step-by-step guide to start earning your affiliate commission in no time.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_1_title'      => __( 'Connect Your Amazon Account', 'hostinger-affiliate-plugin' ),
					'start_earning_item_1_desc'       => __( 'Insert API code inside the Amazon Product Advertising dashboard.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_2_title'      => __( 'Choose a Layout', 'hostinger-affiliate-plugin' ),
					'start_earning_item_2_desc'       => __( 'Search for Hostinger Amazon Affiliate in Gutenberg Blocks, and choose the layout for your post.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_3_title'      => __( 'Add the Product(s)', 'hostinger-affiliate-plugin' ),
					'start_earning_item_3_desc'       => __( 'Find the product(s) you want to add, and publish the post.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_4_title'      => __( 'Earn Commissions', 'hostinger-affiliate-plugin' ),
					'start_earning_item_4_desc'       => __( 'That\'s it – every time visitors buy the product from your post, you will earn a commission from Amazon.', 'hostinger-affiliate-plugin' ),
					'start_earning_button'            => __( 'Connect With Your Amazon Account', 'hostinger-affiliate-plugin' ),
					'template_choice_title'           => __( 'Three Templates for Your Product(s) Block', 'hostinger-affiliate-plugin' ),
					'template_choice_subtitle'        => __( 'Choose any template for your needs  – all of them are integrated with the Gutenberg editor.', 'hostinger-affiliate-plugin' ),
					'template_choice_item_1_title'    => __( 'Single Product Card', 'hostinger-affiliate-plugin' ),
					'template_choice_item_1_subtitle' => __( 'Put focus on one product only.', 'hostinger-affiliate-plugin' ),
					'template_choice_item_2_title'    => __( 'Multiple Product List', 'hostinger-affiliate-plugin' ),
					'template_choice_item_2_subtitle' => __( 'Add a few products and describe them briefly.', 'hostinger-affiliate-plugin' ),
					'template_choice_item_3_title'    => __( 'Comparison Table', 'hostinger-affiliate-plugin' ),
					'template_choice_item_3_subtitle' => __( 'Add multiple similar products and compare them.', 'hostinger-affiliate-plugin' ),
					'template_choice_button'          => __( 'Get Started', 'hostinger-affiliate-plugin' ),
					'settings_title'                  => __( 'Settings', 'hostinger-affiliate-plugin' ),
					'settings_subtitle'               => __( 'Manage your Amazon API and other configurations', 'hostinger-affiliate-plugin' ),
					'table_data_title'                => __( 'Table data collections', 'hostinger-affiliate-plugin' ),
					'table_data_subtitle'             => __( 'Manage the data for your product comparison table', 'hostinger-affiliate-plugin' ),
					'table_data_coming_soon'          => __( 'Coming soon', 'hostinger-affiliate-plugin' ),
					'nothing_found'                	  => __( 'Nothing found', 'hostinger-affiliate-plugin' ),
					'try_other_results'               => __( 'Try searching for something else', 'hostinger-affiliate-plugin' ),
					'copied_successfully'     		  => __( 'Copied successfully!', 'hostinger-affiliate-plugin' ),
					'table_data_collections_configure'=> __( 'Configure', 'hostinger-affiliate-plugin' ),
					'tutorial_title'                  => __( 'Tutorial', 'hostinger-affiliate-plugin' ),
					'tutorial_subtitle'               => __( 'Edit your Amazon API details', 'hostinger-affiliate-plugin' ),
					'learn_more_howto_title'          => __( 'Learn more on how to use this plugin', 'hostinger-affiliate-plugin' ),
					'learn_more_howto_subtitle'       => __( 'Learn how to use Hostinger\'s Amazon Affiliate with our tutorials and documentations', 'hostinger-affiliate-plugin' ),
					'back'                            => __( 'Back', 'hostinger-affiliate-plugin' ),
					'amazon_api_settings'             => __( 'Amazon API settings', 'hostinger-affiliate-plugin' ),
					'save_changes'                    => __( 'Save changes', 'hostinger-affiliate-plugin' ),
					'tutorial_video_by'               => __( 'Tutorial video by', 'hostinger-affiliate-plugin' ),
					'hostinger_academy'               => __( 'Hostinger Academy', 'hostinger-affiliate-plugin' ),
					'video_title'                     => __( 'How to Set Up Amazon Affiliate with Hostinger Amazon Affiliate Plugin - Step by step guide', 'hostinger-affiliate-plugin' ),
					'tutorial_howto_title'            => __( 'How to use this plugin?', 'hostinger-affiliate-plugin' ),
					'tutorial_item_1_title'           => __( 'Create a new post', 'hostinger-affiliate-plugin' ),
					'tutorial_item_1_subtitle'        => __( 'First thing first, you need to create a post. Make sure to create the post with the specific niche to be more related with your visitors.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_2_title'           => __( 'Call Hostinger Amazon Affiliate in block editor', 'hostinger-affiliate-plugin' ),
					'tutorial_item_2_subtitle'        => __( 'Inside Block Editor, you can call Hostinger Amazon Affiliate in the block options. You can call it by typing “/” or click the add button in the right side of the paragraph.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_3_title'           => __( 'Choose the layout for the product(s) block', 'hostinger-affiliate-plugin' ),
					'tutorial_item_3_subtitle'        => __( 'You need to choose the main layout for your product(s) block based on your needs. You can choose between single product, multiple product, or comparison.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_4_title'           => __( 'Add the product(s)', 'hostinger-affiliate-plugin' ),
					'tutorial_item_4_subtitle'        => __( 'After choosing the layout, you need to find the product(s) that you want to promote in your post. You can copy-paste the ASIN or search the product(s) manually.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_5_title'           => __( 'Publish the post', 'hostinger-affiliate-plugin' ),
					'tutorial_item_5_subtitle'        => __( 'That’s it! After your post published, whenever your visitor buy the product from your post, you will earn commissions.', 'hostinger-affiliate-plugin' ),
					'tutorial_read_full_doc'          => __( 'Read full documentation', 'hostinger-affiliate-plugin' ),
					'tutorial_create_new_post'        => __( 'Create a new post', 'hostinger-affiliate-plugin' ),
					'search_modal_keyword_missing'    => __( 'Please enter a keyword for search!', 'hostinger-affiliate-plugin' ),
					'search_modal_error_searching'    => __( 'There was an error searching for items: ', 'hostinger-affiliate-plugin' ),
					'fatal_error_while_processing'    => __( 'There was fatal server error while processing your request.', 'hostinger-affiliate-plugin' ),
					'api_disconnected'                => __( 'Amazon api was disconnected!', 'hostinger-affiliate-plugin' ),
					'api_settings_saved'              => __( 'Amazon settings were successfully saved!', 'hostinger-affiliate-plugin' ),
					'api_error_while_saving'          => __( 'There was an error saving your settings: ', 'hostinger-affiliate-plugin' ),
				),
			)
		);
	}
}
