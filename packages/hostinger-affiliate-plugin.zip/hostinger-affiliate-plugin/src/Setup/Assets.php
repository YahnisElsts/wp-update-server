<?php
/**
 * Assets class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Setup;

use Hostinger\AffiliatePlugin\Admin\Options\PluginOptions;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Functions;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Assets class
 */
class Assets {
	/**
	 * @var Functions
	 */
	private Functions $functions;

	/**
	 * @param Functions $functions
	 */
	public function __construct( Functions $functions ) {
		$this->functions = $functions;
	}

	/**
	 * Run actions or/and hooks
	 */
	public function init(): void {
		if ( $this->functions->need_to_load_affiliate_assets() ) {
			add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ] );
		}
	}

	/**
	 * Enqueue admin assets
	 *
	 * @return void
	 */
	public function admin_enqueue_scripts(): void {
		wp_register_style(
			'hostinger-affiliate-plugin-backend',
			HOSTINGER_AFFILIATE_PLUGIN_URL . 'assets/dist/backend.css',
			false,
			filemtime( HOSTINGER_AFFILIATE_PLUGIN_DIR . 'assets/dist/backend.js' )
		);

		wp_enqueue_style(
			'hostinger-affiliate-plugin-backend'
		);

		wp_enqueue_script(
			'hostinger-affiliate-plugin-backend',
			HOSTINGER_AFFILIATE_PLUGIN_URL . 'assets/dist/backend.js',
			array(),
			filemtime( HOSTINGER_AFFILIATE_PLUGIN_DIR . 'assets/dist/backend.js' ),
			true
		);

		$settings = new PluginSettings();

		$plugin_settings = $settings->get_plugin_settings()->to_array();

		$user = wp_get_current_user();

		$table_args = array(
			'post_type'   => 'hst_affiliate_table',
			'post_status' => 'publish',
			'numberposts' => -1
		);

		$tables = get_posts( $table_args );

		wp_localize_script(
			'hostinger-affiliate-plugin-backend',
			'hst_affiliate_data',
			array(
				'site_url'      => get_site_url(),
				'ajax_url'      => admin_url( 'admin-ajax.php' ),
				'plugin_url'    => HOSTINGER_AFFILIATE_PLUGIN_URL,
				'rest_base_url' => esc_url_raw( rest_url() ),
				'nonce'         => wp_create_nonce( 'wp_rest' ),
				'block'         => array(
					'user_display_name' => $user->data->display_name,
					'site_url'          => get_site_url(),
					'status_constants'  => array(
						'connected'    => PluginOptions::STATUS_CONNECTED,
						'disconnected' => PluginOptions::STATUS_DISCONNECTED,
					),
					'connection_status' => ( ! empty( $plugin_settings['connection_status'] ) ? $plugin_settings['connection_status'] : PluginOptions::STATUS_DISCONNECTED ),
					'tracking_id' => ( ! empty( $plugin_settings['amazon']['tracking_id'] ) ) ? $plugin_settings['amazon']['tracking_id'] : '',
					'tables'    => $tables,
					'domain_settings' => array(
						'domain'        => $this->functions->get_host_info()
					)
				),
				'amazon_dashboard_url' => $this->functions->get_amazon_affiliate_dashboard_url(),
				'translations'  => array(
					'connect_your_amazon_account'     => __( 'Connect Your Amazon Account', 'hostinger-affiliate-plugin' ),
					'fill_api_details_dashboard'      => __( 'Fill API details from Amazon Product Advertising dashboard to start', 'hostinger-affiliate-plugin' ),
					/* translators: %s: URL to advertising dashboard */
					'connect_account_cta_heading'     => __( 'Log in to Amazon Associate dashboard', 'hostinger-affiliate-plugin' ),
					'connect_account_cta_desc'        => __( 'In order to get the Amazon API information, you need to log in to your <b>Amazon Associate</b> account.', 'hostinger-affiliate-plugin' ),
					'connect_account_cta_button_text' => __( 'Login', 'hostinger-affiliate-plugin' ),
					'settings_paragraph'              => sprintf( __( 'You can get all of this information by logging in to <a href="%s" target="_blank" rel="noopener">Amazon Product Advertising dashboard</a> using your personal account. Copy-paste the API information in the dashboard here.', 'hostinger-affiliate-plugin' ), $this->functions->get_amazon_affiliate_dashboard_url() ),
					'settings_field_api_key'          => __( 'API Key', 'hostinger-affiliate-plugin' ),
					'settings_field_api_secret'       => __( 'API Secret', 'hostinger-affiliate-plugin' ),
					'settings_field_country'          => __( 'Country', 'hostinger-affiliate-plugin' ),
					'settings_label_choose_country'   => __( 'Choose Amazon region ...', 'hostinger-affiliate-plugin' ),
					'settings_field_tracking_id'      => __( 'Tracking ID', 'hostinger-affiliate-plugin' ),
					'settings_field_submit'           => __( 'Connect Amazon account', 'hostinger-affiliate-plugin' ),
					'api_status'                      => __( 'API status', 'hostinger-affiliate-plugin' ),
					'api_status_connected'            => __( 'Connected', 'hostinger-affiliate-plugin' ),
					'api_status_disconnected'         => __( 'Disconnected', 'hostinger-affiliate-plugin' ),
					'api_status_connected_to'         => __( 'Connected to Partner ID:', 'hostinger-affiliate-plugin' ),
					'create_a_new_post'               => __( 'Create a new post', 'hostinger-affiliate-plugin' ),
					'api_status_disconnect'           => __( 'Disconnect', 'hostinger-affiliate-plugin' ),
					'welcome_card_title'              => __( 'Welcome to Hostinger Amazon Affiliate Plugin!', 'hostinger-affiliate-plugin' ),
					'welcome_card_subtitle'           => __( 'Unlock the full potential of your website – monetize it with our plugin to earn more.', 'hostinger-affiliate-plugin' ),
					'welcome_card_button'             => __( 'Start Earning Now', 'hostinger-affiliate-plugin' ),
					'start_earning_title'             => __( 'Start Earning in Four Easy Steps', 'hostinger-affiliate-plugin' ),
					'start_earning_subtitle'          => __( 'Follow this step-by-step guide to start earning your affiliate commission in no time.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_1_title'      => __( 'Connect Your Amazon Account', 'hostinger-affiliate-plugin' ),
					'start_earning_item_1_desc'       => __( 'Insert API code inside the Amazon Product Advertising dashboard.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_2_title'      => __( 'Add a new post', 'hostinger-affiliate-plugin' ),
					'start_earning_item_2_desc'       => __( 'Write down your content that you want to link your Amazon product with.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_3_title'      => __( 'Link Amazon Products', 'hostinger-affiliate-plugin' ),
					'start_earning_item_3_desc'       => __( 'Search for <b>Link to Amazon Products</b> in Gutenberg Blocks, find the product(s) you want to add, and publish the post.', 'hostinger-affiliate-plugin' ),
					'start_earning_item_4_title'      => __( 'Earn Commissions', 'hostinger-affiliate-plugin' ),
					'start_earning_item_4_desc'       => __( 'That\'s it – every time visitors buy the product from your post, you will earn a commission from Amazon.', 'hostinger-affiliate-plugin' ),
					'start_earning_button'            => __( 'Connect With Your Amazon Account', 'hostinger-affiliate-plugin' ),
					'template_choice_title'           => __( 'Three Templates for Your Product(s) Block', 'hostinger-affiliate-plugin' ),
					'template_choice_subtitle'        => __( 'Choose any template for your needs  – all of them are integrated with the Gutenberg editor.', 'hostinger-affiliate-plugin' ),
					'template_choice_item_1_title'    => __( 'Single Product Card', 'hostinger-affiliate-plugin' ),
					'template_choice_item_1_subtitle' => __( 'Put focus on one product only.', 'hostinger-affiliate-plugin' ),
					'template_choice_item_2_title'    => __( 'Multiple Product List', 'hostinger-affiliate-plugin' ),
					'template_choice_item_2_subtitle' => __( 'Add a few products and describe them briefly.', 'hostinger-affiliate-plugin' ),
					'template_choice_item_3_title'    => __( 'Comparison Table', 'hostinger-affiliate-plugin' ),
					'template_choice_item_3_subtitle' => __( 'Add multiple similar products and compare them.', 'hostinger-affiliate-plugin' ),
					'template_choice_button'          => __( 'Get Started', 'hostinger-affiliate-plugin' ),
					'settings_title'                  => __( 'Settings', 'hostinger-affiliate-plugin' ),
					'settings_subtitle'               => __( 'Manage your Amazon API and other configurations', 'hostinger-affiliate-plugin' ),
					'create_table'                    => __( 'Create new table', 'hostinger-affiliate-plugin' ),
					'table_data_title'                => __( 'Table data collections', 'hostinger-affiliate-plugin' ),
					'table_data_subtitle'             => __( 'Manage the data for your product comparison table', 'hostinger-affiliate-plugin' ),
					'table_data_coming_soon'          => __( 'Coming soon', 'hostinger-affiliate-plugin' ),
					'nothing_found'                	  => __( 'Nothing found', 'hostinger-affiliate-plugin' ),
					'try_other_results'               => __( 'Try searching for something else', 'hostinger-affiliate-plugin' ),
					'copied_successfully'     		  => __( 'Copied successfully!', 'hostinger-affiliate-plugin' ),
					'table_data_collections_configure'=> __( 'Configure', 'hostinger-affiliate-plugin' ),
					'tutorial_title'                  => __( 'Tutorial', 'hostinger-affiliate-plugin' ),
					'tutorial_subtitle'               => __( 'Edit your Amazon API details', 'hostinger-affiliate-plugin' ),
					'learn_more_howto_title'          => __( 'Learn more on how to use this plugin', 'hostinger-affiliate-plugin' ),
					'learn_more_howto_subtitle'       => __( 'Learn how to use Hostinger\'s Amazon Affiliate with our tutorials and documentations', 'hostinger-affiliate-plugin' ),
					'back'                            => __( 'Back', 'hostinger-affiliate-plugin' ),
					'amazon_api_settings'             => __( 'Amazon API settings', 'hostinger-affiliate-plugin' ),
					'save_changes'                    => __( 'Save changes', 'hostinger-affiliate-plugin' ),
					'tutorial_video_by'               => __( 'Tutorial video by', 'hostinger-affiliate-plugin' ),
					'hostinger_academy'               => __( 'Hostinger Academy', 'hostinger-affiliate-plugin' ),
					'video_title'                     => __( 'How to Set Up Amazon Affiliate with Hostinger Amazon Affiliate Plugin - Step by step guide', 'hostinger-affiliate-plugin' ),
					'tutorial_howto_title'            => __( 'How to use this plugin?', 'hostinger-affiliate-plugin' ),
					'tutorial_item_1_title'           => __( 'Create a new post', 'hostinger-affiliate-plugin' ),
					'tutorial_item_1_subtitle'        => __( 'First thing first, you need to create a post. Make sure to create the post with the specific niche to be more related with your visitors.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_2_title'           => __( 'Add “Link Amazon product(s)” in block editor', 'hostinger-affiliate-plugin' ),
					'tutorial_item_2_subtitle'        => __( 'Inside Block Editor, you can call Hostinger Amazon Affiliate in the block options. You can call it by typing “/” or click the add button in the right side of the paragraph.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_3_title'           => __( 'Choose the layout for the product(s) block', 'hostinger-affiliate-plugin' ),
					'tutorial_item_3_subtitle'        => __( 'You need to choose the main layout for your product(s) block based on your needs. You can choose between single product, multiple product, or comparison.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_4_title'           => __( 'Add the product(s)', 'hostinger-affiliate-plugin' ),
					'tutorial_item_4_subtitle'        => __( 'After choosing the layout, you need to find the product(s) that you want to promote in your post. You can copy-paste the ASIN or search the product(s) manually.', 'hostinger-affiliate-plugin' ),
					'tutorial_item_5_title'           => __( 'Publish the post', 'hostinger-affiliate-plugin' ),
					'tutorial_item_5_subtitle'        => __( 'That’s it! After your post published, whenever your visitor buy the product from your post, you will earn commissions.', 'hostinger-affiliate-plugin' ),
					'tutorial_read_full_doc'          => __( 'Read full documentation', 'hostinger-affiliate-plugin' ),
					'tutorial_create_new_post'        => __( 'Create a new post', 'hostinger-affiliate-plugin' ),
					'table_collection_nothing_found_description' => __( 'Table data will be shown in this page', 'hostinger-affiliate-plugin' ),
					'table_collection_add_new_table'  => __( 'Add new table', 'hostinger-affiliate-plugin' ),
					'search_modal_keyword_missing'    => __( 'Please enter a keyword for search!', 'hostinger-affiliate-plugin' ),
					'search_modal_error_searching'    => __( 'There was an error searching for items: ', 'hostinger-affiliate-plugin' ),
					'fatal_error_while_processing'    => __( 'There was fatal server error while processing your request.', 'hostinger-affiliate-plugin' ),
					'api_disconnected'                => __( 'Amazon api was disconnected!', 'hostinger-affiliate-plugin' ),
					'api_settings_saved'              => __( 'Amazon settings were successfully saved!', 'hostinger-affiliate-plugin' ),
					'api_error_while_saving'          => __( 'There was an error saving your settings: ', 'hostinger-affiliate-plugin' ),
					'create_table_collection_enter_table_name' => __( 'Enter the name of the table', 'hostinger-affiliate-plugin' ),
					'create_table_collection_add_compare_products' => __( 'Add the products to be compared', 'hostinger-affiliate-plugin' ),
					'create_table_collection_edit_compare_products' => __( 'Products to be compared', 'hostinger-affiliate-plugin' ),
					'create_table_collection_add_row_data' => __( 'Add the product data', 'hostinger-affiliate-plugin' ),
					'create_table_collection_edit_row_data' => __( 'Product data', 'hostinger-affiliate-plugin' ),
					'create_table_collection_add_table_data' => __( 'Add table', 'hostinger-affiliate-plugin' ),
					'table_collection_table_name' => __( 'Table name', 'hostinger-affiliate-plugin' ),
					'continue' => __( 'Continue', 'hostinger-affiliate-plugin' ),
					'close' => __( 'Close', 'hostinger-affiliate-plugin' ),
					'delete'    => __( 'Delete', 'hostinger-affiliate-plugin' ),
					'or' => __( 'or', 'hostinger-affiliate-plugin' ),
					'table_collection_asin_invalid' => __( 'Invalid ASIN', 'hostinger-affiliate-plugin' ),
					'table_collection_are_you_sure_delete_table' => __( 'Are you sure you want to delete the table ? This action cannot be undone.', 'hostinger-affiliate-plugin' ),
					'table_collection_delete_table' => __( 'Delete table?', 'hostinger-affiliate-plugin' ),
					'table_collection_saved' => __( 'Table was successfully saved', 'hostinger-affiliate-plugin' ),
					'table_collection_created' => __( 'Table was successfully created', 'hostinger-affiliate-plugin' ),
					'table_collection_field_is_required_error' => __( 'This field is required', 'hostinger-affiliate-plugin' ),
					'dropdown_no_options' => __( 'No options', 'hostinger-affiliate-plugin' ),
					'table_collection_search_in_amazon' => __( 'Search for the product in Amazon', 'hostinger-affiliate-plugin' ),
					'table_collection_add_asin' => __( 'Add', 'hostinger-affiliate-plugin' ),
					'table_collection_add_product' => __( 'Add product', 'hostinger-affiliate-plugin' ),
					'table_collection_how_to_do_that' => __( 'How to do that?', 'hostinger-affiliate-plugin' ),
					'table_collection_quick_way_to_add_block_editor' => __( 'Quick way to add this table inside the Block Editor.', 'hostinger-affiliate-plugin' ),
					'table_collection_shortcode' => __( 'Shortcode', 'hostinger-affiliate-plugin' ),
					'table_collection_deleted' => __( 'Table was successfully deleted', 'hostinger-affiliate-plugin' ),
					'table_collection_determine_who_will_see' => __( 'Determine who will see the table', 'hostinger-affiliate-plugin' ),
					'table_collection_visiblity' => __( 'Visibility', 'hostinger-affiliate-plugin' ),
					'table_collection_published' => __( 'Published', 'hostinger-affiliate-plugin' ),
					'table_collection_published_on' => __( 'Published on', 'hostinger-affiliate-plugin' ),
					'table_collection_status' => __( 'Status', 'hostinger-affiliate-plugin' ),
					'table_collection_add_row' => __( 'Add row', 'hostinger-affiliate-plugin' ),
					'table_collection_add_highlight' => __( 'Add highlight', 'hostinger-affiliate-plugin' ),
					'table_collection_text_label' => __( 'Text label', 'hostinger-affiliate-plugin' ),
					'table_collection_text_label_placeholder' => __( 'Enter text label. For example: Best Price', 'hostinger-affiliate-plugin' ),
					'table_collection_enter_asin' => __( 'Enter ASIN', 'hostinger-affiliate-plugin' ),
					'table_collection_row_data' => __( 'Row data', 'hostinger-affiliate-plugin' ),
					'table_collection_save_changes' => __( 'Save changes', 'hostinger-affiliate-plugin' ),
					'table_collection_general_settings' => __( 'General settings', 'hostinger-affiliate-plugin' ),
					'table_collection_switch_toggle' => __( 'Switch the toggle to hide or show the product(s).', 'hostinger-affiliate-plugin' ),
					'create_table_collection_at_least_two_products' => __( 'You need to add at least two products (max 5 products) to create a table', 'hostinger-affiliate-plugin' ),
					'create_table_collection_at_least_one_row' => __( 'You need to add at least one row (title, select) to create a table. Check if all fields are filled.', 'hostinger-affiliate-plugin' ),
					'table_configuration_add_new_table' => __( 'Add a new table configuration', 'hostinger-affiliate-plugin' ),
					'table_configuration_use_saved_table_config' => __( 'Use the saved table configuration', 'hostinger-affiliate-plugin' ),
					'table_configuration_use_saved_table_config_description' => __( 'You can edit the existing table configuration after this step', 'hostinger-affiliate-plugin' ),
					'table_configuration_choose_configuration' => __( 'Choose the table configuration', 'hostinger-affiliate-plugin' ),
					'list_no_matching_options' => __( 'No matching options', 'hostinger-affiliate-plugin' ),
					'edit_table_configuration_save_changes_requirements' => __( 'You need to add at least one row, two enabled products (max 5 products) to save changes. Check if all added fields are filled.', 'hostinger-affiliate-plugin' ),
					'duplicated_asin_stripped' => __( 'Duplicate ASIN: %s was not added.', 'hostinger-affiliate-plugin' ),
					'table_collection_row_option_title' => __( 'Title', 'hostinger-affiliate-plugin' ),
					'table_collection_row_option_thumb' => __( 'Thumbnail', 'hostinger-affiliate-plugin' ),
					'table_collection_row_option_price' => __( 'Price', 'hostinger-affiliate-plugin' ),
					'table_collection_row_option_amazon_button' => __( 'Amazon Button', 'hostinger-affiliate-plugin' ),
					'asin_tooltip' => __( 'ASIN is a unique 10-digit code Amazon assigns to products in its catalog. You can find it on the product detail page.', 'hostinger-affiliate-plugin' )
				),
			)
		);
	}
}
