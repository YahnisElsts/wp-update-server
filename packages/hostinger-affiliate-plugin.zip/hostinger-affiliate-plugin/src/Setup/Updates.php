<?php
/**
 * Updates class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Setup;

use Hostinger\AffiliatePlugin\Setup\Config;
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Updates class
 */
class Updates {
	/**
	 * @var Config
	 */
	private Config $config_handler;
	/**
	 *
	 */
	private const DEFAULT_PLUGIN_UPDATE_URI = 'https://hostinger-wp-updates.com/?action=get_metadata&slug=hostinger-affiliate-plugin';

	/**
	 *
	 */
	public function __construct() {
		$this->config_handler = new Config();
	}

	/**
	 * @param string $default_value default config value.
	 *
	 * @return string
	 */
	private function get_plugin_update_uri( string $default_value = self::DEFAULT_PLUGIN_UPDATE_URI ): string {
		return $this->config_handler->get_config_value( 'affiliate_plugin_update_uri', $default_value );
	}

	/**
	 * @return void
	 */
	public function updates(): void {
		$plugin_updater_uri = $this->get_plugin_update_uri();

		if ( class_exists( PucFactory::class ) ) {
			$hts_update_checker = PucFactory::buildUpdateChecker(
				$plugin_updater_uri,
				HOSTINGER_AFFILIATE_PLUGIN_DIR . 'hostinger-affiliate-plugin.php',
				'hostinger-affiliate-plugin'
			);
		}
	}
}
