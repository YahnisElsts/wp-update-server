<?php
/**
 * List repository class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Repositories;

use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;
use Hostinger\AffiliatePlugin\Models\Product as ProductModel;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * List repository
 */
class ListRepository implements RepositoryInterface {
	/**
	 * @var mixed
	 */
	private $db;

	/**
	 * @var AmazonClient
	 */
	private AmazonClient $amazon_client;

	/**
	 * @var AmplitudeEvents
	 */
	private AmplitudeEvents $amplitude_events;

	/**
	 * @var ProductRepository
	 */
	private ProductRepository $product_repository;

	/**
	 * @var string
	 */
	private string $table_name;

	/**
	 * @param mixed             $db WordPress db.
	 * @param AmazonClient      $amazon_client amazon client instance.
	 * @param AmplitudeEvents   $amplitude_events amplitude events instance.
	 * @param ProductRepository $product_repository product repo instance.
	 */
	public function __construct( mixed $db, AmazonClient $amazon_client, AmplitudeEvents $amplitude_events, ProductRepository $product_repository ) {
		$this->db                 = $db;
		$this->amazon_client      = $amazon_client;
		$this->amplitude_events   = $amplitude_events;
		$this->product_repository = $product_repository;
		$this->table_name         = $this->db->prefix . 'hostinger_affiliate_lists';
	}

	/**
	 * @param array $fields fields to insert.
	 *
	 * @return bool
	 */
	public function insert( array $fields ): bool {
		return ! empty( $this->db->insert( $this->table_name, $fields ) );
	}

	/**
	 * @param string $keywords keywords to search for.
	 *
	 * @return array
	 */
	public function get_by_keywords( string $keywords ): array {
		$sql = 'SELECT * FROM `' . $this->table_name . '` WHERE `keywords` = "%s"';

		$query = $this->db->prepare( $sql, $keywords );

		$results = $this->db->get_results( $query, ARRAY_A );

		if ( empty( $results ) ) {
			return array();
		}

		return $results;
	}

	/**
	 * @param string $keywords bestseller keywords.
	 * @param string $layout   layout.
	 *
	 * @return array
	 */
	public function pull_bestsellers( string $keywords, string $layout ): array {
		$products = array();

		$list = $this->get_by_keywords( $keywords );

		if ( empty( $list ) ) {

			$amazon_response = $this->amazon_client->search_items( $keywords );

			if ( ! empty( $amazon_response['Errors'] ) ) {
				$this->handle_amazon_errors( $amazon_response['Errors'] );
			}

			if ( empty( $amazon_response['SearchResult']['Items'] ) ) {
				return array();
			}

			$asins = array();

			$items = array_slice( $amazon_response['SearchResult']['Items'], 0, 10 );

			foreach ( $items as $item ) {
				$asins[] = $item['ASIN'];
			}

			$products_in_db = $this->product_repository->get_by_asins( $asins );

			$missing_products = $this->product_repository->find_missing_products( $products_in_db, $asins );

			if ( ! empty( $products_in_db ) ) {
				$products = $products_in_db;
			}

			if ( ! empty( $missing_products ) ) {
				foreach ( $items as $item ) {
					if ( in_array( $item['ASIN'], $missing_products, true ) ) {
						$products[] = $this->product_repository->create_from_api( $item );
					}
				}
			}

			$list = array(
				'keywords' => $keywords,
				'asins'    => implode( ',', $asins ),
			);

			$this->insert( $list );

		} else {

			$products = $this->product_repository->get_by_asins( explode( ',', $list[0]['asins'] ) );

		}

		return $products;
	}
}
