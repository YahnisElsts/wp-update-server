<?php
/**
 * Product repository class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Repositories;

use Hostinger\AffiliatePlugin\Models\Product as ProductModel;
use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Errors\AmazonApiError;
use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;
use mysql_xdevapi\Exception;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Product repository
 */
class ProductRepository implements RepositoryInterface {
	/**
	 * @var mixed
	 */
	private $db;

	/**
	 * @var AmazonClient
	 */
	private AmazonClient $amazon_client;

	/**
	 * @var AmplitudeEvents
	 */
	private AmplitudeEvents $amplitude_events;

	/**
	 * @var string
	 */
	private string $table_name;

	/**
	 * @param mixed           $db db driver.
	 * @param AmazonClient    $amazon_client amazon client instance.
	 * @param AmplitudeEvents $amplitude_events amplitude events instance.
	 */
	public function __construct( mixed $db, AmazonClient $amazon_client, AmplitudeEvents $amplitude_events ) {
		$this->db               = $db;
		$this->amazon_client    = $amazon_client;
		$this->amplitude_events = $amplitude_events;
		$this->table_name       = $this->db->prefix . 'hostinger_affiliate_products';
	}

	/**
	 * @param array $asins product asins.
	 *
	 * @return array
	 */
	public function get_by_asins( array $asins ): array {
		$sql = 'SELECT * FROM `' . $this->table_name . '` WHERE `asin` IN (' . implode( ', ', array_fill( 0, count( $asins ), '%s' ) ) . ')';

		$query = call_user_func_array( array( $this->db, 'prepare' ), array_merge( array( $sql ), $asins ) );

		$results = $this->db->get_results( $query, ARRAY_A );

		if ( empty( $results ) ) {
			return array();
		}

		return array_map(
			function ( $item ) {
				return new ProductModel( $item );
			},
			$results
		);
	}

	/**
	 * @param array $fields fields to insert.
	 *
	 * @return bool
	 */
	public function insert( array $fields ): bool {
		return ! empty( $this->db->insert( $this->table_name, $fields ) );
	}

	/**
	 * @param string $asin asins.
	 *
	 * @return string[]
	 */
	public function clean_asin( string $asin ): array {
		$asin = trim( $asin );

		$asin = str_replace( ' ', '', $asin );

		return array_filter( explode( ',', $asin ) );
	}

	/**
	 * @param array $products products.
	 * @param array $asins asins.
	 *
	 * @return array
	 */
	public function find_missing_products( array $products, array $asins ): array {
		if ( empty( $products ) ) {
			return $asins;
		}

		$product_map = array();

		foreach ( $products as $product ) {
			$product_map[ $product->get_asin() ] = true;
		}

		$missing_products = array();

		foreach ( $asins as $asin ) {
			if ( ! isset( $product_map[ $asin ] ) ) {
				$missing_products[] = $asin;
			}
		}

		return $missing_products;
	}

	/**
	 * @param array  $asins product asins.
	 * @param string $layout selected layout for products.
	 *
	 * @return array
	 * @throws \Exception Exception.
	 */
	public function pull_products( array $asins, string $layout ): array {
		$products = array();

		$products_in_db = $this->get_by_asins( $asins );

		$missing_products = $this->find_missing_products( $products_in_db, $asins );

		if ( ! empty( $products_in_db ) ) {
			$products = $products_in_db;
		}

		if ( ! empty( $missing_products ) ) {
			$fetched_products = $this->fetch_products_from_api( $missing_products, $layout );

			if ( ! empty( $fetched_products ) ) {
				foreach ( $fetched_products as $product ) {
					$products[] = $product;
				}
			}
		}

		return $products;
	}

	/**
	 * @param array $asins product asins.
	 *
	 * @return bool
	 */
	public function validate_asins( array $asins ): bool {
		if ( empty( $asins ) ) {
			return false;
		}

		$valid = true;

		foreach ( $asins as $asin ) {
			if ( ! preg_match( '/^[A-Z0-9]{10}$/', $asin ) ) {
				$valid = false;
			}
		}

		return $valid;
	}

	/**
	 * @param array $products product model items.
	 *
	 * @return array
	 */
	public function format_asins( array $products ) {
		$formatted_asins = array();

		if ( empty( $products ) ) {
			return $formatted_asins;
		}

		foreach ( $products as $product ) {
			$formatted_asins[ $product->get_asin() ] = array_intersect_key( $product->to_array(), array_flip( array( 'asin', 'title', 'image_url' ) ) );
		}

		return $formatted_asins;
	}

	/**
	 * @param array  $asins array of asins.
	 * @param string $layout layout.
	 *
	 * @return array
	 * @throws \Exception Exception.
	 */
	public function fetch_products_from_api( array $asins, string $layout = '' ): array {
		$products = array();

		$amazon_response = $this->amazon_client->get_items( $asins );

		$this->amplitude_events->affiliate_created( $layout );

		if ( ! empty( $amazon_response['Errors'] ) ) {
			$this->handle_amazon_errors( $amazon_response['Errors'] );
		}

		if ( ! empty( $amazon_response['ItemsResult']['Items'] ) ) {
			foreach ( $amazon_response['ItemsResult']['Items'] as $item ) {
				$products[] = $this->create_from_api( $item );
			}
		}

		return $products;
	}

	/**
	 * @param array $item Amazon API item.
	 *
	 * @return ProductModel
	 */
	public function create_from_api( array $item ): ProductModel {
		$product = ProductModel::create_from_api( $item );

		$product->set_updated_at( $product->get_created_at() );

		$this->insert( $product->to_array() );

		return $product;
	}

	/**
	 * @param array $errors api errors.
	 *
	 * @return void
	 * @throws \Exception Exception.
	 */
	private function handle_amazon_errors( array $errors ): void {
		$amazon_api_error        = new AmazonApiError( $errors );
		$reversed_error_messages = implode( ', ', array_reverse( $amazon_api_error->get_error_messages() ) );

		if ( current_user_can( 'administrator' ) ) {
			$formatted_errors = $reversed_error_messages;
		} else {
			$formatted_errors = __( 'There is an issue displaying Amazon products. Please contact the administrator to check that.', 'hostinger-affiliate-plugin' );
		}

		throw new \Exception( $formatted_errors );
	}

    /**
     * @param $data
     * @param $where
     *
     * @return bool
     */
    public function update( $data, $where ): bool {
        $data = array_diff_key( $data, array_flip( array( 'id', 'created_at' ) ) );

        if ( empty( $data ) ) {
            return false;
        }

        return $this->db->update(
            $this->table_name,
            $data,
            $where
        );
    }

    /**
     * @param string $date
     *
     * @return array
     */
    public function get_by_updated_at( string $date, int $limit = 10 ): array {
        $sql = 'SELECT * FROM `' . $this->table_name . '` WHERE `updated_at` < %s ORDER BY `updated_at` ASC LIMIT 0, %d';

        $query = $this->db->prepare( $sql, $date, $limit );

        $results = $this->db->get_results( $query, ARRAY_A );

        if ( empty( $results ) ) {
            return array();
        }

        return array_map(
            function ( $item ) {
                return new ProductModel( $item );
            },
            $results
        );
    }
}
