<?php
/**
 * Product repository class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Repositories;

use Hostinger\AffiliatePlugin\Api\RequestsClient;
use Hostinger\AffiliatePlugin\Models\Product as ProductModel;
use Hostinger\AffiliatePlugin\Repositories\ProductInterface;
use Hostinger\AffiliatePlugin\Admin\PluginSettings;
use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Errors\AmazonApiError;
use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Product repository
 */
class Product implements ProductInterface {
	/**
	 * @var mixed
	 */
	private $db;

	/**
	 * @var string
	 */
	private string $table_name;

	/**
	 * @param mixed $db db driver.
	 */
	public function __construct( mixed $db ) {
		$this->db         = $db;
		$this->table_name = $this->db->prefix . 'hostinger_affiliate_products';
	}

	/**
	 * @param array $asins product asins.
	 *
	 * @return array
	 */
	public function get_by_asins( array $asins ): array {
		$sql = 'SELECT * FROM `' . $this->table_name . '` WHERE `asin` IN (' . implode( ', ', array_fill( 0, count( $asins ), '%s' ) ) . ')';

		$query = call_user_func_array( array( $this->db, 'prepare' ), array_merge( array( $sql ), $asins ) );

		$results = $this->db->get_results( $query, ARRAY_A );

		if ( empty( $results ) ) {
			return array();
		}

		return array_map(
			function ( $item ) {
				return new ProductModel( $item );
			},
			$results
		);
	}

	/**
	 * @param ProductModel $product product object.
	 *
	 * @return bool
	 */
	public function insert( ProductModel $product ): bool {
		return ! empty( $this->db->insert( $this->table_name, $product->to_array() ) );
	}

	/**
	 * @param string $asin asins.
	 *
	 * @return string[]
	 */
	public function clean_asin( string $asin ): array {
		$asin = trim( $asin );

		$asin = str_replace( ' ', '', $asin );

		return array_filter( explode( ',', $asin ) );
	}

	/**
	 * @param array $products products.
	 * @param array $asins asins.
	 *
	 * @return array
	 */
	public function find_missing_products( array $products, array $asins ): array {
		if ( empty( $products ) ) {
			return $asins;
		}

		$product_map = array();

		foreach ( $products as $product ) {
			$product_map[ $product->get_asin() ] = true;
		}

		$missing_products = array();

		foreach ( $asins as $asin ) {
			if ( ! isset( $product_map[ $asin ] ) ) {
				$missing_products[] = $asin;
			}
		}

		return $missing_products;
	}

	/**
	 * @param array  $asins product asins.
	 * @param string $layout selected layout for products.
	 *
	 * @return array
	 * @throws \Exception Exception.
	 */
	public function pull_products( array $asins, string $layout ): array {
		$products = array();

		$products_in_db = $this->get_by_asins( $asins );

		$missing_products = $this->find_missing_products( $products_in_db, $asins );

		if ( ! empty( $products_in_db ) ) {
			$products = $products_in_db;
		}

		if ( ! empty( $missing_products ) ) {

			$plugin_settings = new PluginSettings();

			$requests_client = new RequestsClient();

			$amazon_client = new AmazonClient( $plugin_settings->get_plugin_settings( false )->amazon, $requests_client );

			$amazon_response = $amazon_client->get_items( $missing_products );

			$amplitude_events = new AmplitudeEvents();

			$amplitude_events->affiliate_created( $layout );

			if ( ! empty( $amazon_response['Errors'] ) ) {
				$amazon_api_error = new AmazonApiError( $amazon_response['Errors'] );

				if ( current_user_can( 'administrator' ) ) {
					$errors = implode( ', ', array_reverse( $amazon_api_error->get_error_messages() ) );
				} else {
					$errors = __( 'There is an issue displaying Amazon products. Please contact administrator to check that.', 'hostinger-affiliate-plugin' );
				}

				throw new \Exception( implode( ', ', array_reverse( $amazon_api_error->get_error_messages() ) ) );
			}

			if ( ! empty( $amazon_response['ItemsResult']['Items'] ) ) {
				foreach ( $amazon_response['ItemsResult']['Items'] as $item ) {

					$product = ProductModel::create_from_api( $item );

					$this->insert( $product );

					$products[] = $product;
				}
			}
		}

		return $products;
	}

	/**
	 * @param array $asins product asins.
	 *
	 * @return bool
	 */
	public function validate_asins( array $asins ): bool {
		if ( empty( $asins ) ) {
			return false;
		}

		$valid = true;

		foreach ( $asins as $asin ) {
			if ( ! preg_match( '/^[A-Z0-9]{10}$/', $asin ) ) {
				$valid = false;
			}
		}

		return $valid;
	}
}
