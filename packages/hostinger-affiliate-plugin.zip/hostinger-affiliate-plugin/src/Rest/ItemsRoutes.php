<?php
/**
 * Items API
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Rest;

use Hostinger\AffiliatePlugin\Amplitude\Events as AmplitudeEvents;
use Hostinger\AffiliatePlugin\Api\AmazonClient;
use Hostinger\AffiliatePlugin\Errors\AmazonApiError;
use Hostinger\AffiliatePlugin\Localization\Messages;
use Hostinger\AffiliatePlugin\Repositories\ProductRepository;
use Hostinger\AffiliatePlugin\Amplitude\Actions as AmplitudeActions;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for items
 */
class ItemsRoutes {
	/**
	 *
	 * Amazon client instance
	 *
	 * @var AmazonClient
	 */
	public AmazonClient $amazon_client;

	/**
	 * @var AmplitudeEvents
	 */
	private AmplitudeEvents $amplitude_events;

	/**
	 * Construct class with dependencies
	 *
	 * @param AmazonClient    $amazon_client instance.
	 * @param AmplitudeEvents $amplitude_events instance.
	 */
	public function __construct( AmazonClient $amazon_client, AmplitudeEvents $amplitude_events ) {
		$this->amazon_client    = $amazon_client;
		$this->amplitude_events = $amplitude_events;
	}

	/**
	 * @param \WP_REST_Request $request WordPress request.
	 *
	 * @return \WP_REST_Response|\AmazonApiError|\WP_Error
	 */
	public function search_items( \WP_REST_Request $request ): \WP_REST_Response|\AmazonApiError|\WP_Error {
		$parameters = $request->get_params();

		$errors = array();

		if ( empty( $parameters['keyword'] ) ) {
			$errors['keyword'] = Messages::get_missing_field_message( str_replace( '_', ' ', 'keyword' ) );
		}

		if ( ! empty( $errors ) ) {
			return new \WP_Error(
				'data_invalid',
				__( 'Sorry, there are validation errors.', 'hostinger-affiliate-plugin' ),
				array(
					'status' => \WP_Http::BAD_REQUEST,
					'errors' => $errors,
				)
			);
		}

		$this->amazon_client->set_resources( array( 'Images.Primary.Small' ) );

		$search_keyword = sanitize_text_field( $parameters['keyword'] );

		$amazon_response = $this->amazon_client->search_items( $search_keyword );

		if ( ! empty( $amazon_response['Errors'] ) ) {
			$response = new \WP_REST_Response( array( 'data' => new AmazonApiError( $amazon_response['Errors'] ) ) );

			$response->set_status( \WP_Http::BAD_REQUEST );

			return $response;
		}

		$response_array = array(
			'data' => array(
				'items' => ! empty( $amazon_response['SearchResult']['Items'] ) ? count( $amazon_response['SearchResult']['Items'] ) : 0,
				'html'  => $this->render_item_results( $amazon_response ),
			),
		);

		$response = new \WP_REST_Response( $response_array );

		$response->set_status( \WP_Http::OK );

		return $response;
	}

	/**
	 * @param \WP_REST_Request $request WordPress request.
	 *
	 * @return \WP_REST_Response
	 */
	public function validate_items( \WP_REST_Request $request ): \WP_REST_Response|\WP_Error {
		global $wpdb;

		$parameters = $request->get_params();

		$product_repository = new ProductRepository( $wpdb, $this->amazon_client, $this->amplitude_events );

		$errors = array();

		if ( empty( $parameters['items'] ) ) {
			$errors[] = Messages::get_missing_field_message( str_replace( '_', ' ', 'items' ) );
		}

		$items = $product_repository->clean_asin( $parameters['items'] );

		if ( empty( $product_repository->validate_asins( $items ) ) ) {
			$errors[] = Messages::get_failed_asin_validation_message();
		}

		$layout = $parameters['layout'];

		if ( ! in_array( $layout, AmplitudeActions::AFFILIATE_ALLOWED_LAYOUTS, true ) ) {
			$errors[] = Messages::get_unknown_layout_message();
		}

		if ( ! empty( $errors ) ) {
			return new \WP_Error(
				'data_invalid',
				__( 'Sorry, there are validation errors.', 'hostinger-affiliate-plugin' ),
				array(
					'status' => \WP_Http::BAD_REQUEST,
					'errors' => $errors,
				)
			);
		}

		try {
			$products = $product_repository->pull_products( $items, $layout );
		} catch ( \Exception $e ) {
			$errors = array(
				'data' => array( 'errors' => array( $e->getMessage() ) ),
			);

			$response = new \WP_REST_Response( $errors );

			$response->set_status( \WP_Http::BAD_REQUEST );

			return $response;
		}

		$response_data = array(
			'data'  => 'OK',
			'items' => $product_repository->format_asins( $products ),
		);

		$response = new \WP_REST_Response( $response_data );

		$response->set_status( \WP_Http::OK );

		return $response;
	}

	/**
	 * @param array $response API response.
	 *
	 * @return string
	 */
	private function render_item_results( array $response ): string {
		if ( empty( $response['SearchResult']['Items'] ) ) {
			return '';
		}

		$content = '';

		ob_start();

		require_once __DIR__ . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'search-results.php';

		$content = ob_get_contents();

		ob_end_clean();

		return $content;
	}
}