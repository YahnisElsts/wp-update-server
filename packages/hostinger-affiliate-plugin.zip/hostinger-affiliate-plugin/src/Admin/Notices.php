<?php
/**
 * Notices wrapper class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Admin;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for showing notices
 */
class Notices {
	/**
	 * Main plugin dependency notice
	 */
	public function main_plugin_notice(): void {
		?>
		<div class="notice notice-error is-dismissible hts-theme-settings">
			<p>
				<strong><?php echo __( 'Attention:', 'hostinger-affiliate-plugin' ); ?></strong> <?php __( 'The Hostinger Affiliate plugin requires the main Hostinger plugin to work properly.', 'hostinger-affiliate-plugin' ); ?>
			</p>
			<p><?php echo __( 'To activate the main Hostinger plugin, follow these steps: ', 'hostinger-affiliate-plugin' ); ?></p>
			<ul>
				<li><b><?php echo __( 'Navigate to the Plugins section in the left-hand menu.', 'hostinger-affiliate-plugin' ); ?></b></li>
				<li><b><?php echo __( 'Look for the Hostinger plugin in the list of installed plugins.', 'hostinger-affiliate-plugin' ); ?></b></li>
				<li><b><?php echo __( 'If it is deactivated, click on the "Activate" button below the plugin\'s name.', 'hostinger-affiliate-plugin' ); ?></b></li>
			</ul>
			<p><?php echo __( 'If the main Hostinger plugin is not listed in the Plugins section, follow these steps instead:', 'hostinger-affiliate-plugin' ); ?></p>
			<ul>
				<li><b><?php echo __( 'Deactivate and delete the Hostinger Affiliate plugin.', 'hostinger-affiliate-plugin' ); ?></b></li>
				<li><b><?php echo __( 'From your Hostinger member area (hPanel) reinstall the Hostinger Affiliate plugin.', 'hostinger-affiliate-plugin' ); ?></b></li>
				<li><b><?php echo __( 'The main Hostinger plugin will be installed along with it.', 'hostinger-affiliate-plugin' ); ?></b></li>
			</ul>
		</div>
		<?php
	}
}
