<?php
/**
 * PluginSettings
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Admin\Options;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for handling Settings
 */
class AmazonOptions {
	/**
	 * @var string
	 */
	private string $api_key = '';

	/**
	 * @var string
	 */
	private string $api_secret = '';

	/**
	 * @var string
	 */
	private string $country = '';

	/**
	 * @var string
	 */
	private string $tracking_id = '';

	/**
	 * @var array[]
	 */
	private array $locales = array(
		'au' => array(
			'domain'        => 'amazon.com.au',
			'host'          => 'webservices.amazon.com.au',
			'region'        => 'us-west-2',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => ',',
			),
		),
		'be' => array(
			'domain'        => 'amazon.com.be',
			'host'          => 'webservices.amazon.com.be',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => ' ',
			),
		),
		'br' => array(
			'domain'        => 'amazon.com.br',
			'host'          => 'webservices.amazon.com.br',
			'region'        => 'us-east-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'ca' => array(
			'domain'        => 'amazon.ca',
			'host'          => 'webservices.amazon.ca',
			'region'        => 'us-east-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => ',',
			),
		),
		'eg' => array(
			'domain'        => 'amazon.eg',
			'host'          => 'webservices.amazon.eg',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'fr' => array(
			'domain'        => 'amazon.fr',
			'host'          => 'webservices.amazon.fr',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => ',',
				'thousands_separator' => '',
			),
		),
		'de' => array(
			'domain'        => 'amazon.de',
			'host'          => 'webservices.amazon.de',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => ',',
			),
		),
		'in' => array(
			'domain'        => 'amazon.in',
			'host'          => 'webservices.amazon.in',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => ',',
			),
		),
		'it' => array(
			'domain'        => 'amazon.it',
			'host'          => 'webservices.amazon.it',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'jp' => array(
			'domain'        => 'amazon.co.jp',
			'host'          => 'webservices.amazon.co.jp',
			'region'        => 'us-west-2',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'mx' => array(
			'domain'        => 'amazon.com.mx',
			'host'          => 'webservices.amazon.com.mx',
			'region'        => 'us-east-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'nl' => array(
			'domain'        => 'amazon.nl',
			'host'          => 'webservices.amazon.nl',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'pl' => array(
			'domain'        => 'amazon.pl',
			'host'          => 'webservices.amazon.pl',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'sg' => array(
			'domain'        => 'amazon.sg',
			'host'          => 'webservices.amazon.sg',
			'region'        => 'us-west-2',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'sa' => array(
			'domain'        => 'amazon.sa',
			'host'          => 'webservices.amazon.sa',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'es' => array(
			'domain'        => 'amazon.es',
			'host'          => 'webservices.amazon.es',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'se' => array(
			'domain'        => 'amazon.se',
			'host'          => 'webservices.amazon.se',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'tr' => array(
			'domain'        => 'amazon.com.tr',
			'host'          => 'webservices.amazon.com.tr',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'ae' => array(
			'domain'        => 'amazon.ae',
			'host'          => 'webservices.amazon.ae',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'uk' => array(
			'domain'        => 'amazon.co.uk',
			'host'          => 'webservices.amazon.co.uk',
			'region'        => 'eu-west-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
		'us' => array(
			'domain'        => 'amazon.com',
			'host'          => 'webservices.amazon.com',
			'region'        => 'us-east-1',
			'number_format' => array(
				'decimals'            => 2,
				'decimal_separator'   => '.',
				'thousands_separator' => '',
			),
		),
	);

	/**
	 * @param array $amazon array with amazon settings.
	 */
	public function __construct( array $amazon = array() ) {
		if ( ! empty( $amazon['api_key'] ) ) {
			$this->api_key = $amazon['api_key'];
		}

		if ( ! empty( $amazon['api_secret'] ) ) {
			$this->api_secret = $amazon['api_secret'];
		}

		if ( ! empty( $amazon['country'] ) ) {
			$this->country = $amazon['country'];
		}

		if ( ! empty( $amazon['tracking_id'] ) ) {
			$this->tracking_id = $amazon['tracking_id'];
		}
	}

	/**
	 * @return string
	 */
	public function get_api_key(): string {
		return $this->api_key;
	}

	/**
	 * @param string $api_key Amazon api key.
	 */
	public function set_api_key( string $api_key ): void {
		$this->api_key = $api_key;
	}

	/**
	 * @return string
	 */
	public function get_api_secret(): string {
		return $this->api_secret;
	}

	/**
	 * @param string $api_secret Amazon api secret.
	 */
	public function set_api_secret( string $api_secret ): void {
		$this->api_secret = $api_secret;
	}

	/**
	 * @return string
	 */
	public function get_country(): string {
		return $this->country;
	}

	/**
	 * @param string $country Amazon country.
	 */
	public function set_country( string $country ): void {
		$this->country = $country;
	}

	/**
	 * @return string
	 */
	public function get_tracking_id(): string {
		return $this->tracking_id;
	}

	/**
	 * @param string $tracking_id Amazon partner id.
	 */
	public function set_tracking_id( string $tracking_id ): void {
		$this->tracking_id = $tracking_id;
	}

	/**
	 * @return string
	 */
	public function get_region_name(): string {
		return ! empty( $this->get_country() ) ? $this->locales[ $this->get_country() ]['region'] : '';
	}

	/**
	 * @return string
	 */
	public function get_host(): string {
		return ! empty( $this->get_country() ) ? $this->locales[ $this->get_country() ]['host'] : '';
	}

	/**
	 * @return array
	 */
	public function to_array(): array {
		return array(
			'api_key'     => $this->get_api_key(),
			'api_secret'  => $this->get_api_secret(),
			'country'     => $this->get_country(),
			'tracking_id' => $this->get_tracking_id(),
		);
	}

	/**
	 * @return void
	 */
	public function delete_credentials(): void {
		$this->set_api_key( '' );
		$this->set_api_secret( '' );
		$this->set_country( '' );
		$this->set_tracking_id( '' );
	}

	/**
	 * @return string
	 */
	public function get_domain(): string {
		return ! empty( $this->locales[ $this->get_country() ]['domain'] ) ? $this->locales[ $this->get_country() ]['domain'] : '';
	}

	/**
	 * @return string
	 */
	public function get_formats(): array {
		return ! empty( $this->locales[ $this->get_country() ]['number_format'] ) ? $this->locales[ $this->get_country() ]['number_format'] : array();
	}
}
