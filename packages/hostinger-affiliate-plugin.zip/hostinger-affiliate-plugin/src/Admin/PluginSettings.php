<?php
/**
 * Settings
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Admin;

use Hostinger\AffiliatePlugin\Admin\Options\PluginOptions;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for handling Settings
 */
class PluginSettings {

	/**
	 * @var PluginOptions
	 */
	private ?PluginOptions $plugin_options = null;

	/**
	 * @param PluginOptions|null $plugin_options
	 */
	public function __construct( PluginOptions $plugin_options = null ) {
		if ( ! empty( $plugin_options ) ) {
			$this->plugin_options = $plugin_options;
		}
	}

	/**
	 * Return plugin settings
	 *
	 * @param array $mask_sensitive_data flag if data masking is needed.
	 *
	 * @return PluginOptions
	 */
	public function get_plugin_settings( $mask_sensitive_data = true ): PluginOptions {

		if ( ! empty( $this->plugin_options ) ) {

			$settings = $this->plugin_options;

		} else {
			$settings = get_option(
				HOSTINGER_AFFILIATE_PLUGIN_SLUG,
				array()
			);

			$settings = new PluginOptions( $settings );
		}

		return ! empty( $mask_sensitive_data ) ? $this->mask_sensitive_data( $settings ) : $settings;
	}

	/**
	 * @param PluginOptions $plugin_options plugin settings.
	 *
	 * @return PluginOptions
	 */
	public function save_plugin_settings( PluginOptions $plugin_options ): PluginOptions {
		$existing_settings = $this->get_plugin_settings( false );

		if ( ! empty( $plugin_options->amazon->get_api_secret() ) && ! empty( $existing_settings->amazon->get_api_secret() ) ) {
			if ( str_contains( $plugin_options->amazon->get_api_secret(), '*' ) ) {
				$plugin_options->amazon->set_api_secret( $existing_settings->amazon->get_api_secret() );
			}
		}

		if ( ! empty( $plugin_options->get_is_first_time() ) ) {
			$plugin_options->set_is_first_time( false );
		}

		$update = update_option( HOSTINGER_AFFILIATE_PLUGIN_SLUG, $plugin_options->to_array(), false );

		$plugin_options = ! empty( $update ) ? $plugin_options : $existing_settings;

		return $this->mask_sensitive_data( $plugin_options );
	}

	/**
	 * Filter
	 *
	 * @param PluginOptions $plugin_options plugin settings.
	 *
	 * @return PluginOptions
	 */
	public function mask_sensitive_data( PluginOptions $plugin_options ): PluginOptions {
		// Replace api secret value with asterisk.
		if ( ! empty( $plugin_options->amazon->get_api_secret() ) ) {
			$plugin_options->amazon->set_api_secret( str_repeat( '*', strlen( $plugin_options->amazon->get_api_secret() ) ) );
		}

		return $plugin_options;
	}

	/**
	 * @return void
	 */
	public function delete_amazon_cache(): void {
		global $wpdb;

		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE `option_name` LIKE ('_transient_timeout_amazon_api_%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE `option_name` LIKE ('_transient_amazon_api_%')" );
	}
}
