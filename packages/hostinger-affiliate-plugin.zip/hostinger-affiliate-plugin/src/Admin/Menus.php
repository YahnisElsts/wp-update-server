<?php
/**
 * Menus class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Admin;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for registering menus
 */
class Menus {
	/**
	 * Settings instance
	 *
	 * @var PluginSettings
	 */
	public PluginSettings $plugin_settings;

	/**
	 * Construct class with dependencies
	 *
	 * @param PluginSettings $plugin_settings instance.
	 */
	public function __construct( PluginSettings $plugin_settings ) {
		$this->plugin_settings = $plugin_settings;
	}

	/**
	 * Init menus
	 */
	public function init(): void {
		add_filter( 'hostinger_plugin_additional_tabs', array( $this, 'add_tab' ) );
		add_action( 'hostinger_plugin_additional_tab_content_amazon_affiliate', array( $this, 'render_plugin_content' ) );
		add_action( 'admin_menu', array( $this, 'add_sub_menu_page' ) );
	}

	/**
	 * @return void
	 */
	public function add_sub_menu_page(): void {
		if ( has_action( 'hostinger_plugin_additional_tabs' ) ) {

			add_submenu_page(
				'hostinger',
				__( 'Amazon affiliate', 'hostinger-affiliate-plugin' ),
				__( 'Amazon affiliate', 'hostinger-affiliate-plugin' ),
				'manage_options',
				'hostinger&#amazon_affiliate',
				'__return_empty_string',
				5
			);

		}
	}

	/**
	 * @param array $tabs array of tabs.
	 *
	 * @return array
	 */
	public function add_tab( array $tabs ): array {

		$tabs['amazon_affiliate'] = __( 'Amazon affiliate', 'hostinger-affiliate-plugin' );

		return $tabs;
	}

	/**
	 * Render Vue.js wrapper, pass initial plugin settings as a prop
	 *
	 * @return void
	 */
	public function render_plugin_content(): void {
		?>
		<div id="affiliatePluginApp" class="affiliatePluginApp">
			<Home
					:initial-settings="<?php echo htmlspecialchars( json_encode( $this->plugin_settings->get_plugin_settings()->to_array() ) ); ?>">
			</Home>
		</div>
		<?php
	}
}
