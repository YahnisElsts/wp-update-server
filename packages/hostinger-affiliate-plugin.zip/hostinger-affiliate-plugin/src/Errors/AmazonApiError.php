<?php
/**
 * Amazon Api Error Class
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Errors;

use Hostinger\AffiliatePlugin\Localization\Messages;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class for handling errors from Amazon Api
 */
class AmazonApiError extends \WP_Error {

	/**
	 * @var array
	 */
	private array $error_messages = array();

	/**
	 * @param array $errors array of amazon api returned errors.
	 */
	public function __construct( array $errors ) {
		foreach ( $errors as $error ) {
			$message = $this->get_amazon_error_message( $error['Code'], $error );

			$this->error_messages[] = $message;

			$this->add( $error['Code'], $message );
		}

		parent::__construct(
			'amazon_api_error',
			Messages::get_general_amazon_api_error_message(),
			array(
				'status' => \WP_Http::BAD_REQUEST,
				'errors' => $this->error_messages,
			)
		);
	}

	/**
	 * Handle Amazon API error codes
	 * ref: https://webservices.amazon.com/paapi5/documentation/troubleshooting/error-messages.html
	 *
	 * @param string $error_code Error code returned by API.
	 * @param array  $data Amazon API error data.
	 *
	 * @return string
	 */
	public function get_amazon_error_message( string $error_code, array $data = array() ): string {
		switch ( $error_code ) {
			default:
				$message = __( 'Unknown error happened. Please investigate debug logs for detailed information.', 'hostinger-affiliate-plugin' );
				break;
			case 'AccessDenied':
			case 'AccessDeniedAwsUsers':
				$message = __( 'The Access Key is not enabled for accessing Product Advertising API OR the Access Key is not enabled for accessing this version of Product Advertising API. Please migrate your credentials.', 'hostinger-affiliate-plugin' );
				break;
			case 'InvalidAssociate':
				$message = __( 'Your access key is not mapped to primary of approved associate store. Please visit associate central and map access key.', 'hostinger-affiliate-plugin' );
				break;
			case 'IncompleteSignature':
				$message = __( 'The request signature did not include all of the required components.', 'hostinger-affiliate-plugin' );
				break;
			case 'InvalidPartnerTag':
				$message = __( 'The partner tag is not mapped to a valid associate store with your access key.', 'hostinger-affiliate-plugin' );
				break;
			case 'InvalidSignature':
				$message = __( 'The request has not been correctly signed.', 'hostinger-affiliate-plugin' );
				break;
			case 'TooManyRequests':
				$message = __( 'The request was denied due to request throttling. Please verify the number of requests made per second to the Amazon Product Advertising API.', 'hostinger-affiliate-plugin' );
				break;
			case 'RequestExpired':
				$message = __( 'The request is past expiry date or the request date (either with 15 minute padding), or the request date occurs more than 15 minutes in the future.', 'hostinger-affiliate-plugin' );
				break;
			case 'InvalidParameterValue':
			case 'MissingParameter':
				$message = __( 'Input parameter relating to request is invalid or is missing.', 'hostinger-affiliate-plugin' );

				if ( ! empty( $data['Message'] ) ) {
					$message .= $data['Message'];
				}

				break;
			case 'UnknownOperation':
				$message = __( 'The operation requested is invalid. Please verify that the operation name is typed correctly.', 'hostinger-affiliate-plugin' );
				break;
			case 'UnrecognizedClient':
				$message = __( 'The Access Key or security token included in the request is invalid.', 'hostinger-affiliate-plugin' );
				break;
			case 'NoResults':
				$message = __( 'No results found.', 'hostinger-affiliate-plugin' );
				break;
			case 'RequestFail':
				$message = __( 'Request to Amazon API failed.', 'hostinger-affiliate-plugin' );
				break;
		}

		return $message;
	}

	/**
	 * @return array
	 */
	public function get_api_error_messages(): array {
		return $this->error_messages;
	}
}
