<?php
/**
 * Amplitude Events
 *
 * @package HostingerAffiliatePlugin
 */

namespace Hostinger\AffiliatePlugin\Amplitude;

use Hostinger\WpHelper\Config;
use Hostinger\WpHelper\Constants;
use Hostinger\WpHelper\Requests\Client;
use Hostinger\WpHelper\Utils as Helper;
use Hostinger\Amplitude\AmplitudeManager;

/**
 * Avoid possibility to get file accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Amplitude events
 */
class Events {
	/**
	 * Endpoint
	 */
	private const AMPLITUDE_ENDPOINT = '/v3/wordpress/plugin/trigger-event';
	/**
	 * @var Config instance
	 */
	private Config $config;
	/**
	 * @var Helper instance
	 */
	private Helper $helper;
	/**
	 * @var AmplitudeManager instance
	 */
	private AmplitudeManager $amplitude_manager;

	/**
	 *
	 */
	public function __construct() {
		$this->helper = new Helper();
		$this->config = new Config();
		$client = new Client(
			$this->config->getConfigValue( 'base_rest_uri', Constants::HOSTINGER_REST_URI ),
			[
				Config::TOKEN_HEADER  => $this->helper->getApiToken(),
				Config::DOMAIN_HEADER => $this->helper->getHostInfo(),
			]
		);

		$this->amplitude_manager = new AmplitudeManager( $this->helper, $this->config, $client );
	}

	/**
	 * @return void
	 */
	public function init() {
		add_action( 'transition_post_status', array( $this, 'track_published_post' ), 10, 3 );
	}

	/**
	 * @param string $layout display layout.
	 *
	 * @return void
	 */
	public function affiliate_created( string $layout = '' ) {
        if ( empty( $layout ) ) {
            return;
        }

		$endpoint = self::AMPLITUDE_ENDPOINT;

		$params = array(
			'action'      => Actions::AFFILIATE_CREATE,
			'layout_type' => $layout,
		);

		$this->amplitude_manager->sendRequest( $endpoint, $params );
	}

	/**
	 * @param string $post_type post type.
	 * @param int    $post_id post id.
	 *
	 * @return void
	 */
	public function affiliate_content_published( string $post_type, int $post_id ): void {
		$endpoint = self::AMPLITUDE_ENDPOINT;
		$params   = array(
			'action' => Actions::AFFILIATE_PUBLISHED,
		);

		$this->amplitude_manager->sendRequest( $endpoint, $params );
	}

	/**
	 * @param string   $new_status new post status.
	 * @param string   $old_status old post status.
	 * @param \WP_Post $post post object.
	 *
	 * @return void
	 */
	public function track_published_post( string $new_status, string $old_status, \WP_Post $post ): void {
		$post_id                   = $post->ID;
		static $is_action_executed = array();

		if ( isset( $is_action_executed[ $post_id ] ) ) {
			return;
		}

		if ( ( 'draft' === $old_status || 'auto-draft' === $old_status ) && $new_status === 'publish' ) {
			if ( (has_block( 'hostinger-affiliate-plugin/block', $post ) || has_shortcode( $post->post_content, 'hostinger-affiliate-table' )) && ! wp_is_post_revision( $post_id ) ) {
				$post_type = get_post_type( $post_id );
				$this->affiliate_content_published( $post_type, $post_id );

				add_option( 'hostinger_affiliate_links_created', true, false );

				$is_action_executed[ $post_id ] = true;
			}
		}
	}
}
