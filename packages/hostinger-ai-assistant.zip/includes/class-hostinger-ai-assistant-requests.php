<?php

class Hostinger_Ai_Assistant_Requests {

	const DEFAULT_AI_GENERATE_CONTENT_URI = 'https://rest-hosting.hostinger.com/v3/wordpress/plugin/generate-content';
	private Hostinger_Ai_Assistant_Config $config_handler;
	private Hostinger_Ai_Assistant_Amplitude $amplitude_events;

	public function __construct() {
		$this->config_handler   = new Hostinger_Ai_Assistant_Config();
		$this->amplitude_events = new Hostinger_Ai_Assistant_Amplitude();
		add_action( 'init', [ $this, 'define_ajax_events' ], 0 );
	}

	public function define_ajax_events(): void {
		$events = [
			'get_content_from_description',
			'redirect_to_post_editor_with_content',
		];

		foreach ( $events as $event ) {
			$ajax_event = 'hts_' . $event;
			add_action( 'wp_ajax_' . $ajax_event, [ $this, $event ] );
			add_action( 'wp_ajax_nopriv_' . $ajax_event, [ $this, $event ] );
		}
	}

	private function get_ai_content_uri( string $default = self::DEFAULT_AI_GENERATE_CONTENT_URI ): string {
		return $this->config_handler->get_config_value( 'ai_generate_content_uri', $default );
	}

	public function get_content_from_description(): void {
		$error_msg        = __( 'Action Failed. Try again or contact support. Apologies.', 'hostinger-ai-assistant' );
		$token_error_msg  = __( 'Action Failed. Something wrong with API. Try again or contact support.', 'hostinger-ai-assistant' );
		$unexpected_error = __( 'An unexpected error occurred. Please try again or contact support.', 'hostinger-ai-assistant' );

		try {
			$nonce       = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
			$description = isset( $_POST['description'] ) ? sanitize_text_field( $_POST['description'] ) : '';
			$token       = Hostinger_Ai_Assistant_Helper::get_api_token();
			$endpoint    = $this->get_ai_content_uri();
			$url         = add_query_arg( array( 'description' => $description ), $endpoint );


			if ( ! $token ) {
				wp_send_json_error( $token_error_msg );
			}

			if ( ! wp_verify_nonce( $nonce, 'generate_content' ) ) {
				wp_send_json_error( $error_msg );
			}

			$headers = array(
				'X-Hpanel-Order-Token' => $token,
			);

			$args = array(
				'headers' => $headers,
				'timeout' => 120
			);

			$response      = wp_remote_get( $url, $args );
			$response_code = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $response ) || $response_code !== 200 ) {
				if ( $error_message = json_decode( $response_body )->error->message ) {
					wp_send_json_error( $error_message );
				} else {
					wp_send_json_error( $unexpected_error );
				}
			} else {
				$generated_content = reset( json_decode( $response['body'] )->data );
				$this->amplitude_events->ai_content_created();
				wp_send_json_success( $generated_content );

			}
		} catch ( Exception $exception ) {
			// Handle the exception
			error_log( 'Error: ' . $exception->getMessage() );
			wp_send_json_error( $unexpected_error );
		}
	}

	public function redirect_to_post_editor_with_content(): void {
		$error_msg        = __( 'Action Failed. Try again or contact support. Apologies.', 'hostinger-ai-assistant' );
		$unexpected_error = __( 'An unexpected error occurred. Please try again or contact support.', 'hostinger-ai-assistant' );
		try {
			$nonce    = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
			$title    = isset( $_POST['title'] ) ? wp_kses_post( $_POST['title'] ) : '';
			$content  = isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '';
			$category = isset( $_POST['category'] ) ? sanitize_text_field( $_POST['category'] ) : '';
			$tags     = isset( $_POST['tags'] ) ? sanitize_text_field( $_POST['tags'] ) : '';

			if ( ! wp_verify_nonce( $nonce, 'create_post' ) ) {
				wp_send_json_error( $error_msg );
			}

			$category_id = $this->get_or_create_category( $category );

			$tags_ids = $this->get_or_create_tags( $tags );

			$post_id = $this->create_draft_post( $title, $content, $category_id, $tags_ids );

			if ( $post_id ) {
				$editor_url = admin_url( 'post.php?action=edit&post=' . $post_id );
				wp_send_json_success( $editor_url );
				exit;
			} else {
				wp_send_json_error( $error_msg );
			}
		} catch ( Exception $exception ) {
			// Handle the exception
			error_log( 'Error: ' . $exception->getMessage() );
			wp_send_json_error( $unexpected_error );
		}
	}

	private function get_or_create_category( $category ): int {
		$category_id = category_exists( $category );
		if ( ! $category_id ) {
			$category_data = array(
				'cat_name'             => $category,
				'category_description' => '',
				'category_nicename'    => sanitize_title( $category )
			);
			$category_id   = wp_insert_category( $category_data );
		}

		return $category_id;
	}

	private function get_or_create_tags( string $tags ): array {
		$error_msg  = __( 'Action Failed. Try again or contact support. Apologies.', 'hostinger-ai-assistant' );
		$tags_array = explode( ',', $tags );
		$tags_ids   = array();
		foreach ( $tags_array as $tag_name ) {
			$tag = term_exists( $tag_name, 'post_tag' );
			if ( ! $tag ) {
				$tag_data = array(
					'slug' => sanitize_title( $tag_name ),
					'name' => $tag_name
				);
				$tag_id   = wp_insert_term( $tag_data['name'], 'post_tag', $tag_data );
				if ( is_wp_error( $tag_id ) ) {
					return array( $error_msg );
				}
				$tag_id = $tag_id['term_id'];
			} else {
				$tag_id = $tag['term_id'];
			}
			$tags_ids[] = (int) $tag_id;
		}

		return $tags_ids;
	}

	private function create_draft_post( string $title, string $content, int $category_id, array $tags_ids ): int {
		$post_data = array(
			'post_title'    => $title,
			'post_content'  => $content,
			'post_status'   => 'draft',
			'post_category' => array( $category_id ),
			'tags_input'    => $tags_ids
		);

		$post_id = wp_insert_post( $post_data );
		//Save meta field when content generated by AI.
		update_post_meta( $post_id, 'hostinger_ai_generated', true );
		$post_type = get_post_type( $post_id );
		$this->amplitude_events->ai_content_saved( $post_type, $post_id );

		return $post_id;
	}

}

new Hostinger_Ai_Assistant_Requests();
