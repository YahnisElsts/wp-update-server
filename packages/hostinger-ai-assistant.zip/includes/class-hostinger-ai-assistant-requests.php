<?php

class Hostinger_Ai_Assistant_Requests {

	const GENERATE_CONTENT_ENDPOINT = 'https://hosting-rest-stage.hostinger.io/v3/wordpress/plugin/generate-content';

	public function __construct() {
		add_action( 'init', [ $this, 'define_ajax_events' ], 0 );
	}

	public function define_ajax_events(): void {
		$events = [
			'get_content_from_description',
			'redirect_to_post_editor_with_content',
		];

		foreach ( $events as $event ) {
			add_action( 'wp_ajax_' . $event, [ __CLASS__, $event ] );
			add_action( 'wp_ajax_nopriv_' . $event, [ __CLASS__, $event ] );
		}
	}

	public function get_content_from_description() {

		$nonce       = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		$description = isset( $_POST['description'] ) ? sanitize_text_field( $_POST['description'] ) : '';
		$token       = Hostinger_Ai_Assistant_Helper::get_api_token();
		$endpoint    = self::GENERATE_CONTENT_ENDPOINT;
		$url         = add_query_arg( array( 'description' => $description ), $endpoint );
		$error_msg   = __('Action Failed. Try again or contact support. Apologies.', 'hostinger-ai-assistant');
		if ( ! wp_verify_nonce( $nonce, 'generate_content' ) ) {
			wp_send_json_error( $error_msg );
		}

		$headers = array(
			'X-Hpanel-Order-Token' => $token,
		);

		$args = array(
			'headers' => $headers,
			'timeout' => 120
		);

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			// Request failed, handle the error
			wp_send_json_error( $response );
		} else {
			$httpCode = wp_remote_retrieve_response_code( $response );
			if ( $httpCode === 200 ) {
				$generated_content = reset( json_decode( $response['body'] )->data );
				wp_send_json_success( $generated_content );
			} else {
				// Request failed, handle the error
				wp_send_json_error( $error_msg );
			}
		}
	}

	function redirect_to_post_editor_with_content() {
		// Retrieve content from $_POST parameters
		$nonce     = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		$title     = isset( $_POST['title'] ) ? wp_kses_post( $_POST['title'] ) : '';
		$content   = isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '';
		$category  = isset( $_POST['category'] ) ? sanitize_text_field( $_POST['category'] ) : '';
		$tags      = isset( $_POST['tags'] ) ? sanitize_text_field( $_POST['tags'] ) : '';
		$error_msg = __( 'Action Failed. Try again or contact support. Apologies.', 'hostinger-ai-assistant' );

		if ( ! wp_verify_nonce( 'xxx', 'create_post' ) ) {
			wp_send_json_error( $error_msg );
		}

		// Check if category exists, create it if not
		$category_id = category_exists( $category );
		if ( ! $category_id ) {
			$category_data = array(
				'cat_name'             => $category,
				'category_description' => '',
				'category_nicename'    => sanitize_title( $category )
			);
			$category_id   = wp_insert_category( $category_data );
		}

		// Check if tags exist, create them if not
		$tags_array = explode( ',', $tags );
		$tags_ids   = array();
		foreach ( $tags_array as $tag_name ) {
			$tag = term_exists( $tag_name, 'post_tag' );
			if ( ! $tag ) {
				$tag_data = array(
					'slug' => sanitize_title( $tag_name ),
					'name' => $tag_name
				);
				$tag_id   = wp_insert_term( $tag_data['name'], 'post_tag', $tag_data );
				if ( is_wp_error( $tag_id ) ) {
					echo $error_msg;

					return;
				}
				$tag_id = $tag_id['term_id'];
			} else {
				$tag_id = $tag['term_id'];
			}
			$tags_ids[] = $tag_id;
		}

		// Create the post data
		$post_data = array(
			'post_title'    => $title,
			'post_content'  => $content,
			'post_status'   => 'draft',
			'post_category' => array( $category_id ),
			'tags_input'    => $tags_ids
		);

		// Insert the draft post
		$post_id = wp_insert_post( $post_data );

		if ( $post_id ) {
			// Redirect to the post editor with the newly created post ID
			$editor_url = admin_url( 'post.php?action=edit&post=' . $post_id );
			wp_send_json_success( $editor_url );
			exit;
		} else {
			// Handle error case
			wp_send_json_error( $error_msg );
		}

	}

}

new Hostinger_Ai_Assistant_Requests();