<?php

class Hostinger_Ai_Assistant_Amplitude {
	const DEFAULT_BASE_REST_API_URL = 'https://rest-hosting.hostinger.com/';
	const AMPLITUDE_ENDPOINT = '/v3/wordpress/plugin/trigger-event';
	private Hostinger_Ai_Assistant_Config $config_handler;

	public function __construct() {
		$this->config_handler = new Hostinger_Ai_Assistant_Config();
		add_action( 'transition_post_status', [ $this, 'track_published_post' ], 10, 3 );
	}

	private function get_base_rest_url( string $default = self::DEFAULT_BASE_REST_API_URL ): string {
		return $this->config_handler->get_config_value( 'base_rest_api', $default );
	}

	private function send_request( string $endpoint, array $params ): void {
		$token = Hostinger_Ai_Assistant_Helper::get_api_token();

		$headers = array(
			'X-Hpanel-Order-Token' => $token,
		);

		$args = array(
			'headers' => $headers,
			'body'    => [ 'params' => $params ]
		);

		$response = wp_remote_post( $endpoint, $args );

		if ( is_wp_error( $response ) ) {
			error_log( $response );
		}
	}

	public function ai_content_created(): void {
		$endpoint = $this->get_base_rest_url() . self::AMPLITUDE_ENDPOINT;

		$params = array(
			'action' => 'wordpress.ai_content.create'
		);

		$this->send_request( $endpoint, $params );
	}

	public function ai_content_saved( string $post_type, int $post_id ): void {
		$endpoint = $this->get_base_rest_url() . self::AMPLITUDE_ENDPOINT;

		$params = array(
			'action'       => 'wordpress.ai_content.created',
			'content_type' => $post_type,
			'content_id'   => $post_id,
		);

		$this->send_request( $endpoint, $params );
	}

	public function ai_content_published( string $post_type, int $post_id ): void {
		$endpoint = $this->get_base_rest_url() . self::AMPLITUDE_ENDPOINT;

		$params = array(
			'action'       => 'wordpress.ai_content.published',
			'content_type' => $post_type,
			'content_id'   => $post_id,
		);

		$this->send_request( $endpoint, $params );
	}

	public function track_published_post( string $new_status, string $old_status, WP_Post $post ): void {
		$post_id              = $post->ID;
		$ai_content_generated = get_post_meta( $post_id, 'hostinger_ai_generated', true );

		if ( ( 'draft' === $old_status || 'auto-draft' === $old_status ) && $new_status === 'publish' ) {

			if ( $ai_content_generated && ! wp_is_post_revision( $post_id ) ) {
				$post_type = get_post_type( $post_id );
				$this->ai_content_published( $post_type, $post_id );
			}

		}
	}
}

new Hostinger_Ai_Assistant_Amplitude();
