<?php

class Hostinger_Ai_Assistant_Requests {
	const GENERATE_CONTENT_IMAGES_ACTION = '/v3/wordpress/plugin/get-images';
	const GENERATE_CONTENT_ACTION = '/v3/wordpress/plugin/generate-content';
	const GET_UNSPLASH_IMAGE_ACTION = '/v3/wordpress/plugin/download-image';
	private $client;
	private $amplitude;
	private $generate_content;
	private $config_handler;

	private $helper;

	public function __construct() {
		$this->helper           = new Hostinger_Ai_Assistant_Helper();
		$this->config_handler   = new Hostinger_Ai_Assistant_Config();
		$this->client           = new Hostinger_Ai_Assistant_Requests_Client( $this->config_handler->get_config_value( 'base_rest_api', HOSTINGER_AI_ASSISTANT_REST_URI ), [
			'X-Hpanel-Order-Token' => $this->helper::get_api_token(),
		] );
		$this->amplitude        = new Hostinger_Ai_Assistant_Amplitude();
		$this->generate_content = new Hostinger_Ai_Assistant_Content_Generation();

		add_action( 'init', [ $this, 'define_ajax_events' ], 0 );
	}

	public function define_ajax_events(): void {
		$events = [
			'get_content_from_description',
			'redirect_to_post_editor_with_content',
		];

		foreach ( $events as $event ) {
			$ajax_event = 'hts_' . $event;
			add_action( 'wp_ajax_' . $ajax_event, [ $this, $event ] );
			add_action( 'wp_ajax_nopriv_' . $ajax_event, [ $this, $event ] );
		}
	}

	public function get_content_from_description(): void {
		$error_msg        = __( 'Action Failed. Try again or contact support. Apologies.', 'hostinger-ai-assistant' );
		$unexpected_error = __( 'An unexpected error occurred. Please try again or contact support.', 'hostinger-ai-assistant' );

		try {
			$nonce       = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
			$description = isset( $_POST['description'] ) ? sanitize_text_field( $_POST['description'] ) : '';

			if ( ! wp_verify_nonce( $nonce, 'generate_content' ) ) {
				$this->helper->ajax_error_message( $error_msg );
			}

			$response = $this->client->get( self::GENERATE_CONTENT_ACTION, [
				'description' => $description,
			] );

			$response_code = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $response ) || $response_code !== 200 ) {
				$error_message = isset( json_decode( $response_body )->error->message )
					? json_decode( $response_body )->error->message
					: $unexpected_error;
				$this->helper->ajax_error_message( $error_message );
			} else {
				$generated_content = reset( json_decode( $response['body'] )->data );

				if ( isset( $generated_content->tags[0] ) && $generated_content->tags[0] !== '' ) {
					$unsplash_image_data = $this->get_unsplash_image_data( $generated_content->tags[0] );
					if ( $unsplash_image_data->image ) {
						$generated_content->image = $unsplash_image_data->image;
					}
				}

				$this->amplitude->ai_content_created();
				wp_send_json_success( $generated_content );
			}
		} catch ( Exception $exception ) {
			$this->helper->ajax_error_message( 'Error: ' . $exception->getMessage() );
		}
	}


	public function redirect_to_post_editor_with_content(): void {
		$error_msg = __( 'Action Failed. Try again or contact support. Apologies.', 'hostinger-ai-assistant' );

		try {
			$nonce    = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
			$title    = isset( $_POST['title'] ) ? wp_kses_post( $_POST['title'] ) : '';
			$content  = isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '';
			$category = isset( $_POST['category'] ) ? sanitize_text_field( $_POST['category'] ) : '';
			$tags     = isset( $_POST['tags'] ) ? sanitize_text_field( $_POST['tags'] ) : '';

			if ( ! wp_verify_nonce( $nonce, 'create_post' ) ) {
				$this->helper->ajax_error_message( $error_msg );
			}

			$category_id       = $this->generate_content->get_or_create_category( $category );
			$tags_ids          = $this->generate_content->get_or_create_tags( $tags );
			$image_data        = $this->get_unsplash_image_data( $tags );
			$featured_image_id = 0;

			if ( ! empty( get_object_vars( $image_data ) ) ) {
				$featured_image_id = $this->get_uploaded_unsplash_image( $image_data );
			}

			$post_id = $this->generate_content->create_draft_post( $title, $content, $category_id, $tags_ids, $featured_image_id );

			if ( $post_id ) {
				$editor_url = 'post.php?action=edit&post=' . $post_id;
				wp_send_json_success( $editor_url );
				exit;
			}

			wp_send_json_error( $error_msg );
		} catch ( Exception $exception ) {
			$this->helper->ajax_error_message( 'Error: ' . $exception->getMessage() );
		}
	}

	private function get_uploaded_unsplash_image( object $image_data ): int {
		try {
			$params        = json_encode( array(
				'domain'             => ( new Hostinger_Ai_Assistant_Helper() )->get_host_info(),
				'download_directory' => wp_upload_dir()['basedir'],
				'unsplash_image'     => $image_data->image,
				'track_download_uri' => $image_data->download_location,
			) );
			$headers       = array( 'Content-Type' => 'application/json' );
			$response      = $this->client->post( self::GET_UNSPLASH_IMAGE_ACTION, $params, $headers );
			$response_code = wp_remote_retrieve_response_code( $response );

			if ( $response_code !== 200 ) {
				return 0;
			}

			if ( is_wp_error( $response ) ) {
				$this->helper->ajax_error_message( 'Error: ' . $response->get_error_message() );
			}

			$image_path = json_decode( $response['body'] )->data->result;
			$image_id   = $this->generate_content->upload_image_to_media_library( $image_path, $image_data );

			return $image_id;
		} catch ( Exception $exception ) {
			$this->helper->ajax_error_message( 'Error: ' . $exception->getMessage() );
		}
	}

	private function get_unsplash_image_data( string $tags ): object {
		$unexpected_error = __( 'An unexpected error occurred. Please try again or contact support.', 'hostinger-ai-assistant' );

		if ( ! isset( $tags ) || $tags == '' ) {
			$this->helper->ajax_error_message( $unexpected_error );
		}

		$keywords = explode( ',', $tags );

		try {
			$response = $this->client->get( self::GENERATE_CONTENT_IMAGES_ACTION, [
				'keywords' => array( $keywords[0] ),
				'amount'   => 1
			] );

			$response_code = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );
			$response_data = json_decode( $response_body )->data;

			if ( empty( $response_data ) ) {
				return new stdClass();
			}

			if ( is_wp_error( $response ) || $response_code !== 200 ) {
				$error_message = isset( json_decode( $response_body )->error->message )
					? json_decode( $response_body )->error->message
					: $unexpected_error;
				$this->helper->ajax_error_message( $error_message );
			} else {
				$response = reset( json_decode( $response_body )->data );

				return $response;
			}
		} catch ( Exception $exception ) {
			$this->helper->ajax_error_message( $exception->getMessage() );

		}
	}

}

new Hostinger_Ai_Assistant_Requests();
