<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class Hostinger_Helper {

	/**
	 *
	 * Check if plugin is active
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public static function is_plugin_active( $plugin_slug ): bool {
		$active_plugins = (array) get_option( 'active_plugins', array() );
		foreach ( $active_plugins as $active_plugin ) {
			if ( strpos( $active_plugin, $plugin_slug . '.php' ) !== false ) {
				return true;
			}
		}

		return false;
	}

	public static function get_api_token(): string {
		require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';

		$api_token  = '';
		$token_path = HOSTINGER_WP_TOKEN;
		$filesystem = new WP_Filesystem_Direct( true );
		$token_file = $filesystem->get_contents( $token_path );

		if ( file_exists( $token_path ) && ! empty( $token_file ) ) {
			$api_token = $token_file;
		}

		return $api_token;
	}

	/**
	 *
	 * Get the host info (domain, subdomain, subdirectory)
	 *
	 * @since    1.7.0
	 * @access   public
	 */

	public function get_host_info(): string {
		$host     = sanitize_text_field( $_SERVER['HTTP_HOST'] ?? '' );
		$site_url = get_site_url();
		$site_url = preg_replace( '#^https?://#', '', $site_url );

		if ( ! empty( $site_url ) && ! empty( $host ) && strpos( $site_url, $host ) === 0 ) {
			if ( $site_url === $host ) {
				return $host;
			} else {
				return substr( $site_url, strlen( $host ) + 1 );
			}
		}

		return $host;
	}


}

$hostiner_helper = new Hostinger_Helper();
