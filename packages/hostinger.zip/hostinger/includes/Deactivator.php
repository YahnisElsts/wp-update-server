<?php

namespace Hostinger;

defined( 'ABSPATH' ) || exit;

class Deactivator {
	public static function deactivate(): void {
	}
}
