<?php

namespace Hostinger\Admin;

use Hostinger\Helper;
use Hostinger\WpHelper\Utils;

defined( 'ABSPATH' ) || exit;

class Hooks {
    /**
     * @var Helper
     */
	private Helper $helper;

    /**
     * @var Utils
     */
    private Utils $utils;

	public function __construct() {
		$this->helper = new Helper();
        $this->utils = new Utils();
		add_action( 'admin_footer', array( $this, 'rate_plugin' ) );
	}

    /**
     * @return void
     */
	public function rate_plugin(): void {
        if ( !$this->utils->isThisPage('wp-admin/admin.php?page=' . Menu::MENU_SLUG) ) {
            return;
        }

        require_once HOSTINGER_ABSPATH . 'includes/Admin/Views/Partials/RateUs.php';
	}
}
