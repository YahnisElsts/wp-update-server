<?php

namespace Hostinger\Tests\Integration\Admin\Menu;

use Hostinger\Tests\Integration\TestCase;
use Hostinger_Admin_Menu;
use WP_Screen;

class HostingerAdminMenuTest extends TestCase {

	private Hostinger_Admin_Menu $hostinger_admin_menu;

	public function setUp(): void {
		parent::setUp();

		require_once HOSTINGER_ABSPATH . 'includes/admin/class-hostinger-admin-menu.php';
		$this->hostinger_admin_menu = new Hostinger_Admin_Menu();
	}

	public function test_register_hostinger_menu(): void {
		global $menu, $submenu;

		$screen = get_current_screen();
		$this->loginAdminUser();
		WP_Screen::get( 'dashboard' )->set_current_screen();
		$this->hostinger_admin_menu->admin_menu();
		$this->assertTrue( is_admin() );
		$this->assertEquals( $this->buildAdminUrl( 'admin.php?page=hostinger' ), menu_page_url( 'hostinger' ) );
		$this->assertEquals( 'Hostinger', $menu[1][0] );
		$this->assertEquals( 'manage_options', $menu[1][1] );
		$this->assertEquals( 'hostinger', $menu[1][2] );
		$this->assertEquals( 'Hostinger', $menu[1][3] );
		$this->assertEquals( 'menu-top toplevel_page_hostinger', $menu[1][4] );
		$this->assertEquals( 'toplevel_page_hostinger', $menu[1][5] );
		$icon = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjEiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyMSAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0wLjAwMDE5OTY1MyAxMS4yMzY4VjAuMDAwMzk4MjM1TDUuNjcxMzMgMy4wMjQzNlY4LjA4NjkxTDEzLjE3ODggOC4wOTA1M0wxOC45NDE5IDExLjIzNjhIMC4wMDAxOTk2NTNaTTE0LjcxNCA3LjE2MDQ3VjBMMjAuNTM4IDIuOTQ4NzJWMTAuNTQzN0wxNC43MTQgNy4xNjA0N1pNMTQuNzE0IDIwLjg5NDJWMTUuODc1M0w3LjE0ODYyIDE1Ljg3QzcuMTU1NjggMTUuOTAzNCAxLjI4OTg0IDEyLjY3MzUgMS4yODk4NCAxMi42NzM1TDIwLjUzOCAxMi43NjM4VjI0TDE0LjcxNCAyMC44OTQyWk0wIDIwLjg5NDFMMC4wMDAyMDE3NjkgMTMuNTUxNEw1LjY3MTMzIDE2Ljg1NDZWMjMuODQyN0wwIDIwLjg5NDFaIiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4K'; //phpcs:ignore
		$this->assertEquals( $icon, $menu[1][6] );

		$hostingerSubmenu = $submenu['hostinger'];

		$this->assertCount( 2, $hostingerSubmenu );
		$this->assertEquals( 'Get started', $hostingerSubmenu[1][0] );
		$this->assertEquals( 'manage_options', $hostingerSubmenu[1][1] );
		$this->assertEquals( 'hostinger&#home', $hostingerSubmenu[1][2] );
		$this->assertEquals( 'Get started', $hostingerSubmenu[1][3] );
		$this->assertEquals( 'Learn', $hostingerSubmenu[2][0] );
		$this->assertEquals( 'manage_options', $hostingerSubmenu[2][1] );
		$this->assertEquals( 'hostinger&#learn', $hostingerSubmenu[2][2] );
		$this->assertEquals( 'Learn', $hostingerSubmenu[2][3] );

		$GLOBALS['current_screen'] = $screen;
	}
}
