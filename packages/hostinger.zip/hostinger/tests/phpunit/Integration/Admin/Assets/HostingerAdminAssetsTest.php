<?php

namespace Hostinger\Tests\Integration\Admin\Assets;

use _WP_Dependency;
use Hostinger\Tests\Integration\TestCase;
use Hostinger_Admin_Assets;

class HostingerAdminAssetsTest extends TestCase {

	public function setUp(): void {
		parent::setUp();
		require_once HOSTINGER_ABSPATH . 'includes/admin/class-hostinger-admin-assets.php';
		$hostinger_admin_assets = new Hostinger_Admin_Assets();
		$hostinger_admin_assets->admin_scripts();
		$hostinger_admin_assets->admin_styles();
	}

	public function test_loaded_assets(): void {
		$this->assertTrue( wp_script_is( 'hostinger_main_scripts' ) );
		$this->assertTrue( wp_style_is( 'hostinger_main_styles' ) );
	}

	public function test_check_scripts(): void {
		/** @var _WP_Dependency $scripts */
		$script = wp_scripts()->query( 'hostinger_main_scripts' );

		$this->assertEquals( 'hostinger_main_scripts', $script->handle );
		$this->assertStringContainsString( 'plugins/hostinger/assets/js/main.js', $script->src );
	}

	public function test_check_styles(): void {
		/** @var _WP_Dependency $style */
		$style = wp_styles()->query( 'hostinger_main_styles' );

		$this->assertEquals( 'hostinger_main_styles', $style->handle );
		$this->assertStringContainsString( 'plugins/hostinger/assets/css/main.css', $style->src );
	}
}
