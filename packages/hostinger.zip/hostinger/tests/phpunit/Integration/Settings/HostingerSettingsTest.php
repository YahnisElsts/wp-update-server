<?php

namespace Hostinger\Tests\Integration\Settings;

use Hostinger\Tests\Integration\TestCase;
use Hostinger_Settings;

class HostingerSettingsTest extends TestCase {
	private Hostinger_Settings $settings;

	public function setUp(): void {
		parent::setUp();
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger-settings.php';

		$this->settings = new Hostinger_Settings();
	}

	public function test_get_setting(): void {
		Hostinger_Settings::update_setting( 'test_setting', 'test_value' );
		$value = Hostinger_Settings::get_setting( 'test_setting' );

		$this->assertEquals( 'test_value', $value );
	}

	public function test_user_segment_begginer(): void {
		Hostinger_Settings::update_setting( 'survey.website.created_by', Hostinger_Settings::MYSELF );
		Hostinger_Settings::update_setting( 'survey.website.for', Hostinger_Settings::MYSELF );
		Hostinger_Settings::update_setting( 'survey.website.need_help', 1 );

		$this->settings->set_user_segment();

		$segment = Hostinger_Settings::get_setting( 'user_segment' );

		$this->assertEquals( Hostinger_Settings::BUSINESS_BEGINNER_SEGMENT, $segment );
	}

	public function test_user_segment_learner(): void {
		Hostinger_Settings::update_setting( 'survey.work_at', Hostinger_Settings::FREELANCER );
		Hostinger_Settings::update_setting( 'survey.website.need_help', 1 );

		$this->settings->set_user_segment();

		$segment = Hostinger_Settings::get_setting( 'user_segment' );

		$this->assertEquals( Hostinger_Settings::LEARNER_SEGMENT, $segment );
	}

	public function test_user_segment_business_owner(): void {
		Hostinger_Settings::update_setting( 'survey.website.created_by', Hostinger_Settings::DEVELOPER );
		Hostinger_Settings::update_setting( 'survey.website.for', Hostinger_Settings::MYSELF );

		$this->settings->set_user_segment();

		$segment = Hostinger_Settings::get_setting( 'user_segment' );

		$this->assertEquals( Hostinger_Settings::BUSINESS_OWNER_SEGMENT, $segment );
	}
}
