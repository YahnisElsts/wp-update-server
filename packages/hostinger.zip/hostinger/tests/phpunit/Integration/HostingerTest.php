<?php

namespace Hostinger\Tests\Integration;

class HostingerTest extends TestCase {
	public function test_constants_defined(): void {
		$this->assertTrue( defined( 'HOSTINGER_ABSPATH' ) );
		$this->assertTrue( defined( 'HOSTINGER_VERSION' ) );
		$this->assertTrue( defined( 'HOSTINGER_PLUGIN_FILE' ) );
		$this->assertTrue( defined( 'HOSTINGER_PLUGIN_URL' ) );
		$this->assertTrue( defined( 'HOSTINGER_ASSETS_URL' ) );
		$this->assertTrue( defined( 'HOSTINGER_WP_CONFIG_PATH' ) );
		$this->assertTrue( defined( 'HOSTINGER_WP_TOKEN' ) );
		$this->assertTrue( defined( 'HOSTINGER_REST_URI' ) );
	}

	public function test_constants_contains_correct_values(): void {
		$this->assertEquals( '1.9.6', HOSTINGER_VERSION );
		$this->assertEquals( '/var/www/html/wp-content/plugins/hostinger/hostinger.php', HOSTINGER_PLUGIN_FILE );
		$this->assertEquals( '/tmp/wordpress/.private/config.json', HOSTINGER_WP_CONFIG_PATH );
		$this->assertEquals( '/var/www/.api_token', HOSTINGER_WP_TOKEN );
		$this->assertEquals( 'https://rest-hosting.hostinger.com', HOSTINGER_REST_URI );
	}
}
