<?php

namespace Hostinger\Tests\Integration;

use Hostinger;
use WP_UnitTestCase;

abstract class TestCase extends WP_UnitTestCase {
	protected const BASE_URL = 'http://example.org';

	protected Hostinger $hostinger;

	public function setUp(): void {
		parent::setUp();
		require_once HOSTINGER_ABSPATH . 'includes/class-hostinger.php';
		$this->hostinger = new Hostinger();
		$this->hostinger->bootstrap();
	}

	public function tearDown(): void {
		parent::tearDown();
		unload_textdomain( 'hostinger' );
	}

	protected function loginAdminUser(): void {
		$user = $this->factory->user->create_and_get( [
			'role' => 'administrator',
		] );

		wp_set_current_user( $user->ID );
	}

	protected function buildAdminUrl( string $path ): string {
		return sprintf( '%s/wp-admin/%s', self::BASE_URL, $path );
	}
}
