export const STORE_PERSISTENT_KEYS = {
  GENERAL_DATA_STORE: "general-data-store",
} as const;
