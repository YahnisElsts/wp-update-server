<script async src="https://cdn.ampproject.org/v0.js"></script>
<script custom-element="amp-youtube" src="https://cdn.ampproject.org/v0/amp-youtube-0.1.js" async></script>