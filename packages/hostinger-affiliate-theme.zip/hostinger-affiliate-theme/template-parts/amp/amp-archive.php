<?php get_template_part( 'template-parts/amp/partials/amp', 'header' ); ?>
<?php get_template_part( 'template-parts/amp/partials/amp', 'footer' ); ?>