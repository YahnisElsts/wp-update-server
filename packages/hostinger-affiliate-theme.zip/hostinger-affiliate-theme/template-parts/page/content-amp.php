<?php orbital_amp_content(get_the_content());
