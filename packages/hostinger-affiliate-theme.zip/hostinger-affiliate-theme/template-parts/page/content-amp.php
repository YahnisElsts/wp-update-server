<?php hostinger_aft_amp_content(get_the_content());
