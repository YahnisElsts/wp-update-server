<article id="post-<?php the_ID(); ?>" class="entry-item <?php echo hostinger_aft_customize_option('hostinger_aft_loop_columns'); ?>">
	<a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark">
		<?php
		the_post_thumbnail('thumbnail');
		the_title('<h4 class="entry-title">', '</h4>');
		?>
	</a>
</article>
