<?php
if (! is_active_sidebar('sidebar-404')) {
	return;
}
?>

<?php dynamic_sidebar('sidebar-404');

