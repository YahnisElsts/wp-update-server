<?php

/**
 * Customizer API
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Hostinger AFT
 * @since 1.0
 */
/*
 *
 * text, checkbox, radio, select, textarea, dropdown-pages
 * email, url, number, hidden, and date
 *
 */

require get_template_directory() . '/inc/customizer-parts/customizer-sanitize.php';
require get_template_directory() . '/inc/customizer-parts/customizer-control.php';
require get_template_directory() . '/inc/customizer-parts/customizer-fonts.php';
require get_template_directory() . '/inc/customizer-parts/customizer-misc.php';
require get_template_directory() . '/inc/customizer-parts/customizer-options.php';
require get_template_directory() . '/inc/customizer-parts/customizer-advertisment.php';
require get_template_directory() . '/inc/customizer-parts/customizer-social.php';
require get_template_directory() . '/inc/customizer-parts/customizer-woocommerce.php';
require get_template_directory() . '/inc/customizer-parts/customizer-export-import.php';
require get_template_directory() . '/inc/customizer-parts/customizer-gdpr.php';
require get_template_directory() . '/inc/customizer-parts/customizer-performance.php';
require get_template_directory() . '/inc/customizer-parts/customizer-toc.php';

//Actions
add_action('customize_register', 'hostinger_aft_customizer');
add_action('customize_preview_init', 'hostinger_aft_customizer_live_preview');

//Options
add_action('wp_head', 'hostinger_aft_customize_css');
add_action('wp_head', 'hostinger_aft_fonts_head');
add_action('wp_head', 'hostinger_aft_enqueue_analytics');
add_action('wp_head', 'hostinger_aft_enqueue_adsense');

function hostinger_aft_customizer_live_preview() {
    wp_enqueue_script('hostinger_aft_customizer_js', get_template_directory_uri() . '/assets/js/customizer.js', array('jquery', 'customize-preview'), '20120187', true);
}

function hostinger_aft_customizer($wp_customize) {
    $arrayFonts = hostinger_aft_customizer_fonts();
    $sections = hostinger_aft_customizer_sections();
    $settings = hostinger_aft_customizer_settings();
    $controls = hostinger_aft_customizer_controls($arrayFonts);

    //Sections
    foreach ($sections as $section) {
        $wp_customize->add_section($section['name'], array(
            'title' => $section['title'],
            'description' => $section['description'],
            'priority' => $section['priority'],
        ));
    }

    //Settings
    foreach ($settings as $setting) {
        $wp_customize->add_setting($setting['name'], array(
            'default' => $setting['default'],
            'transport' => $setting['transport'],
                //'sanitize_callback' => $setting['sanitize_callback'],
        ));
    }

    //Controls
    foreach ($controls as $control) {
        $wp_customize->add_control(new WP_Customize_Control(
                        $wp_customize,
                        $control['setting'],
                        $control['info']
        ));
    }

    hostinger_aft_woocommerce_customizer($wp_customize);
    hostinger_aft_advertisment_customizer($wp_customize);
    hostinger_aft_social_customizer($wp_customize);
    hostinger_aft_gdpr_customizer($wp_customize);
    hostinger_aft_performance_customizer($wp_customize);
    hostinger_aft_content_table($wp_customize);
}

function hostinger_aft_customize_option($option, $default = null) {

    global $hostinger_aft_customizer_defaults;

    if (!is_null(get_theme_mod($option)) && get_theme_mod($option)) {
        return get_theme_mod($option);
    }

    if (isset($hostinger_aft_customizer_defaults[$option])) {
        return get_theme_mod($option, $hostinger_aft_customizer_defaults[$option]);
    }

    if (isset($default)) {
        return $default;
    }

    return get_theme_mod($option);
}

function hostinger_aft_delete_minified_files_after_save() {
    $cache_path = dirname(__FILE__) . '/../cache';
    if (is_dir($cache_path)) {
        $files = glob($cache_path . '/*');

        foreach ($files as $file) {
            @unlink($file);
        }
    }
}

add_action('customize_save_after', 'hostinger_aft_delete_minified_files_after_save');

