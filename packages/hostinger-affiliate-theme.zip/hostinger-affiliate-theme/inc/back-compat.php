<?php
/**
 * Back Compatibility
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Hostinger AFT
 * @since 1.0
 */

add_action('after_switch_theme', 'hostinger_aft_switch_theme');
add_action('load-customize.php', 'hostinger_aft_customize');
add_action('template_redirect', 'hostinger_aft_preview');

function hostinger_aft_switch_theme()
{
	switch_theme(WP_DEFAULT_THEME);
	unset($_GET['activated']);
	add_action('admin_notices', 'hostinger_aft_upgrade_notice');
}

function hostinger_aft_upgrade_notice()
{
	$message = sprintf(__('Hostinget Affiliate Theme requires at least WordPress version 4.7. You are running version %s. Please upgrade and try again.', 'hostinger-affiliate-theme'), $GLOBALS['wp_version']);
	printf('<div class="error"><p>%s</p></div>', $message);
}

function hostinger_aft_customize()
{
	wp_die(sprintf(__('Hostinger Affiliate Theme requires at least WordPress version 4.7. You are running version %s. Please upgrade and try again.', 'hostinger-affiliate-theme'), $GLOBALS['wp_version']), '', array(
		'back_link' => true,
	));
}

function hostinger_aft_preview()
{
	if (isset($_GET['preview'])) {
		wp_die(sprintf(__('Hostinger Affiliate Theme requires at least WordPress version 4.7. You are running version %s. Please upgrade and try again.', 'hostinger-affiliate-theme'), $GLOBALS['wp_version']));
	}
}
