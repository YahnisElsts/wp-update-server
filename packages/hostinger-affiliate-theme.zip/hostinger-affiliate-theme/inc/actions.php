<?php
/**
 * All hooks from Hostinger AFT
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Hostinger AFT
 * @since 1.0
 */



//Page
add_action('hostinger_aft_before_page_content', 'hostinger_aft_yoast_breadcrumbs', 10);
add_action('hostinger_aft_before_page_content', 'hostinger_aft_thumbnail_post', 10);

//Single
add_action('hostinger_aft_before_single_content', 'hostinger_aft_yoast_breadcrumbs', 10);
add_action('hostinger_aft_before_single_content', 'hostinger_aft_thumbnail_post', 10);
add_action('hostinger_aft_before_single_comments', 'hostinger_aft_related_posts', 10);
add_action('wp_head', 'hostinger_aft_single_header_code', 10);
add_action('wp_footer', 'hostinger_aft_single_footer_code', 10);

//Yoast Filters
add_action('wpseo_register_extra_replacements', 'hostinger_aft_title_replacements');

//WP Gallery
remove_shortcode('gallery', 'gallery_shortcode');
add_shortcode('gallery', 'hostinger_aft_custom_gallery_shortcode');
add_filter('attachment_fields_to_edit', 'hostinger_aft_attachment_custom_link', 10, 2);
add_filter('attachment_fields_to_save', 'hostinger_aft_attachment_custom_link_save', 10, 2);
add_action('print_media_templates', 'hostinger_aft_gallery_settings');

//Shortcodes
add_shortcode('hostinger_aft_cluster', 'hostinger_aft_cluster_shortcode');

//MetaBox
add_action('add_meta_boxes', 'hostinger_aft_add_meta_boxes');
add_action('admin_footer', 'hostinger_aft_admin_footer');
add_action('save_post', 'hostinger_aft_save_post');

//Json-ld
add_action('wp_footer', 'hostinger_aft_markup_site');

//Jetpack
add_action('after_setup_theme', 'hostinger_aft_jetpack_setup');


//Cleaner
remove_action('wp_head', 'rest_output_link_wp_head', 10);
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');
// add_filter('comment_text', 'wp_filter_nohtml_kses');
add_filter('comment_text_rss', 'wp_filter_nohtml_kses');
add_filter('comment_excerpt', 'wp_filter_nohtml_kses');


//Extra Options
add_filter('excerpt_length', 'hostinger_aft_excerpt_length', 999);
add_filter('excerpt_more', 'hostinger_aft_excerpt_more');
add_filter('mce_buttons', 'hostinger_aft_next_page', 1, 2);
add_filter('body_class', 'hostinger_aft_check_sidebar_class');
add_filter('body_class', 'hostinger_aft_layout_menu_class');
add_filter('get_custom_logo', 'hostinger_aft_customize_logo_html');
//add_action('wp_head','hostinger_aft_the_custom_jumbotron');
add_action('init', 'hostinger_aft_excerpts_to_pages');
add_action('edit_category', 'hostinger_aft_category_transient_flusher');
add_action('save_post', 'hostinger_aft_category_transient_flusher');
add_action('admin_head', 'hostinger_aft_add_custom_buttons');
add_filter('upload_mimes', 'hostinger_aft_mime_types');
add_filter('post_class', 'hostinger_aft_remove_hentry');
add_filter('edit_category_form_fields', 'hostinger_aft_cat_description');
add_action('edited_category', 'hostinger_aft_save_extra_category_fields');
add_filter('comment_form_defaults', 'hostinger_aft_comment_textarea');


//Advertisment
add_action('hostinger_aft_before_page_home_content', 'hostinger_aft_advertisment_before_home');
add_action('hostinger_aft_after_featured_home', 'hostinger_aft_advertisment_after_featured_home');
add_action('hostinger_aft_after_page_home_content', 'hostinger_aft_advertisment_after_home');
add_action('hostinger_aft_before_single_content', 'hostinger_aft_advertisment_before_single_content');
add_filter('the_content', 'hostinger_aft_advertisment_middle_single_content');
add_action('hostinger_aft_after_single_content', 'hostinger_aft_advertisment_after_single_content');
add_action('hostinger_aft_before_page_content', 'hostinger_aft_advertisment_before_page_content');
add_filter('the_content', 'hostinger_aft_advertisment_middle_page_content');
add_action('hostinger_aft_after_page_content', 'hostinger_aft_advertisment_after_page_content');
add_action('hostinger_aft_before_archive_loop', 'hostinger_aft_advertisment_before_archive');
add_action('hostinger_aft_after_featured_archive', 'hostinger_aft_advertisment_after_featured_archive');
add_action('hostinger_aft_after_archive_content', 'hostinger_aft_advertisment_after_archive');
add_action('hostinger_aft_after_archive_content', 'hostinger_aft_advertisment_after_description_archive');
add_action('hostinger_aft_before_page_home_content', 'hostinger_aft_advertisment_before_home_mobile');
add_action('hostinger_aft_after_featured_home', 'hostinger_aft_advertisment_after_featured_home_mobile');
add_action('hostinger_aft_after_page_home_content', 'hostinger_aft_advertisment_after_home_mobile');
add_action('hostinger_aft_before_single_content', 'hostinger_aft_advertisment_before_single_content_mobile');
add_filter('the_content', 'hostinger_aft_advertisment_middle_single_content_mobile');
add_action('hostinger_aft_after_single_content', 'hostinger_aft_advertisment_after_single_content_mobile');
add_action('hostinger_aft_before_page_content', 'hostinger_aft_advertisment_before_page_content_mobile');
add_filter('the_content', 'hostinger_aft_advertisment_middle_page_content_mobile');
add_action('hostinger_aft_after_page_content', 'hostinger_aft_advertisment_after_page_content_mobile');
add_action('hostinger_aft_before_archive_loop', 'hostinger_aft_advertisment_before_archive_mobile');
add_action('hostinger_aft_after_featured_archive', 'hostinger_aft_advertisment_after_featured_archive_mobile');
add_action('hostinger_aft_after_archive_content', 'hostinger_aft_advertisment_after_archive_mobile');
add_action('hostinger_aft_after_archive_content', 'hostinger_aft_advertisment_after_description_archive_mobile');

//Social
add_action('hostinger_aft_after_footer', 'hostinger_aft_social_share_fixed_bottom');
add_action('hostinger_aft_after_footer', 'hostinger_aft_social_share_fixed_side');
add_action('hostinger_aft_before_single_content', 'hostinger_aft_social_share_before_content');
add_action('hostinger_aft_after_single_content', 'hostinger_aft_social_share_after_content');
add_action('hostinger_aft_before_page_content', 'hostinger_aft_social_share_before_content');
add_action('hostinger_aft_after_page_content', 'hostinger_aft_social_share_after_content');
add_action('hostinger_aft_before_page_home_content', 'hostinger_aft_social_share_before_content');
add_action('hostinger_aft_after_page_home_content', 'hostinger_aft_social_share_after_content');
add_action('hostinger_aft_before_archive_loop', 'hostinger_aft_social_share_before_content');
add_action('hostinger_aft_after_archive_loop', 'hostinger_aft_social_share_after_content');
add_action('hostinger_aft_before_woocommerce_loop', 'hostinger_aft_social_share_before_content');
add_action('hostinger_aft_after_woocommerce_loop', 'hostinger_aft_social_share_after_content');

//GDPR
add_action('wp_footer', 'hostinger_aft_gdpr_enqueue_js');

//Performance
add_action('wp_head', 'hostinger_aft_preload_func', 1);
add_action('wp_head', 'hostinger_aft_preconnect_func', 1);
add_action('wp_head', 'hostinger_aft_prefetch_func', 1);

add_action('wp_print_scripts', 'hostinger_aft_unload_js', 9999999999);
add_action('wp_print_styles', 'hostinger_aft_unload_css', 9999999999);


//toc
function hostinger_aft_add_toc_wrapper ( $content ) {
    if (!is_admin() && !wp_doing_ajax() && ( get_theme_mod('hostinger_aft_enable_' . get_post_type() ) ) ) {
        return '<div class="toc-content">'.$content . '</div>';
    }
    return $content;
}
add_filter( 'the_content', 'hostinger_aft_add_toc_wrapper', 1);
