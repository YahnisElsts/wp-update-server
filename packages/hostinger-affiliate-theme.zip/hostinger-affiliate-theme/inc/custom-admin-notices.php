<?php
require get_template_directory() . '/vendor/admin-notices/persist-admin-notices-dismissal.php';
add_action('admin_head', function () { ?>
    <style>
        .hostinger-aft-banner-desciption-content b {
            color: #2271b1;
            font-weight: bolder;
        }

        .hostinger-aft-banner-button-link {
            margin-top: 10px
        }

        .hostinger-aft-banner-promo,
        .hostinger-aft-banner-promo-full {
            display: flex;
            padding: 0
        }

        .hostinger-aft-banner-promo-full {
            margin: 0;
            padding: 0
        }

        .hostinger-aft-banner-promo-logo {
            width: 90px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding-left: 10px
        }

        .hostinger-aft-banner-promo-full .hostinger-aft-banner-promo-logo {
            margin: 0;
            width: 90px;
            height: 90px
        }

        .hostinger-aft-banner-promo-content {
            margin-left: 25px
        }

        .hostinger-aft-banner-promo-full .hostinger-aft-banner-promo-content {
            width: 75%
        }

        .hostinger-aft-banner-promo-content h1 {
            font-weight: 600;
            color: #538ac6;
            margin-top: 10px
        }

        .hostinger-aft-banner-title {
            font-size: 1.3em;
            margin: 8px 0 5px 0
        }

        .hostinger-aft-banner-promo-slacklogo {
            width: 75px;
            height: 75px;
            display: inline-block;
            padding: 0;
            flex: 0 0 5%
        }

        .hostinger-aft-banner-promo .hostinger-aft-banner-promo-slack-line1 {
            font-size: 18px;
            margin-top: 0;
            line-height: 21px
        }

        .hostinger-aft-banner-promo .hostinger-aft-banner-promo-slack-textlink {
            color: #e59544;
            text-decoration: none
        }

        .hostinger-aft-banner-promo .hostinger-aft-banner-promo-slack-textlink:hover {
            opacity: .8
        }

        .hostinger-aft-banner-promo-slack-line2 {
            display: block;
            font-size: 15px;
            margin: 15px 0 0;
            line-height: .75em
        }

        .hostinger-aft-banner-promo-slack-link {
            color: #888
        }

        a.hostinger-aft-btn-xs.hostinger-aft-banner-promo-slack-btn {
            margin: 0 5px
        }
    </style>
<?php });

add_action('admin_init', array('PAnD', 'init'));
function echo_promo($is_dismissible, $notice_version)
{
    $data_dismissible = ($is_dismissible) ? $notice_version : "";
    $class_dismissible = ($is_dismissible) ? "is-dismissible" : "";
?>
    <div data-dismissible="<?= $data_dismissible; ?>" class="hostinger-aft-banner-promo notice notice-info <?php echo $class_dismissible; ?>">
        <div class="hostinger-aft-banner-promo-logo"><img width="90" height="90" src="<?php echo get_template_directory_uri() . "/assets/images/logo.png"; ?>"></div>

        <div class="hostinger-aft-banner-promo-content">
            <h3 class="hostinger-aft-banner-title"><?php echo __('Welcome to Hostinger Themes', 'hostinger-affiliate-theme'); ?></h3>
            <div class="hostinger-aft-banner-description">
                <div class="hostinger-aft-banner-description-padding-right-15">
                    <p class="hostinger-aft-banner-desciption-content">
                        <?php echo __('Do you have any question?', 'hostinger-affiliate-theme'); ?>
                        <?php echo __('Don\'t hesitate to contact our support team.', 'hostinger-affiliate-theme'); ?>
                    </p>
                    <p class="hostinger-aft-banner-desciption-content">
                        <?php echo __("<b>Note: Have you just updated?</b> Don't forget to clear the cache of both the server and the browser to view the changes correctly.", 'hostinger-affiliate-theme'); ?>
                    </p>

                </div>
                <div>
                    <div class="hostinger-aft-banner-promo-slack-line2">
                        <?php _e('Click on the link below', 'hostinger-affiliate-theme'); ?>
                    </div>
                    <h3 class="hostinger-aft-banner-button-link">
	                    <?php echo __('Go to Support', 'hostinger-affiliate-theme'); ?>
                    </h3>
                </div>
            </div>
        </div>
    </div>
<?php
}

function author_admin_notice()
{
    $version = "four-notice";
    if (isset($_GET["page"]) && $_GET["page"] === "hostinger-aft-licenses") {
        echo_promo(false, "");
    } elseif (PAnD::is_admin_notice_active($version)) {
        echo_promo(true, $version);
    }
}

add_action('admin_notices', 'author_admin_notice');
