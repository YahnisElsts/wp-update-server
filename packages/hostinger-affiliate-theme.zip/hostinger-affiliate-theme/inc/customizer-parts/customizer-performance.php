<?php

function hostinger_aft_performance_customizer($wp_customize)
{
	
	global $hostinger_aft_customizer_defaults;

	$wp_customize->add_panel('hostinger_aft_performances', array(
		'title' =>  __('Performance Settings', 'hostinger-affiliate-theme'),
		'description' => __('Remember to test each function separately and check the website for errors.', 'hostinger-affiliate-theme'),
		'priority' => 1004,
	));

	$wp_customize->add_section('hostinger_aft_performance_preload_fonts', array(
		'title' =>  __('Preload Fonts', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));
	$wp_customize->add_setting('hostinger_aft_performance_preload_fonts', array(
		'name' => 'hostinger_aft_performance_preload_fonts',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_preload_fonts'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_preload_fonts', array(
		'setting' => 'hostinger_aft_performance_preload_fonts',
		'label' => __('“Preload” the location of your resources', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_preload_fonts',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __("One per line \nEx. https://example.com/font.woff2", 'hostinger-affiliate-theme'),
		)
	)));

	$wp_customize->add_section('hostinger_aft_performance_preload_styles', array(
		'title' =>  __('Preload Styles (CSS)', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));
	$wp_customize->add_setting('hostinger_aft_performance_preload_styles', array(
		'name' => 'hostinger_aft_performance_preload_styles',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_preload_styles'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_preload_styles', array(
		'setting' => 'hostinger_aft_performance_preload_styles',
		'label' => __('“Preload” the location of your resources', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_preload_styles',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __("One per line \nEx. https://example.com/style.css", 'hostinger-affiliate-theme'),
		)
	)));

	$wp_customize->add_section('hostinger_aft_performance_preload_scripts', array(
		'title' =>  __('Preload Scripts (JS)', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));
	$wp_customize->add_setting('hostinger_aft_performance_preload_scripts', array(
		'name' => 'hostinger_aft_performance_preload_scripts',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_preload_scripts'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_preload_scripts', array(
		'setting' => 'hostinger_aft_performance_preload_scripts',
		'label' => __('“Preload” the location of your resources', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_preload_scripts',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __("One per line \nEx. https://example.com/script.css", 'hostinger-affiliate-theme'),
		)
	)));

	$wp_customize->add_section('hostinger_aft_performance_preload_images', array(
		'title' =>  __('Preload Images', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));
	$wp_customize->add_setting('hostinger_aft_performance_preload_images', array(
		'name' => 'hostinger_aft_performance_preload_images',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_preload_images'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_preload_images', array(
		'setting' => 'hostinger_aft_performance_preload_images',
		'label' => __('“Preload” the location of your resources', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_preload_images',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __("One per line \nEx. https://example.com/image.jpg", 'hostinger-affiliate-theme'),
		)
	)));

	$wp_customize->add_section('hostinger_aft_performance_preload_embed', array(
		'title' =>  __('Preload Embed (iframes)', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));
	$wp_customize->add_setting('hostinger_aft_performance_preload_embed', array(
		'name' => 'hostinger_aft_performance_preload_embed',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_preload_embed'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_preload_embed', array(
		'setting' => 'hostinger_aft_performance_preload_embed',
		'label' => __('“Preload” the location of your resources', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_preload_embed',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __("One per line \nEx. https://example.com/videoembed/", 'hostinger-affiliate-theme'),
		)
	)));


	$wp_customize->add_section('hostinger_aft_performance_preconnect', array(
		'title' =>  __('Preconnect (URL)', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));
	$wp_customize->add_setting('hostinger_aft_performance_preconnect', array(
		'name' => 'hostinger_aft_performance_preconnect',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_preconnect'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_preconnect', array(
		'setting' => 'hostinger_aft_performance_preconnect',
		'label' => __('“Preconnect” the location of your resources', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_preconnect',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __("One url per line\nEx. https://example.com/font.woff2", 'hostinger-affiliate-theme'),
		),
		
	)));

	$wp_customize->add_section('hostinger_aft_performance_prefetch', array(
		'title' =>  __('Prefetch (Domain)', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));
	$wp_customize->add_setting('hostinger_aft_performance_prefetch', array(
		'name' => 'hostinger_aft_performance_prefetch',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_prefetch'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_prefetch', array(
		'setting' => 'hostinger_aft_performance_prefetch',
		'label' => __('“Prefetch” the location of your resources', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_prefetch',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __("One domain per line. Format //example.com \nEx. //fonts.googleapis.com", 'hostinger-affiliate-theme'),
		),
	)));

	$wp_customize->add_section('hostinger_aft_performance_rendering', array(
		'title' =>  __('Fix Render Blocking', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));

	$wp_customize->add_setting('hostinger_aft_performance_render_blocking_css', array(
		'name' => 'hostinger_aft_performance_render_blocking_css',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_render_blocking_css'],
		'transport' => 'refresh',
		'sanitize_callback' => '',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_render_blocking_css', array(
		'setting' => 'hostinger_aft_performance_render_blocking_css',
		'label' => __('Fix Render Blocking CSS', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_rendering',
		'type' => 'checkbox',
	)));

	$wp_customize->add_setting('hostinger_aft_performance_render_blocking_js', array(
		'name' => 'hostinger_aft_performance_render_blocking_js',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_render_blocking_js'],
		'transport' => 'refresh',
		'sanitize_callback' => '',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_render_blocking_js', array(
		'setting' => 'hostinger_aft_performance_render_blocking_js',
		'label' => __('Fix Render Blocking JS', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_rendering',
		'type' => 'checkbox',
	)));

	$wp_customize->add_setting('hostinger_aft_performance_render_blocking_jquery', array(
		'name' => 'hostinger_aft_performance_render_blocking_jquery',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_render_blocking_jquery'],
		'transport' => 'refresh',
		'sanitize_callback' => '',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_render_blocking_jquery', array(
		'setting' => 'hostinger_aft_performance_render_blocking_jquery',
		'label' => __('Exclude jQuery on Fix Render Blocking', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_rendering',
		'type' => 'checkbox',
	)));	

	$wp_customize->add_setting('hostinger_aft_performance_lazy_load', array(
		'name' => 'hostinger_aft_performance_lazy_load',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_performance_lazy_load'],
		'transport' => 'refresh',
		'sanitize_callback' => '',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_performance_lazy_load', array(
		'setting' => 'hostinger_aft_performance_lazy_load',
		'label' => __('Lazy Load (Experimental)', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_rendering',
		'description' => __('It is necessary to regenerate all miniatures', 'hostinger-affiliate-theme'),
		'type' => 'checkbox',
	)));

	$wp_customize->add_section('hostinger_aft_performance_quicklink', array(
		'title' =>  __('Quick Link', 'hostinger-affiliate-theme'),
		'panel' => 'hostinger_aft_performances',
	));

	$wp_customize->add_setting('hostinger_aft_quicklink_active', array(
		'name' => 'hostinger_aft_quicklink_active',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_quicklink_active'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_checkbox',
	));
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_quicklink_active', array(
		'setting' => 'hostinger_aft_quicklink_active',
		'label' => __('Enable Quicklink', 'hostinger-affiliate-theme'),
		//'description' => __('', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_quicklink',
		'type' => 'checkbox',
	)));

	$wp_customize->add_setting('hostinger_aft_quicklink_default_urls', array(
		'name' => 'hostinger_aft_quicklink_default_urls',
		'default' => $hostinger_aft_customizer_defaults['hostinger_aft_quicklink_default_urls'],
		'transport' => 'refresh',
		'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'hostinger_aft_quicklink_default_urls', array(
		'setting' => 'hostinger_aft_quicklink_default_urls',
		'label' => __('Default Prefetch URLs', 'hostinger-affiliate-theme'),
		'section' => 'hostinger_aft_performance_quicklink',
		'type' => 'textarea',
		'input_attrs' => array(
			'placeholder' => __('One per line', 'hostinger-affiliate-theme'),
		),
	)));
	
}
