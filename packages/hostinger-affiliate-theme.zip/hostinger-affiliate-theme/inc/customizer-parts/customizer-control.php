<?php

$hostinger_aft_customizer_defaults = array(
    'hostinger_aft_link_color' => '#2196f3',
    'hostinger_aft_navbar_background' => '#ffffff',
    'hostinger_aft_navbar_link_color' => '#000000',
    'hostinger_aft_layout_container' => 52,
    'hostinger_aft_layout_relation' => 30,
    'hostinger_aft_layout_sidebar_order' => 0,
    'hostinger_aft_layout_sidebar_sticky' => false,
    'hostinger_aft_layout_menu_aft' => false,
    'hostinger_aft_layout_search_navbar' => false,
    'hostinger_aft_seo_analytics' => '',
    'hostinger_aft_seo_adsense' => '',
    'hostinger_aft_typo_logo' => false,
    'hostinger_aft_typo_headings' => false,
    'hostinger_aft_typo_body' => false,
    'hostinger_aft_loop_columns' => 'column-third',
    'hostinger_aft_loop_thumbnail' => true,
    'hostinger_aft_loop_excerpt' => true,
    'hostinger_aft_loop_excerpt_lenght' => 12,
    'hostinger_aft_loop_read_more' => esc_html__('Read more', 'hostinger-affiliate-theme'),
    'hostinger_aft_loop_date' => true,
    'hostinger_aft_loop_category' => true,
    'hostinger_aft_loop_author' => false,
    'hostinger_aft_loop_cluster_img_width' => 390,
    'hostinger_aft_loop_cluster_img_height' => 200,
    'hostinger_aft_advertisment_device' => 'all',
    'hostinger_aft_cluster_columns' => 'column-third',
    'hostinger_aft_posts_default_thumbnail' => true,
    'hostinger_aft_posts_default_related' => true,
    'hostinger_aft_posts_show_category' => true,
    'hostinger_aft_performance_preload_fonts' => '',
    'hostinger_aft_performance_preload_styles' => '',
    'hostinger_aft_performance_preload_scripts' => '',
    'hostinger_aft_performance_preload_images' => '',
    'hostinger_aft_performance_preload_embed' => '',
    'hostinger_aft_performance_preconnect' => '',
    'hostinger_aft_performance_prefetch' => '',
    'hostinger_aft_performance_render_blocking_css' => false,
    'hostinger_aft_performance_render_blocking_js' => false,
    'hostinger_aft_performance_render_blocking_jquery' => false,
    'hostinger_aft_performance_lazy_load' => false,
    'hostinger_aft_quicklink_active' => false,
    'hostinger_aft_quicklink_default_urls' => '',
    'hostinger_aft_gdpr_general_popup_btn' => __('Save settings', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_general_popup_title' => __('Cookie settings', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_general_link' => '#',
    'hostinger_aft_gdpr_general_text_link' => __('Read Our Cookie Policy', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_general_btn_settings' => __('Settings', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_general_btn_accept' => __('Accept', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_general_message' => __('We use cookies and other tracking techniques to improve your browsing experience on our website, to show you customized content and appropriate advertisements, to analyze traffic on our website and to understand where our visitors are coming from.', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_general_active' => false,
    'hostinger_aft_gdpr_general_mandatory' => true,
    'hostinger_aft_gdpr_functional_code' => '',
    'hostinger_aft_gdpr_functional_desc' => __('These cookies are used to provide you with a more personalized experience and to remember your choices on our website, for example, we may use functionality cookies to remember your language preferences or your login details.', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_functional_text' => __('Functionality Cookies', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_functional_active' => true,
    'hostinger_aft_gdpr_performance_code' => '',
    'hostinger_aft_gdpr_performance_desc' => __('These cookies are used to collect information to analyze traffic and how users use our website. For example, these cookies may collect data such as how long you have been browsing our website or which pages you visit, which helps us to understand how we can improve our website for you. The information collected with these tracking and performance cookies does not identify any individual visitor.', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_performance_text' => __('Traceability and performance cookies', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_performance_active' => true,
    'hostinger_aft_gdpr_analytics_ads_code' => '',
    'hostinger_aft_gdpr_analytics_ads_desc' => __('These cookies are used to show you advertisements that may be of interest based on your browsing habits. These cookies, served by our content and/or advertising providers, may combine the information they collected from our website with other information collected by them in connection with your browser activities across their network of websites. If you choose to opt-out or disable tracking and advertising cookies, you will still see advertisements but these may not be of interest to you.', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_analytics_ads_text' => __('Tracking and advertising cookies', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_analytics_ads_active' => true,
    'hostinger_aft_gdpr_other_code' => '',
    'hostinger_aft_gdpr_other_desc' => __('Other cookies not covered in the previous points.', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_other_text' => __('Other cookies', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_other_active' => true,
    'hostinger_aft_gdpr_strictly_necessary_code' => '',
    'hostinger_aft_gdpr_strictly_necessary_desc' => __('These cookies are essential to provide you with the services available on our website and to enable you to use some features of our website. Without these cookies, we cannot provide some services on our website.', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_strictly_necessary_text' => __('Strictly necessary cookies', 'hostinger-affiliate-theme'),
    'hostinger_aft_gdpr_strictly_necessary_active' => true,
    'hostinger_aft_gdpr_general_position' => 'middle',
    'hostinger_aft_gdpr_general_change_position' => 'right',
    'hostinger_aft_accessibility_links' => false,
    'hostinger_aft_accessibility_menu' => false
);

function hostinger_aft_customizer_sections() {

    $sections = array(
        //Sections
        array(
            'name' => 'hostinger_aft_layout',
            'title' => __('Layout Settings', 'hostinger-affiliate-theme'),
            'description' => __('', 'hostinger-affiliate-theme'),
            'priority' => 1001,
        ),
        array(
            'name' => 'hostinger_aft_posts',
            'title' => __('Posts Settings', 'hostinger-affiliate-theme'),
            'description' => __('', 'hostinger-affiliate-theme'),
            'priority' => 1001,
        ),
        array(
            'name' => 'hostinger_aft_typo',
            'title' => __('Typography Settings', 'hostinger-affiliate-theme'),
            'description' => __('', 'hostinger-affiliate-theme'),
            'priority' => 1001,
        ),
        array(
            'name' => 'hostinger_aft_loop',
            'title' => __('Loops Settings', 'hostinger-affiliate-theme'),
            'description' => __('', 'hostinger-affiliate-theme'),
            'priority' => 1002,
        ),
        array(
            'name' => 'hostinger_aft_seo',
            'title' => __('SEO Settings', 'hostinger-affiliate-theme'),
            'description' => __('', 'hostinger-affiliate-theme'),
            'priority' => 1003,
        ),
        array(
            'name' => 'hostinger_aft_accessibility',
            'title' => __('Accessibility Options', 'hostinger-affiliate-theme'),
            'description' => __('', 'hostinger-affiliate-theme'),
            'priority' => 1003,
        )
    );

    return $sections;
}

function hostinger_aft_customizer_settings() {
    global $hostinger_aft_customizer_defaults;
    $settings = array(
        //
        //  COLORS
        //

        array(
            'name' => 'hostinger_aft_link_color',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_link_color'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_hex_color',
        ),
        array(
            'name' => 'hostinger_aft_navbar_background',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_navbar_background'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_hex_color',
        ),
        array(
            'name' => 'hostinger_aft_navbar_link_color',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_navbar_link_color'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_hex_color',
        ),
        //
        //  LAYOUT SETTINGS
        //
        array(
            'name' => 'hostinger_aft_layout_container',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_layout_container'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_number_absint',
        ),
        array(
            'name' => 'hostinger_aft_layout_relation',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_layout_relation'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_number_absint',
        ),
        array(
            'name' => 'hostinger_aft_layout_sidebar_order',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_layout_sidebar_order'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_number_absint',
        ),
        array(
            'name' => 'hostinger_aft_layout_sidebar_sticky',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_layout_sidebar_sticky'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        ),
        array(
            'name' => 'hostinger_aft_layout_search_navbar',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_layout_search_navbar'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        ),
        array(
            'name' => 'hostinger_aft_layout_menu_aft',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_layout_menu_aft'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        ),
        //
        // POSTS SETTINGS
        //
        array(
            'name' => 'hostinger_aft_posts_default_thumbnail',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_posts_default_thumbnail'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        ),
        array(
            'name' => 'hostinger_aft_posts_default_related',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_posts_default_related'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        ),
        array(
            'name' => 'hostinger_aft_posts_show_category',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_posts_show_category'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        ),
       
        //
        // SEO SETTINGS
        //
        array(
            'name' => 'hostinger_aft_seo_analytics',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_seo_analytics'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_scripts',
        ),
        array(
            'name' => 'hostinger_aft_seo_adsense',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_seo_adsense'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_scripts',
        ),
        //
        //TYPO SETTINGS
        //
        array(
            'name' => 'hostinger_aft_typo_logo',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_typo_logo'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
        ),
        array(
            'name' => 'hostinger_aft_typo_headings',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_typo_headings'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
        ),
        array(
            'name' => 'hostinger_aft_typo_body',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_typo_body'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_nohtml',
        ),
        //
        // LOOP SETTINGS
        //
        array(
            'name' => 'hostinger_aft_loop_thumbnail',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_thumbnail'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_checkbox',
        ),
        array(
            'name' => 'hostinger_aft_loop_excerpt',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_excerpt'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_checkbox',
        ),
        array(
            'name' => 'hostinger_aft_loop_excerpt_lenght',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_excerpt_lenght'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_number_absint',
        ),
        array(
            'name' => 'hostinger_aft_loop_read_more',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_read_more'],
            'transport' => 'postMessage',
            'sanitize_callback' => 'hostinger_aft_sanitize_checkbox',
        ),
        array(
            'name' => 'hostinger_aft_loop_date',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_date'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_checkbox',
        ),
        array(
            'name' => 'hostinger_aft_loop_category',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_category'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_checkbox',
        ),
        array(
            'name' => 'hostinger_aft_loop_author',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_author'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_checkbox',
        ),
        array(
            'name' => 'hostinger_aft_loop_cluster_img_width',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_cluster_img_width'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_number_absint',
        ),
        array(
            'name' => 'hostinger_aft_loop_cluster_img_height',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_loop_cluster_img_height'],
            'transport' => 'refresh',
            'sanitize_callback' => 'hostinger_aft_sanitize_number_absint',
        ),
        array(
            'name' => 'hostinger_aft_accessibility_links',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_accessibility_links'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        ),
        array(
            'name' => 'hostinger_aft_accessibility_menu',
            'default' => $hostinger_aft_customizer_defaults['hostinger_aft_accessibility_menu'],
            'transport' => 'refresh',
            'sanitize_callback' => '',
        )
    );


    return $settings;
}

function hostinger_aft_customizer_controls($fonts) {
    $controls = array(
        //
        //  COLOR CONTROLS
        //

        array(
            'setting' => 'hostinger_aft_link_color',
            'info' => array(
                'label' => __('Link Color', 'hostinger-affiliate-theme'),
                'section' => 'colors',
                'settings' => 'hostinger_aft_link_color',
                'type' => 'color',
            )
        ),
        array(
            'setting' => 'hostinger_aft_navbar_background',
            'info' => array(
                'label' => __('Navbar Background Color', 'hostinger-affiliate-theme'),
                'section' => 'colors',
                'settings' => 'hostinger_aft_navbar_background',
                'type' => 'color',
            )
        ),
        array(
            'setting' => 'hostinger_aft_navbar_link_color',
            'info' => array(
                'label' => __('Navbar Link Color', 'hostinger-affiliate-theme'),
                'section' => 'colors',
                'settings' => 'hostinger_aft_navbar_link_color',
                'type' => 'color',
            )
        ),
        //
        //  LAYOUT CONTROLS
        //
        array(
            'setting' => 'hostinger_aft_layout_container',
            'info' => array(
                'label' => __('Container Width', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_layout',
                'settings' => 'hostinger_aft_layout_container',
                'type' => 'range',
                'input_attrs' => array(
                    'min' => 36,
                    'max' => 96,
                    'step' => 0.5,
                ),
            )
        ),
        array(
            'setting' => 'hostinger_aft_layout_relation',
            'info' => array(
                'label' => __('Content-Sidebar Relation', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_layout',
                'settings' => 'hostinger_aft_layout_relation',
                'type' => 'range',
                'input_attrs' => array(
                    'min' => 25,
                    'max' => 50,
                    'step' => 0.5,
                ),
            )
        ),
        array(
            'setting' => 'hostinger_aft_layout_sidebar_order',
            'info' => array(
                'type' => 'select',
                'section' => 'hostinger_aft_layout',
                'label' => __('Sidebar Order', 'hostinger-affiliate-theme'),
                'settings' => 'hostinger_aft_layout_sidebar_order',
                'choices' => array(
                    -1 => 'Left',
                    0 => 'Right',
                ),
            )),
        array(
            'setting' => 'hostinger_aft_layout_sidebar_sticky',
            'info' => array(
                'label' => __('Sticky Sidebar', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_layout',
                'settings' => 'hostinger_aft_layout_sidebar_sticky',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_layout_search_navbar',
            'info' => array(
                'label' => __('Navbar Search', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_layout',
                'settings' => 'hostinger_aft_layout_search_navbar',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_layout_menu_aft',
            'info' => array(
                'label' => __('Hostinger Affiliate Menu', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_layout',
                'settings' => 'hostinger_aft_layout_menu_aft',
                'type' => 'checkbox',
            )
        ),
        
        //
        //  POSTS CONTROLS
        //
        array(
            'setting' => 'hostinger_aft_posts_default_thumbnail',
            'info' => array(
                'label' => __('Show Thumbnails', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_posts',
                'settings' => 'hostinger_aft_posts_default_thumbnail',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_posts_default_related',
            'info' => array(
                'label' => __('Show Related Posts', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_posts',
                'settings' => 'hostinger_aft_posts_default_related',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_posts_show_category',
            'info' => array(
                'label' => __('Show Category Link', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_posts',
                'settings' => 'hostinger_aft_posts_show_category',
                'type' => 'checkbox',
            )
        ),
       
        //
        //  SEO CONTROLS
        //
        array(
            'setting' => 'hostinger_aft_seo_analytics',
            'info' => array(
                'label' => __('Analytics Code', 'hostinger-affiliate-theme'),
                'section' => 'position_options_analytics',
                'settings' => 'hostinger_aft_seo_analytics',
                'type' => 'textarea',
                'input_attrs' => array(
                    'placeholder' => __('Insert Analytics Code with script tag', 'hostinger-affiliate-theme'),
                ),
            )
        ),
        array(
            'setting' => 'hostinger_aft_seo_adsense',
            'info' => array(
                'label' => __('Adsense Code', 'hostinger-affiliate-theme'),
                'section' => 'position_options_analytics',
                'settings' => 'hostinger_aft_seo_adsense',
                'type' => 'textarea',
                'input_attrs' => array(
                    'placeholder' => __('Insert the Adsense code with the script tag', 'hostinger-affiliate-theme'),
                ),
            )
        ),
        //
        // LOOPS CONTROLS
        //
        array(
            'setting' => 'hostinger_aft_loop_thumbnail',
            'info' => array(
                'label' => __('Show Thumbnails', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_thumbnail',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_excerpt',
            'info' => array(
                'label' => __('Show Excerpt', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_excerpt',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_date',
            'info' => array(
                'label' => __('Show Date', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_date',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_category',
            'info' => array(
                'label' => __('Show Category', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_category',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_author',
            'info' => array(
                'label' => __('Show Author', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_author',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_excerpt_lenght',
            'info' => array(
                'label' => __('Excerpt Length', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_excerpt_lenght',
                'type' => 'number',
                'input_attrs' => array(
                    'min' => 5,
                ),
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_columns',
            'info' => array(
                'type' => 'select',
                'section' => 'hostinger_aft_loop',
                'label' => __('Number of columns', 'hostinger-affiliate-theme'),
                'settings' => 'hostinger_aft_loop_columns',
                'choices' => array(
                    'column' => 'List Mode',
                    'column-half' => '2 columns',
                    'column-third' => '3 columns',
                    'column-quarter' => '4 columns',
                ),
            )),
        array(
            'setting' => 'hostinger_aft_loop_read_more',
            'info' => array(
                'label' => __('Read More Text', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_read_more',
                'type' => 'text',
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_cluster_img_width',
            'info' => array(
                'label' => __('Cluster Image Width', 'hostinger-affiliate-theme'),
                'description' => __('It is necessary to regenerate all miniatures', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_cluster_img_width',
                'type' => 'number',
                'input_attrs' => array(
                    'min' => 1,
                ),
            )
        ),
        array(
            'setting' => 'hostinger_aft_loop_cluster_img_height',
            'info' => array(
                'label' => __('Cluster Image Height', 'hostinger-affiliate-theme'),
                'description' => __('It is necessary to regenerate all miniatures', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_loop',
                'settings' => 'hostinger_aft_loop_cluster_img_height',
                'type' => 'number',
                'input_attrs' => array(
                    'min' => 1,
                ),
            )
        ),
        //
        // TYPO CONTROLS
        //
        array('setting' => 'hostinger_aft_typo_logo',
            'info' => array(
                'label' => __('Typo Logo', 'hostinger-affiliate-theme'),
                'description' => __('You can enter a URL. For example from Google Fonts.', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_typo',
                'settings' => 'hostinger_aft_typo_logo',
                'type' => 'select',
                'choices' => $fonts,
            )
        ),
        array('setting' => 'hostinger_aft_typo_headings',
            'info' => array(
                'label' => __('Typo Headings', 'hostinger-affiliate-theme'),
                'description' => __('You can enter a URL. For example from Google Fonts.', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_typo',
                'settings' => 'hostinger_aft_typo_headings',
                'type' => 'select',
                'choices' => $fonts,
            )
        ),
        array('setting' => 'hostinger_aft_typo_body',
            'info' => array(
                'label' => __('Typo Body', 'hostinger-affiliate-theme'),
                'description' => __('You can enter a URL. For example from Google Fonts.', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_typo',
                'settings' => 'hostinger_aft_typo_body',
                'type' => 'select',
                'choices' => $fonts,
            )
        ),
        array(
            'setting' => 'hostinger_aft_accessibility_links',
            'info' => array(
                'label' => __('Disable underline on links', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_accessibility',
                'settings' => 'hostinger_aft_accessibility_links',
                'type' => 'checkbox',
            )
        ),
        array(
            'setting' => 'hostinger_aft_accessibility_menu',
            'info' => array(
                'label' => __('Disable menu navigation by keyboard', 'hostinger-affiliate-theme'),
                'section' => 'hostinger_aft_accessibility',
                'settings' => 'hostinger_aft_accessibility_menu',
                'type' => 'checkbox',
            )
        )
    );
    return $controls;
}
