<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Hostinger AFT
 * @since 1.0
 */

/*
 * Print Pagination
 */

if (! function_exists('hostinger_aft_pagination')) :

	function hostinger_aft_pagination()
	{

		if (paginate_links()) {
			echo '<div class="pagination">'. paginate_links() .'</div>';
		}
	}

endif;


/*
 * Print Subtitle to Singular Elements
 */

if (! function_exists('hostinger_aft_subtitle')) :

	function hostinger_aft_subtitle()
	{

		if (! hostinger_aft_get_option_page('subtitle', false)) {
			return;
		}

		echo '<p class="subtitle">'. hostinger_aft_get_option_page('subtitle') . '</p>';
	}

endif;


/*
 * Return name of Primary Category of Post
 */

if (! function_exists('hostinger_aft_the_category')) :

	function hostinger_aft_the_category()
	{

		$categories = get_the_category();

		if (isset($categories[0])) {
			$category_name = $categories[0]->name;
			if (class_exists('WPSEO_Primary_Term')) {
				$wpseo_primary_term = new WPSEO_Primary_Term('category', get_the_id());
				if ($wpseo_primary_term->get_primary_term()) {
					$category_name = get_the_category_by_ID($wpseo_primary_term->get_primary_term());
				}
			}

			return $category_name;
		}
	}

endif;

/*
 * Tags
 */

if (! function_exists('hostinger_aft_the_tags')) :

	function hostinger_aft_the_tags()
	{
		the_tags();
	}

endif;


/*
 * Return id of Primary Category of Post
 */

if (! function_exists('hostinger_aft_the_category_id')) :

	function hostinger_aft_the_category_id()
	{

		$categories = get_the_category();
		$category_id = $categories[0]->term_id;

		if (class_exists('WPSEO_Primary_Term')) {
			$wpseo_primary_term = new WPSEO_Primary_Term('category', get_the_id());
			if ($wpseo_primary_term->get_primary_term()) {
				$category_id = $wpseo_primary_term->get_primary_term();
			}
		}

		return $category_id;
	}

endif;


/*
 * Return link of Primary Category of Post
 */

if (! function_exists('hostinger_aft_the_category_link')) :

	function hostinger_aft_the_category_link()
	{

		$category_name = hostinger_aft_the_category();
		$category_link = get_category_link(get_cat_ID($category_name));
		return '<a href="' . esc_url($category_link) .'">'. $category_name .'</a>';
	}

endif;


/*
 * Print related posts
 */

if (! function_exists('hostinger_aft_related_posts')) :

	function hostinger_aft_related_posts()
	{
		if (! hostinger_aft_get_option_page('related') || !hostinger_aft_customize_option('hostinger_aft_posts_default_related')) {
			return;
		}
		get_template_part('template-parts/single/content', 'related');
	}

endif;


/*
 * Print meta info
 */

if (! function_exists('hostinger_aft_posted_on')) :

	function hostinger_aft_posted_on()
	{

		$byline = sprintf(__('by %s', 'hostinger-affiliate-theme'), '<span class="author">' . get_the_author() . '</span>');

		if (hostinger_aft_customize_option('hostinger_aft_loop_author')) {
			echo '<span class="byline"> ' . $byline . '</span>' ;
		}

		if (hostinger_aft_customize_option('hostinger_aft_loop_date')) {
			echo ' <span class="posted-on">' . get_the_date() . '</span>';
		}
	}

endif;


/*
 * Print Thumbnail Featured Image from a Singular element
 */

if (! function_exists('hostinger_aft_thumbnail_post')) :

	function hostinger_aft_thumbnail_post()
	{

		if (has_post_thumbnail() && hostinger_aft_get_option_page('thumbnail') && hostinger_aft_customize_option('hostinger_aft_posts_default_thumbnail')) { ?>
			<div class="post-thumbnail"><?php the_post_thumbnail('large'); ?></div>

			<?php
		}
	}

endif;


/*
 * Return Logo from customize
 */

if (! function_exists('hostinger_aft_customize_logo_html')) :

	function hostinger_aft_customize_logo_html()
	{

		$hostinger_aft_custom_logo = get_theme_mod('custom_logo');
		$html = sprintf(
			'<a href="%1$s" class="custom-logo-link">%2$s</a>',
			esc_url(home_url('/')),
			wp_get_attachment_image($hostinger_aft_custom_logo, 'full', false, array(
				'class'    => 'custom-logo',
			))
		);
		return $html;
	}

endif;


/*
 * Print Custom Logo
 */

if (! function_exists('hostinger_aft_the_custom_logo')) :

	function hostinger_aft_the_custom_logo()
	{
		if (function_exists('the_custom_logo')) {
			the_custom_logo();
		}
	}

endif;


/*
 * Print Background Style for Jumbotron Header
 */

if (! function_exists('hostinger_aft_the_custom_jumbotron')) :

	function hostinger_aft_the_custom_jumbotron()
	{
		if (is_home()) {
			echo '<style>.jumbotron {background-image: url(' . get_header_image() .'); }</style>';
		} elseif (is_front_page()) {
			echo '<style>.jumbotron {background-image: url(' . get_the_post_thumbnail_url(get_option('page_for_posts'), 'full') .');}</style>';
		} elseif (is_page() || is_single()) {
			if (has_post_thumbnail()) {
				echo '<style>
				.jumbotron, .group-image {
					background-image: url(' . get_the_post_thumbnail_url(get_the_ID(), 'full') .');
				}
				</style>';
			}
		}
	}

endif;


/*
 * Print Top Category description
 */

if (! function_exists('hostinger_aft_category_top_description')) :

	function hostinger_aft_category_top_description()
	{
		if(get_queried_object()){
			echo wpautop(get_term_meta(get_queried_object()->term_id, 'cat_extra_description', true));
		}
	}

endif;
