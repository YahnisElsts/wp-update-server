<?php

/**
 * Advertisment Functionality
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Hostinger AFT
 * @since 1.0
 */
/*
 * Advertisment Hook Before Home
 */

function hostinger_aft_advertisment_before_home() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_home', 'desktop');
}

function hostinger_aft_advertisment_before_home_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_home_mobile', 'mobile');
}

/*
 * Advertisment Hook After Featured Home
 */

function hostinger_aft_advertisment_after_featured_home() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_featured_home', 'desktop');
}

function hostinger_aft_advertisment_after_featured_home_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_featured_home_mobile', 'mobile');
}

/*
 * Advertisment Hook After Home
 */

function hostinger_aft_advertisment_after_home() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_home', 'desktop');
}

function hostinger_aft_advertisment_after_home_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_home_mobile', 'mobile');
}

/*
 * Advertisment Hook Before Single Content
 */

function hostinger_aft_advertisment_before_single_content() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_single_content', 'desktop');
}

function hostinger_aft_advertisment_before_single_content_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_single_content_mobile', 'mobile');
}

/*
 * Advertisment Hook Middle Single Content
 */

function hostinger_aft_advertisment_middle_single_content($content) {
    return hostinger_aft_print_advertisment_middle_page('hostinger_aft_advertisment_middle_single_content', $content, 'desktop', 'post');
}

function hostinger_aft_advertisment_middle_single_content_mobile($content) {
    return hostinger_aft_print_advertisment_middle_page('hostinger_aft_advertisment_middle_single_content_mobile', $content, 'mobile', 'post');
}

/*
 * Advertisment Hook After Single Content
 */

function hostinger_aft_advertisment_after_single_content() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_single_content', 'desktop');
}

function hostinger_aft_advertisment_after_single_content_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_single_content_mobile', 'mobile');
}

/*
 * Advertisment Hook Before Page Content
 */

function hostinger_aft_advertisment_before_page_content() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_page_content', 'desktop');
}

function hostinger_aft_advertisment_before_page_content_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_page_content_mobile', 'mobile');
}

/*
 * Advertisment Hook Middle Page Content
 */

function hostinger_aft_advertisment_middle_page_content($content) {
    return hostinger_aft_print_advertisment_middle_page('hostinger_aft_advertisment_middle_page_content', $content, 'desktop', 'page');
}

function hostinger_aft_advertisment_middle_page_content_mobile($content) {
    return hostinger_aft_print_advertisment_middle_page('hostinger_aft_advertisment_middle_page_content_mobile', $content, 'mobile', 'page');
}

/*
 * Advertisment Hook After Page Content
 */

function hostinger_aft_advertisment_after_page_content() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_page_content', 'desktop');
}

function hostinger_aft_advertisment_after_page_content_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_page_content_mobile', 'mobile');
}

/*
 * Advertisment Hook Before Archive
 */

function hostinger_aft_advertisment_before_archive() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_archive', 'desktop');
}

function hostinger_aft_advertisment_before_archive_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_before_archive_mobile', 'mobile');
}

/*
 * Advertisment Hook After Featured Archive
 */

function hostinger_aft_advertisment_after_featured_archive() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_featured_archive', 'desktop');
}

function hostinger_aft_advertisment_after_featured_archive_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_featured_archive_mobile', 'mobile');
}

/*
 * Advertisment Hook After Archive
 */

function hostinger_aft_advertisment_after_archive() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_archive', 'desktop');
}

function hostinger_aft_advertisment_after_archive_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_archive_mobile', 'mobile');
}

/*
 * Advertisment Hook After Description Archive
 */

function hostinger_aft_advertisment_after_description_archive() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_description_archive', 'desktop');
}

function hostinger_aft_advertisment_after_description_archive_mobile() {
    hostinger_aft_print_advertisment('hostinger_aft_advertisment_after_description_archive_mobile', 'mobile');
}

function hostinger_aft_middle_insert_advertisment($insertion, $part_id, $content, $code = 'p', $mode = 'unique') {
    $closing = '</' . $code . '>';
    $parts = explode($closing, $content);
    if ($mode == 'scroll') {
        foreach ($parts as $index => $part) {
            if ($part !== end($parts)) {
                if (trim($part)) {
                    $parts[$index] .= $closing;
                }

                if ($part_id) {
                    if (($index + 1) % $part_id == 0) {
                        $parts[$index] .= $insertion;
                    }
                }
            }
        }
    } else {
        foreach ($parts as $index => $part) {
            if (trim($part)) {
                $parts[$index] .= $closing;
            }

            if ($part_id == $index + 1) {
                $parts[$index] .= $insertion;
            }
        }
    }


    return implode('', $parts);
}

/*
 * Check if template can print advertisment
 */

if (!function_exists('hostinger_aft_check_advertisment_template')) :

    function hostinger_aft_check_advertisment_template($slug, $location = null) {
        $locationoption = hostinger_aft_customize_option($location);

        if (isset($location) && empty($locationoption)) {
            return true;
        }

        switch ($slug) {
            case 'no-ads':
                if (is_home() || is_front_page()) {
                    return false;
                }

                if ((is_page_template('templates/single-noads.php') || is_page_template('templates/page-noads.php')) || !hostinger_aft_get_option_page('advertisment')) {
                    return true;
                }


                break;

            default:
                return false;
                break;
        }
        return false;
    }

endif;

function hostinger_aft_print_advertisment($location, $device = 'desktop') {
    
    if (!hostinger_aft_gdpr_show_cookies('analytics_ads') || !hostinger_aft_get_option_page('advertisment')) {
        return;
    }
    ?>
    <div class="banner <?php echo $device ?>">
        <div class="<?php echo hostinger_aft_customize_option($location . '_align', 'center') ?> <?php echo hostinger_aft_customize_option($location . '_style', 'fluid') ?>">
            <?php echo hostinger_aft_customize_option($location . '_code') ?>
        </div>
    </div>
    <?php
}

function hostinger_aft_print_advertisment_middle_page($location, $content, $device = 'desktop', $post_type = 'post') {


    if (!hostinger_aft_gdpr_show_cookies('analytics_ads') || !hostinger_aft_get_option_page('advertisment') || is_admin()) {
        return $content;
    }

    $ad_code = '<div class="banner ' . $device . '"><div class="' . hostinger_aft_customize_option($location . '_align') . ' ' . hostinger_aft_customize_option($location . '_style') . '">
	' . hostinger_aft_customize_option($location . '_code') . '
	</div>
	</div>';


    if (is_singular($post_type)) {
        return hostinger_aft_middle_insert_advertisment(
                $ad_code,
                hostinger_aft_customize_option($location . '_middle_number', 3),
                $content,
                hostinger_aft_customize_option($location . '_middle_tag', 'p'),
                hostinger_aft_customize_option($location . '_middle_mode', 'unique')
        );
    }

    return $content;
}
