<?php

/**
 * Hostinger AFT functions and definitions
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Hostinger AFT
 * @since 1.0
 */
/*
 * Compability System
 */

if (version_compare($GLOBALS['wp_version'], '4.7', '<')) {
    require_once get_template_directory() . '/inc/back-compat.php';
    return;
}


/*
 * Theme Setup
 */

if (!function_exists('hostinger_aft_setup')) :

    function hostinger_aft_setup() {

        load_theme_textdomain('hostinger-affiliate-theme', get_template_directory() . '/languages');
        add_theme_support('automatic-feed-links');
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('align-wide');
        add_theme_support('customize-selective-refresh-widgets');
        register_nav_menus(array('primary' => esc_html__('Primary Menu', 'hostinger-affiliate-theme')));

        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ));

        add_theme_support('custom-logo', array(
            'height' => 90,
            'width' => 450,
            'flex-height' => true,
            'flex-width' => true,
        ));

        add_theme_support('post-formats', array(
            'aside',
            'image',
            'video',
            'quote',
            'link',
            'gallery',
            'audio',
        ));

        $defaults = array(
            'default-image' => '',
            'width' => 1920,
            'height' => 400,
            'flex-height' => true,
            'flex-width' => true,
            'uploads' => true,
            'random-default' => false,
            'header-text' => true,
        );

        add_theme_support('custom-header', $defaults);
        add_theme_support('custom-background');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');


        add_image_size(
                'thumbnail-center',
                hostinger_aft_customize_option('hostinger_aft_loop_cluster_img_width', 390),
                hostinger_aft_customize_option('hostinger_aft_loop_cluster_img_height', 200),
                array('top', 'center')
        );

        add_image_size('thumbnail-featured', 333, 360, array('center', 'center'));

        add_theme_support('starter-content', array(
            'widgets' => array(
                'posts' => array(
                    'recent-posts-hostinger-aft' => array('recent-posts-hostinger-aft', array(
                            'title' => esc_html__('Lasts Posts', 'hostinger-affiliate-theme'),
                            'thumbnail' => true,
                        )),
                ),
            ),
        ));
    }

endif;
add_action('after_setup_theme', 'hostinger_aft_setup');


/*
 * Content Width Definition
 */

if (!function_exists('hostinger_aft_content_width')) :

    function hostinger_aft_content_width() {

        if (hostinger_aft_customize_option('hostinger_aft_layout_container')) {
            $container = hostinger_aft_customize_option('hostinger_aft_layout_container') * 16;
        } else {
            $container = 768;
        }

        $GLOBALS['content_width'] = apply_filters('hostinger_aft_content_width', $container);
    }

endif;
add_action('after_setup_theme', 'hostinger_aft_content_width', 0);


/*
 * Widget Area Register
 */

if (!function_exists('hostinger_aft_widgets_init')) :

    function hostinger_aft_widgets_init() {
        register_sidebar(array(
            'name' => esc_html__('Posts Sidebar', 'hostinger-affiliate-theme'),
            'id' => 'posts',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Pages Sidebar', 'hostinger-affiliate-theme'),
            'id' => 'pages',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));

        register_sidebar(array(
            'name' => esc_html__('Pilar Pages Sidebar', 'hostinger-affiliate-theme'),
            'id' => 'pilar',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));

        register_sidebar(array(
            'name' => esc_html__('Page Home Sidebar', 'hostinger-affiliate-theme'),
            'id' => 'page-home',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
        register_sidebar(array(
            'name' => esc_html__('No advertisment Sidebar', 'hostinger-affiliate-theme'),
            'id' => 'no-ads',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Archives Sidebar', 'hostinger-affiliate-theme'),
            'id' => 'archives',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer Widget Area 1', 'hostinger-affiliate-theme'),
            'id' => 'widget-footer-1',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer Widget Area 2', 'hostinger-affiliate-theme'),
            'id' => 'widget-footer-2',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer Widget Area 3', 'hostinger-affiliate-theme'),
            'id' => 'widget-footer-3',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer Widget Area 4', 'hostinger-affiliate-theme'),
            'id' => 'widget-footer-4',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));

        register_sidebar(array(
            'name' => esc_html__('Content 404', 'hostinger-affiliate-theme'),
            'id' => 'sidebar-404',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));

        register_sidebar(array(
            'name' => esc_html__('Shop Sidebar', 'hostinger-affiliate-theme'),
            'id' => 'shop',
            'description' => esc_html__('Add widgets here.', 'hostinger-affiliate-theme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h4 class="widget-title n-m-t">',
            'after_title' => '</h4>',
        ));
    }

endif;
add_action('widgets_init', 'hostinger_aft_widgets_init');


/*
 * URL Fonts Register
 */

if (!function_exists('hostinger_aft_fonts_url')) :

    function hostinger_aft_fonts_url() {
        $fonts_url = '';
        $fonts = array();
        $subsets = 'latin,latin-ext';

        if (hostinger_aft_customize_option('hostinger_aft_typo_headings')) {
            $fonts[] = hostinger_aft_customize_option('hostinger_aft_typo_headings');
        }
        if (hostinger_aft_customize_option('hostinger_aft_typo_body')) {
            $fonts[] = hostinger_aft_customize_option('hostinger_aft_typo_body');
        }
        if (hostinger_aft_customize_option('hostinger_aft_typo_logo')) {
            $fonts[] = hostinger_aft_customize_option('hostinger_aft_typo_logo');
        }
        if ($fonts) {
            $fonts_url = add_query_arg(array(
                'family' => urlencode(implode('|', $fonts)),
                'subset' => urlencode($subsets),
                'display' => 'swap'
                    ), 'https://fonts.googleapis.com/css');

            //md5 downaloded file (function download_url wp
            /*
              $tmp_filename = download_url('https://pagespeed.ninja/api/getcss?' . http_build_query($data), 60);
              if (is_string($tmp_filename)) {
              $css = @file_get_contents($tmp_filename);
              @unlink($tmp_filename);
              return $css;
              }
              return '';
             */
        }
        return $fonts_url;
    }

endif;


/*
 * URL Fonts Register
 */

if (!function_exists('hostinger_aft_scripts')) :

    function hostinger_aft_scripts() {

        wp_enqueue_style('hostinger-aft-fonts', hostinger_aft_fonts_url(), array(), null);

        wp_enqueue_style('hostinger-aft-style', get_template_directory_uri() . '/assets/css/main.css');

        if (hostinger_aft_check_woocommerce()) {
            wp_enqueue_style('hostinger-aft-woocommerce', get_template_directory_uri() . '/assets/css/woocommerce.css');
        }
        if(hostinger_aft_customize_option('hostinger_aft_accessibility_links')){
            $custom_css = "
                a {
                    text-decoration: none;
                }
                a:hover {
                    text-decoration: none;
                }
            ";
            wp_add_inline_style( 'hostinger-aft-style', $custom_css );
        }

        if(!hostinger_aft_customize_option('hostinger_aft_accessibility_menu')){
            $custom_css = "
                .primary-menu li.menu-item-has-children:focus > ul, .primary-menu li.menu-item-has-children.focus > ul {
                    right: 0;
                    opacity: 1;
                    transform: translateY(0);
                    transition: opacity 0.15s linear, transform 0.15s linear;
                }
               
            ";
            wp_add_inline_style( 'hostinger-aft-style', $custom_css );
        }

        if (hostinger_aft_customize_option('hostinger_aft_gdpr_general_active')) {
            wp_enqueue_script('hostinger-aft-gdpr-js', get_template_directory_uri() . '/assets/js/gdpr.min.js', array(), '20190102', false); //changed from bottom
        }

        wp_enqueue_script('hostinger-aft-social', get_template_directory_uri() . '/assets/js/social.min.js', false, '20190102', true); //changed from bottom

        if (hostinger_aft_customize_option('hostinger_aft_performance_render_blocking_js')) {
            wp_enqueue_script('hostinger-aft-main', get_template_directory_uri() . '/assets/js/main.min.js', array('jquery'), '20190102', false);
           wp_enqueue_script('hostinger-aft-menu', get_template_directory_uri() . '/assets/js/menu.min.js', array('jquery'), '20190102', false);
           wp_enqueue_script('hostinger-aft-search-box', get_template_directory_uri() . '/assets/js/search-box.min.js', array('jquery'), '20190102', false);
        } else {
            wp_enqueue_script('hostinger-aft-main', get_template_directory_uri() . '/assets/js/main.min.js', array('jquery'), '20190102', true);
           wp_enqueue_script('hostinger-aft-menu', get_template_directory_uri() . '/assets/js/menu.min.js', array('jquery'), '20190102', true);
           wp_enqueue_script('hostinger-aft-search-box', get_template_directory_uri() . '/assets/js/search-box.min.js', array('jquery'), '20190102', true);
        }


        if (is_singular() && comments_open() && get_option('thread_comments')) {
            wp_enqueue_script('comment-reply');
        }
    }

endif;
add_action('wp_enqueue_scripts', 'hostinger_aft_scripts');

/** ADDED TAG rel=preload in fonts * */
if (!function_exists('hostinger_aft_add_preload_tag_fonts')) :

    function hostinger_aft_add_preload_tag_fonts($html, $handle) {
        if (strpos($handle, 'hostinger-aft-font') !== false) {
            $preload = str_replace("rel='stylesheet'",
                    " rel='preload' as='style'  ", $html);
            $style = $html;
            return $preload . $style;
        }
        return $html;
    }

endif;
add_filter('style_loader_tag', 'hostinger_aft_add_preload_tag_fonts', 10, 2);


/*
 * Add Extra Funcionality
 */
require_once get_template_directory() . '/inc/hostinger-aft-minifier.php';
require_once get_template_directory() . '/inc/template-tags.php';
require_once get_template_directory() . '/inc/extras.php';
require_once get_template_directory() . '/inc/meta-box.php';
require_once get_template_directory() . '/inc/actions.php';
require_once get_template_directory() . '/inc/jetpack.php';
require_once get_template_directory() . '/inc/shortcodes.php';
require_once get_template_directory() . '/inc/wpgallery.php';
require_once get_template_directory() . '/inc/widgets.php';
require_once get_template_directory() . '/inc/woocommerce-filters.php';
require_once get_template_directory() . '/inc/woocommerce-tags.php';
require_once get_template_directory() . '/inc/comments-walker.php';
require_once get_template_directory() . '/inc/json-ld.php';
require_once get_template_directory() . '/inc/yoast-filters.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/advertisment.php';
require_once get_template_directory() . '/inc/social.php';
require_once get_template_directory() . '/inc/toc.php';
require_once get_template_directory() . '/inc/custom-admin-notices.php';


if (hostinger_aft_customize_option('hostinger_aft_performance_lazy_load')) {
	require_once get_template_directory() . '/inc/lazy-load.php';
}

if (hostinger_aft_customize_option('hostinger_aft_quicklink_active')) {
	require_once get_template_directory() . '/inc/quicklink.php';
}


/*
 * Editor Style Register
 */

if (!function_exists('hostinger_aft_theme_add_editor_styles')) :

    function hostinger_aft_theme_add_editor_styles() {
        add_editor_style('assets/css/editor-style.css');
    }

endif;
add_action('admin_init', 'hostinger_aft_theme_add_editor_styles');


/*
 * Hostinger AFT Get Template Part
 */

if (!function_exists('hostinger_aft_get_template_part')) :

    function hostinger_aft_get_template_part($slug, $extension = 'php') {
        do_action("get_template_part_{$slug}", $slug);
        $templates = array();
        $templates[] = "{$slug}.{$extension}";
        locate_template($templates, true, false);
    }
endif;

function hasAttribute($attribute, $array){

    foreach ( $array as $element ) {
        if ( $attribute == $element->$attribute ) {
            return true;
        }
    }

    return false;
}

/*
 * Hostinger AFT Menu
 */
require_once get_template_directory() . '/inc/menu-functions.php';
require_once get_template_directory() . '/inc/class-hostinger-aft-menu-walker.php';